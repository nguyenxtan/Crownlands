# Biên bản kiểm tra bộ tài liệu 2.1

Phiên bản 2.1 · 07/11/2026 · Kiểm tra docs và đặc tả dữ liệu sau Bổ sung 02.

| Phạm vi | Kết quả |
|---|---|
| Nguồn gốc | Bảy file `reference-docs` và attachment U08 khớp SHA256 đã lưu |
| Lưu v2.0 | ZIP có39 entry, integrity đạt; 15 file lịch sử sources/reviews/proposals không đổi byte |
| Asset contract | Manifest/roster/layout JSON nguyên byte so với v2.0: 189 export planned,16 proof/134 core bổ sung/39 expansion; 14 profile/14 slot/16 plot |
| Liên kết và mã | Toàn bộ liên kết Markdown tương đối có đích; B01–B28, BS-01–BS-10, BS-T01–BS-T13, BUILD-01–BUILD-05 liên tục; D/P/O/I/N/CAL giữ namespace |
| S00 references | JSON parse, chủ/profile/gốc/capacity/site tham chiếu hợp lệ, kho không vượt cap, tổng52 quân khởi đầu đúng |
| Bước đầu kinh tế | Theo số thử: 400 lương/giờ game, quân đầu ăn52, còn348; đủ vốn cho nâng ruộng đầu. Không chứng minh cân bằng dài hạn |
| Đường đi tĩnh | BFS bốn hướng với núi/sông/cầu: mỏ đất8 ô, mỏ lương10, trại10, tiền thành17, thành chính34; tất cả mục tiêu có thể tới |
| Trạng thái game | Không gọi engine, không thử AI/trận/đói/cache/lưu/tua; BS-T01–13 là expected outcomes chưa chạy |
| Trạng thái review | Các vòng Claude trước giữ nguyên; B23–B28 và S00 là lựa chọn mới của Codex, chưa được Claude review riêng |
| Trạng thái hình | Không tạo ảnh, không thêm asset, chưa duyệt hình proof |

Kết quả máy đọc ở [static validation](prototype/static-validation.json). S00 là **specification fixture**, chưa là save hoặc ruleset đầy đủ: thiếu dữ liệu combat/health/đói/tech/schema trước khi chạy thật. Bổ sung này không chứng minh game vui, cân bằng hoặc offline thành công.

[Đối chiếu BS](prototype-readiness.md), [scenario S00](prototype/scenarios/first-foundation.json), [baseline](final-design.md) và [asset plan](asset-production-plan.md) là các điểm vào hiện hành. U10 lưu dưới dạng tóm lược biên tập, không gọi là nguyên văn/byte-exact.
