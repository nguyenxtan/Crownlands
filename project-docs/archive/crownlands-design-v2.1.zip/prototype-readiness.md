# Bổ sung 02 — đối chiếu luật và chuẩn bị prototype

Phiên bản 2.1 · 07/11/2026 · Đối chiếu U10 với [baseline](final-design.md).

U10 là danh mục kiểm tra hữu ích, **không phải lệnh hủy các lựa chọn của v2.0**. Những cơ chế đã chốt vẫn là yêu cầu thiết kế; game/asset chưa có kết quả triển khai được xác nhận. Codex chọn các luật nối B23–B28 theo ủy quyền U09, ghi riêng số thử; không gán mọi phương án mới thành ý đã được người dùng/Claude duyệt.

## 1. Kết sổ từng mục BS

| Mục nguồn | Đối chiếu hiện hành | Xử lý 2.1 |
|---|---|---|
| BS-01 Khởi đầu | Thiếu scenario cụ thể | Thêm S00 `first-foundation`, một vị trí dựng sẵn, quân thường, tài sản có nguồn. Số là preset thử. |
| BS-02 Thắng/tiếp tục | B15 đã cho Khai Quốc/Thống Nhất và tiếp tục | Khóa kiểm theo danh sách mục tiêu scenario, không săn hết tàn quân hoặc bí mật sinh phe. |
| BS-03 Bản đồ | B03 đã chọn ô vuông64²/128² | S00 bố trí núi/sông/cầu/site, thông tin khám phá và yêu cầu reachability. Chưa bật du mục. |
| BS-04 Ngoại giao | B13 chỉ trung lập/thù địch | B23 bổ sung quyền đi/đến và ba phía. Không tự mở giao thương/đình chiến/đầu hàng. |
| BS-05 Thuế/An dân | B18 đã hoãn | Không thêm kho dân sinh, tỷ lệ thuế hoặc hình phạt An dân trong core. Giữ nguyên tắc không tạo hai lần. |
| BS-06 Gốc/nâng | B07/B08 đã xử phần lớn | B24 bổ sung quá hạn mức và mất năng lực, không xóa quân tức thời. |
| BS-07 Trộn nhánh | B08/B10 đã cho trộn, quỹ hữu hạn | B25 nói rõ hỗ trợ đồng minh bất kể path và giá cơ hội; không thanh tẩy/nguyền ở core. |
| BS-08 Thứ tự năng lực | B09/B10 và combat-abilities đã có | B25 bổ sung snapshot sát thương/tổn thất đồng thời và đồng quy vu tận; không để thứ tự loop quyết định. |
| BS-09 Bonus kinh tế | B17 mới khóa riêng Đại thành | B26 chọn cộng cùng base hợp lệ; trần 40% chỉ áp phần Đại thành. |
| BS-10 Vòng đời NPC | B14 cấm nguồn/cap miễn phí, chưa đủ trạng thái kết thúc | B27 tách mất năng lực quân sự với xóa dữ liệu; giới hạn mission, không hồi sinh phe tự động. |

## 2. B23 — Quyền tương tác và nhiều phe

Core giữ **neutral/hostile**. Trung lập đi được trên các ô địa hình thông thường, kể cả màu lãnh thổ phe khác, nhưng không mặc nhiên được vào kho, trú quân, khai thác/chuyển chủ site hoặc qua cổng bị kiểm soát. Màu đất không tự sinh phí hay vùng sát thương. Tới site không có quyền vào thì dừng ở ô tiếp cận hợp lệ; không có chỗ thì giữ vị trí và báo.

Điểm tài nguyên vô chủ được chiếm giữ bằng quân hợp lệ có lương; quyền ở đây thuộc site, không tự chiếm mọi ô xung quanh.

Muốn đánh/chiếm một site thuộc phe trung lập phải xác nhận tuyên chiến trước khi xuất lệnh. Quan hệ hostile theo cặp và có hiệu lực hai chiều tại cửa lệnh; không tuyên chiến với toàn bộ NPC. Không tấn công đoàn xe giữa đường ở baseline này; hàng chỉ gặp cổng/quyền nhận tại site. Giao thương/đình chiến/đầu hàng có điều khoản tiếp tục hoãn, không tạo bốn state ngoại giao chỉ vì nguồn liệt kê.

Nhiều bên cùng đến một mốc được gom vào pha giao chiến. Giải quyết từng trận **giữa hai chủ**, theo sequence ổn định đã lưu của sự kiện tới; không phụ thuộc FPS/iteration map. Bên giữ ngoại thành hiện tại là bên chiếm vị trí, không đồng nghĩa chủ thành. Mỗi bên đến hostile với bên giữ vị trí thì đánh bên đó trước; thắng mới thay bên giữ. Các bên cùng chủ có thể tập kết nếu không đang đi/job, các chủ khác không gộp quân dù cùng địch.

Nếu bên đến trung lập với bên đang giữ thì không cùng tiếp quản hoặc đi xuyên vào site để đánh chủ bên trong; dừng ngoài, đổi mục tiêu hoặc tuyên chiến bằng lệnh sau. Sau mỗi trận, trận tiếp theo đọc lực lượng/kiểm soát/cooldown đã commit. Đây là quy ước giải quyết tuần tự có lợi thế thứ tự đến; phải hiện trong báo cáo và thử đổi thứ tự. Không gọi nó là trận ba phe đồng thời.

Cả hai bên chết hết: vị trí không có quân giữ, chủ thành vẫn giữ đến một job tiếp quản hợp lệ hoàn tất. Không có người thắng tưởng tượng; job mất điều kiện về 0. Pha hàng sau đó đọc kết quả cuối của toàn nhóm giao chiến cùng mốc.

## 3. B24 — Vượt suất và mất gốc

Chuyển nơi đóng **không chuyển gốc**. Gán gốc mới là lệnh riêng, chỉ thành cùng chủ đủ suất nhận; chuyển khoản dùng/giữ một lần, không đặt quân ở hai gốc. Chỉ tính sức chứa nơi đóng để nhận hành trình; nó không là hạn mức tuyển mới.

Khi gốc mất hoặc capacity giảm: giữ quân sống/chủ/địa điểm, chặn lệnh tuyển/nâng làm tăng nhu cầu; hủy phần hàng chờ chưa chạy vượt khả năng, giải phóng khoản giữ theo luật hiện hành. Job đang chạy thiếu suất thì pause, không hoàn tất bất chấp cap hoặc trừ chi phí lần nữa khi resume. Không lấy cap/kho của chủ mới. Hủy phần đã tiêu không tạo hoàn tài nguyên mới.

Có **nợ biên chế** nếu tổng suất quân hiện hữu vượt capacity nguồn hoặc chưa có gốc. Bắt đầu đồng hồ game của đợt nợ; di chuyển/tách/gộp/đổi tên nguồn không reset thời gian. Chỉ hết nợ khi thật sự có đủ nguồn hợp lệ. Trong ân hạn cho phép phòng thủ, vận tải, rút và gán lại, không tự suy yếu/quân biến mất.

Sau ân hạn, phần nợ có thêm chi phí lương theo tỷ lệ `r = max(0, used - capacity) / used` với `used>0`; gốc đã mất hoặc pending thì capacity 0. Mỗi cohort dùng nguồn đó chịu `upkeep = base_upkeep × (1 + r × surcharge)`. Đây là chi phí của thiếu cơ cấu, không phạt số thành. Khi không nuôi được, áp luật đói chung tại nơi đóng, không một cơ chế xóa quân thứ hai. Người đủ giàu được giữ lực lượng vượt cap với chi phí, nhưng không tuyển/nâng tăng thêm.

Preset S00 thử ân hạn 6 giờ game, surcharge 1 (tối đa gấp đôi lương cơ bản khi hoàn toàn không có nguồn). Các số thuộc CAL02/CAL10, chưa chứng minh hợp lý. Không áp surcharge cho suất chỉ đang giữ mà chưa thành quân; giải quyết reservation trước rồi tính ratio. Bucket quân giữ mốc nợ; gán nguồn không đủ hoặc đi vòng qua gốc đã mất không làm mới ân hạn.

## 4. B25 — Nhánh hỗn hợp, snapshot và thứ tự

Được trộn nhánh. Hộ trận áp quân **cùng chủ trong tuyến bảo vệ**, kể cả umbral/martial; không bảo vệ phe khác chỉ vì cùng đánh một địch. Tổng quỹ và số nguồn theo quân sẵn sàng, không tăng vì thêm nhóm. Quỹ hữu hạn tạo giá cơ hội về slot/suất/kho/lương/hồi; không thêm một “phí phép” trừ tài nguyên không có trong profile.

Phá ấn chỉ có ngân sách của số nguồn đủ điều kiện, không vô hạn theo số mục tiêu; một lần/trận của phần quân sẵn sàng. Martial có giá trị profile/khắc dòng, không phải quân chịu đòn miễn phí cho hai nhánh còn lại. Không có đủ số thì chưa thể kết luận đội hỗn hợp cân bằng, nhưng cũng không tự phạt đội hỗn hợp để che lỗi số.

Thứ tự: snapshot ban đầu → Hộ trận của cả hai bên → tổng Phá ấn hợp lệ của cả hai bên → từng lượt tính sát thương từ snapshot quân sống đầu lượt → phân bổ quỹ → áp tổn thất đồng thời → xét kết thúc. Chủ động core chỉ kích ở bước đầu, không spam mỗi round. Nguồn còn đủ điều kiện tại snapshot thực hiện; chết sau bước đó không hủy ngược quỹ đã tạo. Quân chết từ lượt trước không ra đòn ở lượt sau. Hết lượt 12 chưa dứt thì không tự cấp thành.

Hai bên mất hết trong cùng lượt vẫn được ghi đúng; không bên nào được ra đòn lần hai vì chương trình duyệt trước. Thanh tẩy/Nguyền chưa thuộc core: không viết một thứ tự giả để quảng cáo chúng đã có luật.

## 5. B26 — Một pipeline sản lượng

Với mỗi nguồn/tài nguyên/đoạn thời gian:

`available_base = base_rate(level) × control_availability × recovery_factor`

`rate = available_base × max(0, 1 + research_bonus + great_empire_bonus + great_region_bonus)`

Các bonus cộng trên **cùng available_base**, theo scope riêng. `great_empire + great_region ≤0.40`, mỗi phần ≤0.20; đây không phải trần research+mọi thứ. Ví dụ base100, availability/recovery đều1, Great40% và research20% hợp lệ: **160**, không 168.

Great chỉ áp nguồn ô sản xuất thành cùng chủ; mỏ world không nhận Great. Nghiên cứu chỉ áp những nguồn/tài nguyên ghi trong tech; không tự thưởng tất cả vì trùng tên lương. Một bonus chỉ ghi một lần theo effect/source key. Đoạn trước/ sau đổi chủ/tech/ổn định tính riêng; không áp hồi tố hoặc lấy bonus đã cộng làm base của bonus sau.

Control/recovery là mức hoạt động thực, không một bonus âm tùy tiện; recovery profile do CAL09 chọn. Giữ phần lẻ fixed-point qua các đoạn, không làm tròn mỗi frame. Sau tính sản xuất mới áp kho/capacity, phần không nhận được ghi theo luật đầy kho; chi lương/vận tải là các dòng riêng. Không có thuế/An dân/policy tăng sản lượng trong core (`0/not-active`), không cộng tài nguyên từ một kho dân sinh chưa tồn tại. Khi thêm về sau phải thay pipeline có version và sổ bảo toàn.

## 6. B27 — NPC mất thành, kết thúc và trần

`settled`: có ít nhất một thành sở hữu. `landless`: không còn thành nhưng còn Army/tài sản sống. Quân giữ gốc cũ thành pending, không cap mobile/tuyển/hồi sinh miễn phí; tiếp tục tiêu lương và có thể giành một thành bằng quân còn sống theo cùng điều kiện tiếp quản. Không tự dựng thành mới nếu chưa có luật định cư/nguồn.

Phe được ghi **thất bại về quân sự** khi không còn thành hoạt động, quân chiến đấu hoặc quyền tái lập đã được scenario cấp hợp lệ. Không dùng điều kiện này để xóa hàng/xe/ledger/event vẫn còn chủ. Chỉ archive phần AI khi hết công việc sống; giữ faction ID và lịch sử, không tái dùng ID. Cleanup chỉ bỏ event version cũ hoặc đối tượng không còn tài sản, không xóa Army sống để ép giảm số.

Không tự hồi sinh phe hoặc sinh vương quốc mới trong S00. Khám phá một phe dựng sẵn không phải tạo mới; mọi setup phải nằm trong scenario. Không cần bù số địch khi người chơi thắng. Thương đoàn/du mục chưa có ở core nên không bịa nguồn cung tuần hoàn cho chúng.

Preset kingdom tối đa 4 Army chiến dịch ngoài thành, patrol tính trong4; local defender không tự tạo đoàn. B hai kingdom thử tối đa8 tổng đoàn do planner tạo. Chạm trần thì chặn tạo/tách mới, không xóa quân hiện có hoặc dịch chuyển chúng; thủ quân tại thành không bị tính thành Army ngoài thành. Đoàn có lịch đói và mission riêng. Trần/budget là CAL11, không một hạn mức thần bí thay suất quân.

## 7. B28 — Khởi đầu, bản đồ và thành tựu thử

[S00 first-foundation](prototype/scenarios/first-foundation.json) là **đặc tả dữ liệu thử, chưa phải save chạy được**. Bản đồ64² dựng sẵn, một thành người chơi, một vương quốc hai thành, một trại địa phương và hai điểm khai thác. Giữ vương quốc mạnh hơn ở xa; không tăng cấp chúng theo tiến trình người chơi. Vị trí/công trình/kho/quân đều khai trong file, không spawn để làm vừa kết quả.

Người chơi bắt đầu Phủ 1, 52 quân thường (20 kiếm/20 giáo/12 cung), 16 plot cấp 1, bốn xe; kho1200 gỗ/đất/sắt và1800 lương. Đây là lựa chọn preset của Codex để thử vòng khởi đầu, **không là mức kinh tế đã cân bằng hoặc toàn bộ game chỉ có 52 quân**. Nhánh mở sau nghiên cứu/cơ sở, không khóa phe từ Chơi mới.

Trong 3600 giây game đầu, kingdom chưa được phóng chiến dịch mới vào thành khởi đầu; thủ quân/site địch vẫn chiến đấu, không có khiên miễn nhiễm. Người chơi đánh kingdom đó thì hết điều kiện trì hoãn ngay sau xác nhận; đánh trại địa phương không liên quan không kết thúc guard với kingdom. Tăng tốc áp timer như mọi việc, pause dừng timer. Hết guard không ép AI tấn công nếu không có mục tiêu khả thi.

Sông/núi chặn đường, cầu nối ô cho cả quân/xe; chưa hải quân hoặc đánh trên đoạn. S00 đi bốn hướng, không cắt chéo góc. Phải có đường hợp lệ từ start đến mọi mục tiêu bắt buộc và có nguồn bốn tài nguyên trong thành. Thông tin khám phá nhớ terrain; current vision/intel timestamp quyết định được biết quân/kho, không mở hết state khi vừa lộ tên site.

Mục tiêu đầu là nâng một ruộng, trinh sát bằng quân hiện có, chiếm mỏ và nhận hàng thật, giao chiến, chiếm/vận hành thành thứ hai và restore save. **Không bắt có Học viện hoặc quân cao mới được hoàn thành chiến dịch đầu.** S00 chưa có Đại thành; mốc hoàn thành của nó không gọi là Khai Quốc.

Bản thế giới đầy đủ khai danh sách Đại thành/vùng mục tiêu và thời gian giữ hợp lệ trong scenario. Khai Quốc khi giữ Đại thành đầu ổn định; Thống Nhất khi đủ mục tiêu khai báo, không cần săn mọi tàn quân. Nếu sở hữu toàn bản đồ, ghi chiến thắng và tiếp tục cùng save; không reset hoặc sinh đối thủ bắt buộc. Điều kiện từng scenario phải công bố trước, không đổi khi người chơi gần đạt.

## 8. Thứ tự dựng bản chơi và điều kiện nghiệm thu

Giữ giai đoạn2 là asset proof; code có thể dùng placeholder sau đó, không bắt hoàn tất189 export trước thử luật. Thứ tự năm mốc của U10 được chỉnh để **chiếm thành thứ hai trước nghiên cứu sâu**, giữ vòng A1 đã review.

| Mốc code | Nội dung | Nghiệm thu khi có engine |
|---|---|---|
| BUILD-01 | Clock/command/state, thành, kho/sản xuất, local save/export/import/cache | Cùng state/lệnh cùng mốc+pha cho kết quả tương đương ở1/2/4/8×; đóng không chạy bù; khôi phục job dở; ngắt mạng vẫn mở đủ bộ cục bộ. |
| BUILD-02 | Tuyển I, mỏ, xe, trại, trinh sát và phản ứng NPC nhỏ | Quân/hàng một vị trí, không cap do ra ngoài, xe đi/về, đầy kho/hàng kẹt có lý do; không NPC teleport. |
| BUILD-03 | Auto battle, cổng/ngoại thành/tiếp quản, thành thứ hai — kết A1 | Đi hết vòng chơi S00, sở hữu/kho/cấp chuyển một lần; ba phía không tự gộp; chưa cần tech để thắng mục tiêu phù hợp. |
| BUILD-04 | Một dự án, cơ sở, nâng một dòng — phần đầu A2′ | Mất Học viện/gốc/job bị đánh/hủy/load không nhân quân/hoàn chi; quân bậc cũ chịu trận; nợ cap có hậu quả đúng. |
| BUILD-05 | Đủ 14 profile, ba năng lực, L patrol rồi B nhiều phe/tàn quân | Quỹ dùng chung/cooldown/snapshot đúng; đoàn có nguồn và mục tiêu, không đường combat; NPC không cùng phe mặc định. |

Âm thanh/cảnh báo âm lượng làm sau vòng nền, không thêm asset âm thanh vào manifest hiện tại. Phải xác nhận dữ liệu combat/đói/cost/schema trước khi chạy S00; file scenario đã chỉ rõ các phần thiếu. Các ngưỡng hiệu năng định trước trên máy đo ở CAL15, không lấy server p95 cũ.

## 9. Ca nghiệm thu mới — chưa chạy

| Mã | Tình huống | Kết quả yêu cầu |
|---|---|---|
| BS-T01 | Chơi mới cùng scenario/seed | Cùng vị trí/kho/quân/nguồn; không spawn theo FPS. |
| BS-T02 | Cầu bị bỏ trong cấu hình | Validator phát hiện mục tiêu bắt buộc không còn đường nếu không có đường thay thế; không sinh teleport. |
| BS-T03 | Tua/pause trong guard rồi đánh kingdom | Timer game đúng, kết guard đúng phe; không miễn garrison. |
| BS-T04 | Trung lập đi qua màu đất nhưng muốn vào site | Qua địa hình được; vào kho/chiếm/tấn công cần quyền/tuyên chiến, không gộp quân. |
| BS-T05 | Ba chủ hostile đến cùng mốc | Trận theo sequence lưu, mỗi trận hai chủ; hàng đọc sau nhóm trận; không liên minh tự sinh. |
| BS-T06 | Cap giảm, gốc mất, pause/load/tách/gộp/gán vòng | Quân sống giữ chủ, không reset nợ; không tuyển/nâng tăng; phí lương đúng nơi/số. |
| BS-T07 | Hộ trận hỗ trợ nhánh khác | Cùng chủ/tuyến chia cùng quỹ; thêm nhóm không thêm quỹ; chủ khác không được hưởng. |
| BS-T08 | Đồng quy vu tận và nguồn ward chết | Damage snapshot đồng thời; quỹ đã tạo không hồi lại, chủ thành không đổi bởi người thắng rỗng. |
| BS-T09 | Base100/Great40%/research20% và scope mine | City hợp lệ160; mine không nhận Great; không nhân nối tiếp thành 168. |
| BS-T10 | Cùng đoạn kinh tế bị chia nhiều frame | Fixed-point/phần lẻ và đổi mốc cho cùng tổng, không tạo thêm do rounding. |
| BS-T11 | Phe mất hết thành nhưng còn quân/xe/hàng | Landless/ledger tồn tại, không cap/tuyển mới; không cleanup tài sản sống. |
| BS-T12 | Đạt trần đoàn hoặc thắng toàn bản đồ | Chặn tạo mới hợp lệ, không xóa đoàn; ghi thắng và tiếp tục, không phe mới bắt buộc. |
| BS-T13 | Tải offline sau cài đủ, file local thiếu hoặc save phiên bản khác | Cache manifest được kiểm; thiếu/hỏng/version không hỗ trợ có giải thích, không mất save âm thầm. |

Đây là expected outcomes, chưa có implementation test hoặc playtest. Kiểm JSON/đường đi tĩnh chỉ chứng minh cấu hình nhất quán, không chứng minh đã thắng được trận, AI thú vị hoặc chơi offline thành công.
