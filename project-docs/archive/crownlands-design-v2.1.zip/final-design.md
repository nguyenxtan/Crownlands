# Crownlands bản chốt để sản xuất asset

Phiên bản 2.1 · 07/11/2026 · Baseline asset đã chốt; bổ sung luật nối và chuẩn bị prototype.

**Nguồn ủy quyền U09:** chủ dự án yêu cầu chốt phương án, viết tài liệu cuối để chuẩn bị giai đoạn 2 — asset. Codex lựa chọn các mặc định dưới đây từ nguồn U08 và các vòng phản biện với Claude. Đây là baseline có hiệu lực cho sản xuất asset, không phải tuyên bố game đã được lập trình, chơi thử hoặc cân bằng.

Các quyết định B01–B28 là lựa chọn triển khai theo ủy quyền này. Chỉ số giá, sát thương, lương, tốc độ và thời lượng được quản lý trong [sổ hiệu chỉnh](calibration-register.md); không gọi những chỉ số chưa thử là đã cân bằng. Thay dòng quân, nhánh, camera, bố cục hoặc phạm vi sản xuất phải cập nhật baseline, không tự mở rộng trong lúc tạo ảnh.

## 1. Đích sản phẩm

**B01 — Game chiến thuật một người, web offline, 2D, ưu tiên desktop.** Người chơi xây đế chế trong một thế giới tiếp diễn qua bản lưu và cạnh tranh với vương quốc NPC. Không tài khoản/server nhiều người, thanh toán hoặc dịch vụ AI online làm tiền đề. Đích UI 1440×900, tối thiểu 1024×768; bản mobile riêng để sau.

Giữ thành tròn/ô cố định, năm dòng quân, bố trận tự tính và báo cáo; không hoạt cảnh giao chiến. Hình chi tiết nội thành và biểu tượng bản đồ là hai bộ có tỷ lệ riêng.

**B02 — Nhịp offline:** pause dừng mọi phe; chọn tốc độ 1×/2×/4×/8× và tua tới sự kiện đáng chú ý. Đóng game không tính bù giờ đời thực. Có thể đặt lệnh khi pause tại cửa lệnh hợp lệ. Tự dừng khi giao chiến/đổi chủ hoặc cảnh báo lương quan trọng được phép biết.

Lưu tay ba slot, một quicksave, năm autosave luân phiên; autosave mỗi năm phút đời thực khi đang chơi và tại điểm an toàn trước các biến động lớn. Khoảng lưu không làm thế giới trôi khi pause/đóng. Có export/import save. Chỉ lưu giữa bước nguyên tử, giữ bản trước nếu ghi lỗi.

## 2. Thế giới, thành và tài nguyên

**B03 — Bản đồ ô vuông logic**, địa hình hiển thị tự nhiên, lưới có thể bật/tắt. Vùng thử 64×64 ô, khuôn thế giới đầu 128×128 ô; mở quy mô sau đo hiệu năng. Chưa có hàng hải hoặc giao chiến trên đoạn đường. Không chia nhánh quân thành các lục địa/tài nguyên riêng.

**B04 — Một bố cục thành:** 14 ô nội thành cố định, 16 ô tài nguyên ngoại thành (4 gỗ, 4 đất sét, 4 sắt, 4 lương). Công trình và ô tài nguyên có trần 20. Ô chưa xây là 0, không phải cấp quân. Sức mạnh thực không suy từ một con số cấp thành.

Tên hiển thị “cấp thành” dùng cấp Phủ làm mốc hành chính/ngoại hình, ghi rõ không là tổng quân lực. Hạng mục tiêu NPC 1–20 là đánh giá riêng theo cấu hình/thông tin được biết; công thức rating thuộc hiệu chỉnh, không đổi asset.

| Ô | Công năng khóa cho layout |
|---|---|
| S01 | Phủ thành |
| S02 / S03 | Kho tài nguyên / Kho lương |
| S04 / S05 | Điểm tập kết / Doanh trại |
| S06 / S07 | Học viện / Trạm vận tải |
| S08 / S09 / S10 | Lò rèn / Chuồng ngựa / Trại voi |
| S11 | Dinh điều hành, mở sâu sau vòng lõi |
| S12 / S13 | Vị trí kho tài nguyên/lương bổ sung |
| S14 | Ô dự trữ cho công trình tương lai, hiện để trống |

Tường/cổng là lớp bao thành riêng, không chiếm một ô nhà. Trạm vận tải đảm nhiệm xe nội bộ; giao thương NPC tương lai có thể dùng nơi này, không mở chợ phức tạp chỉ để có xe. Trạm cứu thương, Xưởng công thành và Tháp quan sát chưa thuộc bộ nhà lõi.

Giữ bốn tài nguyên, kho cục bộ và vận chuyển thật. Nguồn được bảo vệ/ngoại thành được gắn khu kiểm soát rõ. Mỏ thế giới có trần năng suất và kho; bản đầu không cạn tài nguyên theo chu kỳ. Không thêm vàng/mana/thép như tài nguyên bắt buộc.

## 3. Quân, công nghệ và biên chế

**B05 — Năm dòng, I–V, ba đường chuyên hóa.** Kiếm/giáo/cung/kỵ/voi giữ nhận diện. I–III dùng nền chung; IV–V đi theo **Quân chế (`martial`), Thánh Quang (`radiant`), Hắc Ảnh (`umbral`)**. Quân chế là đường hoàn chỉnh. Thánh/Hắc không mặc định thiện/ác hoặc bạn/địch.

45 profile là đích nội dung dài hạn nếu mọi tổ hợp tồn tại. Bộ đại diện đầu có 14 profile theo [roster khóa](asset-production/unit-roster.json): kỵ I–III và IV ba đường; bốn dòng khác I–II. Kỵ IV Thánh mang tên **Kỵ vệ Thánh Ấn**; **Paladin/Thánh kỵ sĩ** dành cho kỵ V Thánh, chưa nằm trong 14 profile. Kiếm Thánh vẫn là bộ binh.

**B06 — Kiến thức toàn đế chế, cơ sở và thanh toán địa phương.** Một dự án nghiên cứu toàn đế chế tại một thời điểm; cùng công nghệ không chạy hai bản. Học viện mở kiến thức; Lò rèn và nơi tuyển quyết định thành nào sản xuất/nâng được. Không cộng tốc độ bằng nhiều Học viện. Công nghệ xong không tự nâng quân.

Kiến thức hoàn tất giữ khi mất Học viện hoặc tái lập; dự án dở tại thành bị chiếm hủy, phần đã tiêu không hoàn cho chủ cũ, chủ mới không nhận công nghệ. Giữ cấp nhà khi chiếm, không nhận kiến thức của chủ cũ. Công cụ lọc/cảnh báo/giảm thao tác cơ bản có từ đầu, không khóa sau nghiên cứu.

**B07 — Hạn mức theo suất có trọng số**, tách sức chứa nơi đóng và khả năng nuôi. Mỗi phần quân có gốc; đi xa/giữ mỏ/ở trại/đang nâng vẫn tính. Quân đang tuyển giữ chỗ; trọng số theo profile được hiệu chỉnh. Mất gốc không xóa/chuyển chủ quân: vào chờ biên chế, không tuyển/nâng thêm từ nguồn đã mất. Gán lại cần thành cùng chủ đủ suất.

**B08 — Tuyển thẳng hoặc nâng một phần quân cũ tại chỗ.** Công nghệ/cơ sở/kho/suất đủ mới nhận lệnh. Job nâng/chuyển nhánh hoàn tất cả lô còn sống tại một mốc. Trong lúc làm, quân vẫn là thủ quân, đánh bằng profile cũ, chưa được hành quân. Muốn đi phải hủy trước.

Quân chết giảm job và giải phóng suất tương ứng ngay. Suất tăng giữ trước; suất giảm chỉ trả khi đổi xong. Hủy việc chưa chạy giải phóng phần giữ; việc đã chạy không hoàn vật liệu đã tiêu trong baseline đầu. Mất cơ sở/chủ địa điểm hủy job. Mất riêng thành gốc làm job tạm dừng, chỉ tiếp tục khi gán nguồn cùng chủ hợp lệ; không lấy suất chủ mới.

Chỉ một profile/nhánh có hiệu lực. Có thể học và trộn nhiều nhánh trong một đạo quân, không bất mãn tự sinh. Chưa có XP từng lính, item hoặc hệ chữa thương riêng. Nâng không tự hồi sinh/hồi máu. So đường tuyển/nâng theo nhiều chi phí, không ép một đường luôn rẻ hơn hoặc nhanh hơn.

## 4. Chiến đấu và năng lực

**B09 — Trận tự giải quyết trên lưới 3×3**, tối đa 12 lượt cho preset đầu; phân bổ/đội hình được chọn trước. Không ra lệnh phép giữa trận. Năng lực lõi: **Hộ trận, Phá ấn, Trang bị chuyên dụng**. Nguyền/Thanh tẩy/Kỷ luật làm sau; không thêm sợ hãi chỉ để có kỹ năng chống nó.

**B10 — Hộ trận là một quỹ chung theo tuyến/loại.** Tổng đóng góp tỷ lệ quân nguồn sẵn sàng, không có phần cố định theo số nhóm. Nhiều nhóm cùng rút từ một quỹ; phân bổ hấp thụ cùng lượt theo tỷ lệ sát thương hợp lệ và quy tắc phần dư đối xứng. Quỹ chụp khi kích hoạt, tồn tại kể cả nguồn chết đến khi cạn/hết hạn/hết trận; không tái sinh hoặc nhân lên khi gộp nhóm.

Phá ấn giảm quỹ mục tiêu trước sát thương trong giới hạn profile; không tạo tài nguyên. Trigger, chọn tuyến và trường hợp không có quỹ theo [đặc tả năng lực](combat-abilities.md). Trang bị chuyên dụng củng cố một lợi thế dòng vốn có, không miễn phản chế. Hiệu ứng chỉ tồn tại trong trận lõi; thời hạn tính lượt. Hồi tính thời gian thế giới, lưu theo bucket quân. Tách giữ mốc; gộp không lấy mốc sớm nhất cho tất cả; đổi nhánh dùng `max(old_ready, finish + rearm_new)`, không rửa hồi qua nhánh bị động/load.

**B11 — Hai lớp đọc được:** ma trận tương khắc theo dòng trước, hiệu ứng/quỹ sau; nhánh không sửa K. Dấu lợi/bất lợi khóa như sau, không bảo đảm kết quả trận bất kể ngân sách:

| Công → thủ | Kiếm | Giáo | Cung | Kỵ | Voi |
|---|---|---|---|---|---|
| Kiếm | = | + | + | − | − |
| Giáo | − | = | − | + | + |
| Cung | − | + | = | − | + |
| Kỵ | + | − | + | = | − |
| Voi | + | − | − | + | = |

Hệ số, stats và quỹ là hiệu chỉnh, không kết luận bậc cao luôn thắng hoặc quân thấp luôn còn giá trị mọi lúc. Báo cáo giải thích dòng/bậc/nhánh, quỹ, tổn thất, hàng và kiểm soát. Không hồi sinh, triệu hồi vô hạn hoặc teleport.

## 5. Chinh phục và hậu cần

**B12 — Một quy trình chuyển quyền.** Tách chủ, thủ quân, người giữ ngoại thành, job tiếp quản và phục hồi. Công phá/vây/rút là lựa chọn chiến dịch; đầu hàng nhiều điều khoản chưa thuộc bản lõi.

Tiếp quản chỉ chạy khi giữ ngoại thành, hết thủ quân đối kháng, đủ lực giữ cấu hình và có lương. Hoàn tất đổi chủ một lần; mất điều kiện hủy về 0, thắng toán nhỏ mà vẫn đủ điều kiện không reset. Thành mới chiếm vẫn có thể bị đánh lại. Kho/công trình ở lại, không chia cấp vì nhầm tỷ lệ tái lập; quân cũ giữ chủ.

Chỉ nguồn thật sự mất kiểm soát mới ngừng sản xuất. Kho và nguồn được bảo vệ vẫn dùng. Bên giữ cửa chọn chặn/để ngỏ; chặn thì xuất thành giải quyết trận tại địa điểm, không tường. Đoàn đã rời không bị kéo lại vì đổi lập trường. Không có miễn tấn công toàn cầu.

Hàng kiểm tra quyền/cổng lúc tới. Không nhận được thì về nguồn một lần; nguồn không hợp lệ chọn nơi cùng chủ hợp lệ, không có thì kẹt có thông báo, không mất/nhân hàng hoặc quay vòng vô hạn. Trại không sản xuất miễn phí, ăn lương tại chỗ; xe có chu kỳ đi và về thật. Tuyến đặt sẵn có dự trữ/ngân sách/số xe, không tự quyết chiến tranh.

## 6. Phe, đoàn và mục tiêu

**B13 — Phe, nhánh, quan hệ tách biệt.** Tên nội dung khóa dùng trong production: Vương triều Thiết Quan, Hắc triều Tro Tàn; Giáo đoàn Bình Minh dành mở rộng. Một phe thiên nhánh không có nghĩa mọi quân đều thuộc nhánh đó. Quan hệ lõi trung lập/thù địch, cấu hình theo scenario và lưu, không tự đánh vì chữ Thánh/Hắc.

A1 dùng Hắc triều làm đối thủ; B thêm Thiết Quan. Setup tài sản/công nghệ ban đầu được ghi nguồn, không giả vờ đã mô phỏng lịch sử hoặc cấp miễn phí giữa game. AI dùng tin quan sát, lương và cam kết, có ngân sách đầu tư; khi chưa thể đánh được phép trinh sát/đầu tư, không tự sát để đạt chỉ tiêu hoạt động.

**B14 — Đoàn là Army có mission**, hành quân/dừng/quan sát/hành động ở địa điểm. L thử một patrol có căn cứ; B thử tàn quân thật sau mất thành. Quân vẫn dùng gốc, tàn quân không có suất/tuyển mới miễn phí. Du mục/cap mobile để sau, không truyền cơ chế đó cho người chơi.

Không có trận giữa đường ở baseline đầu: hai đoàn đi ngang nhau chưa đánh, chưa cướp xe/hộ tống/đuổi bắt bằng va chạm. Truy đuổi theo nơi thấy cuối cùng, không tọa độ ẩn. Dừng chân không tạo đất hoặc thành miễn phí. Nguồn đoàn/ngân sách/trần/giải tán có sổ; cleanup không xóa tài sản sống.

**B15 — Thắng lớn là phần thưởng.** Có mốc Khai Quốc khi giữ Đại thành đầu tiên và mốc Thống Nhất theo mục tiêu scenario; được tiếp tục sandbox, không reset. Không bắt săn mọi tàn quân để tiếp tục. Đế chế lớn chịu đường xa, nhiều mặt trận và phục hồi thật, không phạt theo thành thứ 30 hoặc sinh quân bí mật.

**B16 — Phục hồi dài hạn:** mất thành cuối giữ 1/3 cấp công trình hợp lệ khi tái lập; di dân chủ động hợp lệ từ thành cuối giữ 1/2. Một quyền/nguồn dùng một lần, không quyền mới cho mỗi thành phụ bỏ. Chỉ cấp hoàn thành tại snapshot ngay trước mất quyền/commit di dân thành cuối của nguồn đó, làm tròn lên, ô rỗng vẫn 0; không chọn mốc cao nhất từ cả lịch sử. Không mang đất/quân chết/kho theo tỷ lệ, quân rút cần đi thật. A1 có thể dùng load trước khi module tái lập được xây, nhưng không thay luật bản đầy đủ.

**B17 — Thưởng Đại thành B giữ 20/20/40.** Base là sản xuất ô tài nguyên trong thành cùng chủ, trước trừ lương; không gồm mỏ/loot/trade/hỗ trợ. Nguồn Đại thành ổn định hợp lệ cho tối đa +20% đế chế, vùng có Đại thành hợp lệ thêm tối đa +20%; cộng không nhân, không lặp. Chủ khác trong vùng không tự nhận và không mất thành.

Thưởng chỉ bật sau mốc ổn định; chủ cũ dừng khi đổi chủ, không fade chồng hai chủ. Quấy rối nhỏ không tự tắt thưởng toàn đế chế; mất nguồn sản xuất thật vẫn ảnh hưởng nơi đó. Không thêm yêu cầu kết nối đường toàn cầu trước khi có luật mạng đủ rõ.

## 7. Phạm vi và sản xuất hình

**B18 — Chưa làm trong lõi:** thuế/An dân, thanh quản trị, dự bị/tự quản, hợp đồng dài hạn, nhập thành, chư hầu, du mục, thương binh/tù binh, item/XP, Thanh tẩy/Nguyền đầy đủ, công thành phức tạp, hàng hải và trận giữa đường. Các ý tưởng còn trong nguồn, không phải điều kiện để sang asset.

**B19 — Mỹ thuật khóa theo [art bible](art-bible.md):** 2D cách điệu sáng, một kiến trúc giả tưởng; world nhìn từ trên, thành chi tiết nhìn chéo; ánh sáng chung trong từng lớp, mọi marker và chữ động tách khỏi ảnh.

**B20 — Phạm vi asset:** 14 profile đại diện, 10 nhà lõi, ba mốc hình nhà (1–6/7–13/14–20), bốn loại tài nguyên, bộ world/city/UI/hiệu ứng báo cáo. Tường riêng; Dinh điều hành/công thành và đủ 45 profile mở rộng sau. Bốn mùa là cảnh quan, không sửa hình ô/vùng bấm hoặc chỉ số kinh tế.

**B21 — Giai đoạn 2 theo ba đợt:** `proof` 16 mẫu đại diện và composite kiểm tỷ lệ; `core` bộ dùng cho lát cắt; `expansion` mùa/công trình/nội dung mở sâu. Asset chưa tạo đều có trạng thái `planned`, không coi manifest là ảnh đã hoàn tất. Hai concept cũ không là mẫu duyệt.

**B22 — Khóa cấu trúc, hiệu chỉnh số.** Giai đoạn 2 được bắt đầu từ baseline này. Cần duyệt mẫu thật của đợt proof trước nhân rộng. Những thay đổi không ảnh hưởng camera/shape/ID có thể hiệu chỉnh bằng ruleset; thay cấu trúc phải cập nhật version và danh mục tác động. Không tự sản xuất 45 quân hoặc thêm phép chỉ vì có ý tưởng trong file tham khảo.

## 8. Luật nối sau bổ sung 02

Đối chiếu U10 ở [prototype readiness](prototype-readiness.md), gồm bảng BS-01–BS-10 và điều kiện nghiệm thu. B23–B28 là lựa chọn nối luật của Codex theo U09, không tự duyệt bốn trạng thái ngoại giao, thuế/An dân, Nguyền/Thanh tẩy hoặc du mục trong nguồn. Số trong S00 là preset thử, chưa cân bằng. Art contract/roster/layout/manifest vẫn v2.0, không thêm asset.

**B23 — Quyền đi/đến và nhiều phe:** trung lập qua địa hình không đồng nghĩa vào kho/cổng/khai thác đất có chủ; tấn công cần quan hệ hostile/tuyên chiến. Điểm tài nguyên vô chủ được giữ bằng quân hợp lệ. Nhiều chủ cùng đến xử lý các trận hai phía theo sequence đã lưu, không tự gộp quân khác chủ, không gọi là trận ba phe đồng thời.

**B24 — Nợ biên chế:** mất gốc/giảm capacity không xóa quân; chặn tăng, xử lý khoản giữ/job và cho thời gian gán lại. Sau ân hạn có phụ phí lương theo tỷ lệ thiếu suất; tách/gộp/load không làm mới ân hạn. Không nuôi được áp đói chung, không xóa quân lần hai. Chi tiết/timer ở prototype readiness, số thử CAL02/CAL10.

**B25 — Nhánh trộn và sát thương đồng thời:** Hộ trận hỗ trợ quân cùng chủ/tuyến bất kể nhánh, dùng một quỹ; chủ khác không hưởng. Hai bên tạo quỹ → phá quỹ → từng lượt damage snapshot → áp casualty đồng thời, không lệ thuộc vòng lặp. Giữ Thanh tẩy/Nguyền ngoài core.

**B26 — Pipeline kinh tế:** mọi bonus sản xuất đang có cộng trên cùng base sau khả dụng/khôi phục; Great riêng trần 20/20/40 và scope thành, không là trần mọi research. Base100+Great40%+research20% hợp lệ bằng160. Kho/chi lương/nguồn đầy xử lý riêng, phần lẻ fixed-point giữ qua đoạn; không thuế/An dân cộng thêm trong core.

**B27 — Vòng đời NPC:** settled/landless khác trạng thái thất bại quân sự và archive dữ liệu. Quân/hàng còn sống giữ chủ và lịch; không hồi sinh/tuyển/cap miễn phí khi lưu vong, không phe mới bắt buộc sau thắng. Chặn tạo đoàn khi đầy trần, không cleanup bằng xóa quân sống.

**B28 — Scenario đầu và mục tiêu:** S00 `first-foundation` đặc tả 64² dựng sẵn, một thành người chơi, một vương quốc hai thành, hai mỏ và một trại địa phương. Tài sản/nguồn/guard đều khai; nhánh mở qua nghiên cứu, không chọn khóa từ đầu. Hoàn thành vòng thành thứ hai trước tech sâu; không gọi mốc S00 là Khai Quốc khi chưa có Đại thành. Chơi tiếp sau chiến thắng.

## 9. Bàn giao

- [Art bible](art-bible.md): camera, tỷ lệ, màu, alpha và định dạng.
- [Kế hoạch asset](asset-production-plan.md): thứ tự, nghiệm thu, vai trò từng file.
- [Manifest](asset-production/asset-manifest.json), [roster](asset-production/unit-roster.json), [layout](asset-production/city-layout.json): dữ liệu sản xuất.
- [Bổ sung 02 và S00](prototype-readiness.md): các khoảng hở đã giải quyết, ngoại lệ, thứ tự dựng và ca kiểm chưa chạy.
- [Sổ hiệu chỉnh](calibration-register.md): phần còn phải đo trước/lúc làm game; không chặn phác thảo asset.
- [Lịch sử review](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md): nguồn lập luận, không ghi đè baseline hiện hành.

Chưa có benchmark, kiểm thử game hoặc playtest. Bước này chốt thiết kế và hợp đồng hình; giai đoạn 2 chưa sinh ảnh, giai đoạn lập trình chưa bắt đầu.
