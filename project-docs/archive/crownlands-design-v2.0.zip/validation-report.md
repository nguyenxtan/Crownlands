# Biên bản kiểm tra bộ tài liệu 2.0

Phiên bản 2.0 · 07/11/2026 · Kiểm tra sau khi chốt docs và chuẩn bị asset.

| Phạm vi | Kết quả |
|---|---|
| Nguồn | Bảy file `reference-docs` và U08 khớp SHA256 đã lưu |
| Bản lưu cũ | ZIP v1.3 có 29 entry, kiểm tra integrity đạt; 15 file nguồn/review/proposal còn nguyên byte |
| Liên kết | Kiểm toàn bộ liên kết Markdown tương đối trong docs và assets README, không có đích file thiếu |
| Mã quyết định | D01–D33 và ủy quyền D34; B01–B22, P01–P20, O01–O38 liên tục; I/N và CAL có namespace riêng |
| Manifest | 189 ID/path duy nhất, tên ASCII; 16 proof + 134 core bổ sung + 39 expansion; thống kê khớp |
| Phụ thuộc asset | Contract/format/path hợp lệ, ID dẫn xuất có nguồn, không có vòng phụ thuộc |
| Roster | 14 profile, năm dòng; 14 card và 14 icon dẫn xuất khớp manifest |
| Bố cục | 14 slot nhà, 16 plot (bốn mỗi loại), anchor chuẩn hóa duy nhất, footprint nền không chồng nhau |
| Phạm vi nhà | 10 loại core × ba mốc hình; kho bổ sung tái dùng sprite; Dinh điều hành thuộc expansion |
| Trạng thái hình | Toàn bộ `planned`, chưa approved, chưa có file ảnh export được tạo trong đợt này |

Đã kiểm dữ liệu bằng script trên file thực. Đây là kiểm tính nhất quán bộ bàn giao, không phải kiểm thử game hoặc QA hình ảnh. Sprite đứng cao có thể che nhau dù footprint nền không chồng; cần xem composite proof trước nhân rộng. Chưa có mô phỏng, benchmark, playtest hay bằng chứng cân bằng.

Đầu vào sản xuất: [baseline](final-design.md), [asset plan](asset-production-plan.md) và [brief 16 mẫu đầu](asset-production/briefs/first-proof-batch.md).
