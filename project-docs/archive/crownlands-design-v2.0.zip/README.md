# Crownlands — bộ tài liệu chuẩn 2.0

Phiên bản 2.0 · 07/11/2026 · Theo [bản chốt](final-design.md).

**Đã chốt thiết kế để chuyển sang giai đoạn 2: sản xuất asset.** Crownlands là webgame chiến thuật một người chơi offline, thế giới tiếp diễn qua save, năm dòng quân và ba đường Quân chế / Thánh Quang / Hắc Ảnh. Không có yêu cầu server nhiều người để chơi.

## Đọc theo thứ tự

1. [Bản chốt thiết kế](final-design.md): 22 quyết định triển khai, phạm vi chơi và những hệ thống để sau.
2. [Art bible](art-bible.md): camera, palette, scale, silhouette, alpha và cách ghép.
3. [Kế hoạch bộ asset](asset-production-plan.md): 189 export dự kiến, chia proof 16 / core bổ sung 134 / expansion 39.
4. [Brief 16 mẫu đầu](asset-production/briefs/first-proof-batch.md): đầu việc mở giai đoạn 2.

[Manifest](asset-production/asset-manifest.json), [roster 14 profile](asset-production/unit-roster.json) và [layout 14 nhà / 16 ô tài nguyên](asset-production/city-layout.json) là dữ liệu sản xuất. Mọi entry asset hiện `planned`; chưa tạo hoặc duyệt ảnh ở lần chốt docs này.

## Tra theo hệ thống

| Tài liệu | Nội dung |
|---|---|
| [Sổ quyết định](decisions.md) | D01–D34, B01–B22, xử lý đề xuất/vấn đề mở và nguồn thẩm quyền |
| [Khung lối chơi](gameplay-blueprint.md) / [định hướng](game-design.md) | Vòng chơi, lựa chọn, mốc chiến dịch và thua/phục hồi |
| [Hệ thống và cân bằng](systems-and-balance.md) | Tài nguyên, khai thác, quân, hậu cần, tiếp quản |
| [Quân và nghiên cứu](military-and-research.md) | Bậc/nhánh, kiến thức đế chế, nâng, suất và cơ sở |
| [Năng lực chiến đấu](combat-abilities.md) | Quỹ chung, trigger, cooldown và giải thích báo cáo |
| [Đoàn NPC](mobile-npcs.md) / [NPC và Đại thành](npc-and-great-cities.md) | Phe, mission, nguồn lực, chuyển quyền và thưởng B |
| [Thế giới và mở rộng](world-and-expansion.md) | Quyền đất, đánh đổi khi mở rộng, thu hẹp và tiếp tục thế giới |
| [Thiết kế kỹ thuật](technical-design.md) | Đồng hồ, thứ tự pha, bản lưu và bất biến |
| [Giao diện](interface-and-art.md) | Các màn hình và lớp hiển thị tách khỏi asset |
| [Lộ trình và kiểm chứng](roadmap-and-validation.md) | Giai đoạn docs → asset → code → hiệu chỉnh/playtest |
| [Sổ hiệu chỉnh](calibration-register.md) | 15 nhóm số/cấu hình cần đo; không mở lại shape/camera/roster |
| [Biên bản kiểm tra](validation-report.md) | Kết quả kiểm nguồn, liên kết, mã, manifest, roster và layout sau khi chốt |

## Hiệu lực và lưu trữ

Thứ tự áp dụng: chỉ đạo mới của chủ dự án → [baseline 2.0](final-design.md) cùng B01–B22 → các đặc tả hiện hành → số ruleset được chọn cho mỗi lần thử. Các file review/proposal và bộ nguồn là lịch sử lập luận, không ghi đè baseline. “Chốt” là quyết định thiết kế; không có nghĩa game đã chạy, vui hoặc cân bằng.

[D34](decisions.md) ghi ủy quyền U09. Những lựa chọn mới như ô vuông, 14/16 slot, một dự án nghiên cứu, tên nhánh và 14 profile là quyết định triển khai do Codex chốt theo ủy quyền này; không gán ngược thành câu nói của chủ dự án hoặc kết quả đã đo của Claude.

Bản trước được lưu nguyên trong [archive v1.3](archive/crownlands-design-v1.3.zip). Reviews/proposals/sources vẫn giữ file gốc để tra. Bảy tài liệu trong `reference-docs` giữ nguyên SHA256; bản U08 giữ nguyên byte. Bản Markdown này là biên tập hiện hành, không phải bản dịch/trích xuất nguyên văn đầy đủ của PDF/DOCX.

## Nguồn

| Mã nguồn | Nội dung |
|---|---|
| R01 | [Tập 01 v1.0](../reference-docs/01_Dinh_huong_va_luat_game_v1.0.docx): định hướng và D01–D18 |
| R02 | [Tập 02 v1.0](../reference-docs/02_Dac_ta_he_thong_va_can_bang_v1.0.docx): đặc tả và công thức thử |
| R03 | [Tập 03 v1.0](../reference-docs/03_Kien_truc_ky_thuat_va_du_lieu_v1.0.docx): dữ liệu, lệnh và I01–I12 |
| R04 | [Tập 04 v1.0](../reference-docs/04_Giao_dien_va_quy_chuan_my_thuat_v1.0.docx): UX01–UX10 và mỹ thuật |
| R05 | [Tập 05 v1.0](../reference-docs/05_Lo_trinh_kiem_thu_va_quan_tri_v1.0.docx): B, T01–T70 và O01–O16 |
| R06 | [Bảng cân bằng v1.0](../reference-docs/Tam_Gioi_Bang_can_bang_v1.0.xlsx): số và công thức mẫu |
| R07 | [Hồ sơ tổng hợp v1.0](../reference-docs/Tam_Gioi_Khai_Quoc_Ho_so_tong_hop_v1.0.pdf): bản PDF tham khảo |
| U01 | Trao đổi chủ dự án ngày 06–07/11/2026: tên Crownlands, làm web app trước, tách hai thư mục |
| U02 | Tổng hợp thiết kế mới ngày 07/11/2026: thế giới lâu dài, cấp 20, khai thác, hạn mức quân, Đại thành, NPC chủ động và nghịch lý mở rộng |
| U03 | Phản hồi bản đồ ngày 07/11/2026: thành trong ảnh mẫu quá lớn, NPC chưa được thể hiện rõ |
| U04 | Bảy ý tưởng tham khảo ngày 07/11/2026, lưu và phân tích trong `proposals`; toàn bộ còn là đề xuất |
| U05 | Chuyển trọng tâm sang offline một người với vương quốc NPC; D28 ghi nhận hướng, các mặc định thời gian/lưu còn là đề xuất |
| U06 | Yêu cầu review chéo Codex–Claude để tìm lối chơi logic; chưa đồng nghĩa phê duyệt mọi phương án sau review |
| U07 | Đề xuất tiến hóa quân, công nghệ toàn đế chế/cơ sở địa phương và năm bậc; chưa có lựa chọn cuối về Paladin/phép thuật |
| U08 | [Danh mục đính kèm nguyên bản](sources/2026-11-07-offline-design-addendum.md): ghi hướng chọn mới về nhánh, phe và NPC lưu động; cách triển khai chi tiết ở nguồn là đề xuất; baseline 2.0 đã chọn phạm vi hiện hành |
| C01 | Review mở rộng của Claude trước khi đổi offline |
| C02 | Claude review chinh phục vòng 1 |
| C03 | Codex phản biện mười hai điểm sau vòng 1 |
| C04 | Claude review chinh phục vòng 2 |
| C05 | Claude review tiến hóa quân và sửa thêm một số điểm vòng 2 |
| C06 | Codex tổng hợp 1.2 trước U08, tách đồng thuận và sửa cuối |
| C07 | Claude phản biện nguồn U08, nhánh/hiệu ứng và NPC lưu động |
| C08 | Codex đối chiếu sau C07; sửa cuối có nhãn, chưa được review lại hoặc chạy thử |

| U09 | Chủ dự án ngày 07/11/2026 ủy quyền chốt phương án và viết docs cuối để sang giai đoạn 2 — bộ asset; baseline 2.0 ghi lựa chọn triển khai của Codex |

[Manifest nguồn gốc](sources/reference-manifest.json) và [manifest U08](sources/offline-design-addendum-manifest.json) dùng để kiểm tra bảo toàn. Các câu “còn đề xuất” trong review/archive phản ánh lúc viết chúng, không là trạng thái hiện hành sau U09.
