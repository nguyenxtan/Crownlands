# Sổ hiệu chỉnh sau khi khóa thiết kế

Phiên bản 2.0 · 07/11/2026.

Đã khóa cấu trúc ở [baseline](final-design.md). Bảng này chứa dữ liệu cần đo trước/lúc lập trình, **không phải các phương án thiết kế đang chờ chọn để bắt đầu asset**. Giá trị chưa thử không được gắn nhãn cân bằng. Không cần vẽ asset khác khi đổi một mức sát thương hoặc thời gian.

Mã CAL01–CAL15 dành riêng cho hiệu chỉnh; C01–C08 trong danh mục nguồn vẫn chỉ các review lịch sử.

## 1. Dữ liệu cần hiệu chỉnh

| Mã | Nhóm | Đã khóa | Còn đo/cấu hình |
|---|---|---|---|
| CAL01 | Kinh tế | Bốn tài nguyên, kho riêng, 16 ô 4/4/4/4, trần 20 | Giá, sản lượng, sức chứa, thời gian, vốn đầu và tăng trưởng |
| CAL02 | Quân | Năm dòng, tier/path, roster 14 đầu | Stats, lương, sức chở, thời gian và suất có trọng số |
| CAL03 | Tương khắc | Dấu ma trận B11, không đổi bởi path | Độ lớn K và hiệu quả lệch bậc/ngân sách |
| CAL04 | Nâng/chuyển | Tại chỗ, job cả lô sống, cap giữ, một profile | Giá/thời gian, rearm, bộ test ưu thế hai đường |
| CAL05 | Năng lực | Quỹ chung, hồi thế giới, không mana, ba năng lực lõi | Dung lượng, thời hạn lượt, hồi, lượng phá và thông số report |
| CAL06 | NPC rating | Hạng 1–20 riêng, không = cấp lính | Rating theo scenario/tình báo và cách cập nhật |
| CAL07 | Hành quân | Ô vuông, site encounter, lương mang, xe đi/về | Tốc độ, chi phí dựng trại, sức chứa, ETA |
| CAL08 | Mỏ | Năng suất/kho hữu hạn, chưa depletion trong lõi | Điểm bão hòa quân, sản lượng, kho và sức chở |
| CAL09 | Chiếm/giữ | Chủ/control/job riêng, ngắt về 0 | Lực giữ tối thiểu, thời gian tiếp quản, thời gian phục hồi |
| CAL10 | Thiếu lương | Cùng preset người/NPC, game time, không giờ thật | Khoảng cứu, hệ số suy yếu/hao hụt có giới hạn |
| CAL11 | AI/đoàn | Nguồn thật, mission, tin hạn chế, không cap miễn phí | Ngân sách, chu kỳ đánh giá, biên an toàn và trần đối tượng |
| CAL12 | Đại thành | 20/20/40, base nội thành, chủ đổi dừng nguồn cũ | Thời gian ổn định/hiệu lực, scenario Đại thành |
| CAL13 | Tái lập | 1/2 chủ động hợp lệ, 1/3 mất cuối, một claim/nguồn | Thời gian/điều kiện thực hiện, vùng đến và hỗ trợ khởi lập |
| CAL14 | Nhịp chơi/mùa | Pause/tua chung, bốn mùa cosmetic | Khoảng hai quyết định có nghĩa, thời lượng mùa, mức tự dừng |
| CAL15 | Kỹ thuật | Web offline, save nguyên vẹn, không chạy bù | Cơ chế lưu cục bộ cụ thể, schema/migration, hiệu năng máy |

Không import toàn bộ R06 thành cân bằng mới. Cấu hình cũ 18 ô hoặc `field_cap=10` không còn là số sản xuất hiện hành. Nguồn cũ vẫn giữ nguyên để so, không sửa XLSX gốc.

## 2. Điều kiện không được phá khi hiệu chỉnh

- Không thêm dòng thứ sáu, tài nguyên bắt buộc thứ năm hoặc biến kiếm thành kỵ.
- Không để quỹ/nhánh xóa mọi ý nghĩa của cơ cấu quân, không lấy cùng đầu người là so sánh duy nhất.
- Không nhận thêm quân/hàng/cap qua tách/gộp, đổi chủ, chuyển nhánh hoặc tải lại.
- Không phạt theo số thành hoặc tăng quân NPC bí mật để chữa một cấu hình quá dễ.
- Không làm người chơi phải canh giờ ngoài đời; tăng tốc không đổi thứ tự cùng đầu vào logic.
- Không biến khác biệt số thành/vai trò thành nhiệm vụ bấm lặp, không khóa UX cơ bản sau research.

## 3. Bài thử trước khi gọi cân bằng

So theo giá, lương, suất, thời gian thay thế, tốc độ và mục tiêu; đổi bên/đội hình/tin; thử mới chiếm/bị vây lại, mất gốc, nâng bị đánh, quỹ bị nhiều nhóm rút, cooldown qua đổi nhánh, hàng đổi đích và save giữa hành quân.

Thử đế chế lớn đã ổn định, không chỉ mở nóng. Người chơi được phép thắng lớn. Đo active objects/events khi chạy dài; không đòi save giữ kích thước byte phẳng khi lịch sử tăng hợp lệ.

Hiện chưa có game test/mô phỏng/playtest/benchmark. Giai đoạn 2 nghiệm thu hình và hợp đồng asset, không thay các bằng chứng này.
