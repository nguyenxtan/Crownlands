# Thế giới và nghịch lý mở rộng

Phiên bản 2.0 · 07/11/2026 · Theo [bản chốt](final-design.md).

Thế giới lâu dài nghĩa là lịch sử/lãnh thổ tiếp diễn trong save, không chạy khi đóng game. Ô vuông logic, vùng thử 64×64, khuôn đầu 128×128; camera và lưới hiển thị tách logic. Bốn mùa đổi cảnh quan, không reset hoặc tạo bốn hệ kinh tế.

## Quyền và kiểm soát

Thành/site có một chủ. Ngoại thành có bên giữ; garrison, job tiếp quản và phục hồi là dữ liệu khác. Quân đi qua hoặc dừng chân không tự chiếm cả vùng. Đường biên vẽ từ quyền hợp lệ; không dùng convex hull để biến đất người khác thành của mình.

Quyền vùng Đại thành không cho sở hữu/thu kho/điều quân thành khác chủ. Màu vùng hành chính và màu chủ quyền là hai chế độ map riêng. Chưa có cơ chế cửa ải khóa đường, hàng hải hay chiếm mọi ô đất bằng việc vẽ đường nối.

## Nghịch lý mở rộng

Đế chế không yếu vì có nhiều thành; yếu khi đường tiếp tế, quân giữ, kho/xe và nhịp ổn định không theo kịp. Thành liền nhau có thể dễ giữ hơn ít thành rải rác. Đế chế lớn ổn định được quyền mạnh và thắng; không sinh quân bí mật hay phạt số thành để kéo xuống.

Core dùng chi phí có thật: giữ mỏ/trại, hành quân, lương, tập trung quân, phục hồi thành mới. Thanh tải quản trị, thuế/An dân, dự bị và tự quản hoãn. Không coi việc bấm 100 thành là hình phạt cân bằng; tuyến/cảnh báo giảm thao tác có từ đầu.

## Rút và phục hồi

Rút quân và chở hàng bằng Movement thật; không nút xóa thành để né tiếp quản. Bỏ một thành phụ không tự cấp quyền tái lập mới. Dời thủ đô đổi nơi điều hành; không cộng hai cấp nhà/kho thành một.

Tái lập từ thành cuối áp B16: chủ động hợp lệ 1/2, bị mất 1/3 cấp hoàn thành, làm tròn lên, ô rỗng vẫn 0. Không nhân lại quân/tài nguyên/đất; quyền một lần theo nguồn. Mốc chụp là **ngay trước sự kiện mất quyền thành cuối hoặc commit di dân cuối**, chỉ từ thành nguồn đó, không chọn cấp cao nhất của toàn lịch sử. Không nhận nhiều quyền bằng lặp bỏ/nhận cùng nguồn.

## Đường dài

Mốc tự nguyện Khai Quốc/Thống Nhất và biên niên sử ghi câu chuyện, không bonus sức mạnh vô hạn. Có thể tiếp tục sau thắng, không bắt giết hết quân lưu vong. Bộ môi trường bốn mùa hoàn thiện ở expansion asset; việc mô phỏng thế giới lớn cần đo riêng.

Sổ [CAL01–CAL15](calibration-register.md) và [lộ trình](roadmap-and-validation.md) đặt câu hỏi về nguồn tạo/tiêu/chuyển, đế chế lớn ổn định, thắng/quay lại sau thua; chưa có kết quả.
