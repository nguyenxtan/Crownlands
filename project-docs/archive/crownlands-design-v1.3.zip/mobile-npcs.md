# Phe và đoàn NPC lưu động

Phiên bản 1.3 · 07/11/2026. D32/D33 ghi hướng NPC có phe/quan hệ và lưu động theo nguồn U08. **Tên phe, kiểu đoàn, quyền qua biên, cap di động và quy tắc chi tiết đều là đề xuất/cần khóa.** Chưa mô phỏng hoặc playtest.

## 1. Phe khác nhánh quân

Chủ của một đoàn là một phe có lịch sử tài sản. `path_bias` chỉ là ưu tiên nghiên cứu/tuyển của controller; không làm mọi quân cùng nhánh hoặc tự gán quan hệ.

Đề xuất bản thử có trung lập/thù địch, quan hệ cấu hình theo cặp có hướng hoặc đối xứng rõ. Không tự suy phe Thánh là bạn, phe Hắc là địch. Những tên Vương triều Thiết Quan, Giáo đoàn Bình Minh, Hắc triều Tro Tàn và các tên U08 khác là nội dung tham khảo, chưa phải danh sách bắt buộc.

Quan hệ NPC có thể đổi theo luật sẽ chọn; giao thương, xin qua biên và ngoại giao nhiều điều khoản là phạm vi riêng. Một icon nhánh không thay dấu chủ hoặc trạng thái quan hệ.

## 2. Đoàn là lực lượng có nhiệm vụ

Đề xuất dùng đạo quân/cohort và thêm nhiệm vụ, không tạo bản sao thứ hai của quân. Đoàn có thể tuần tra, viễn chinh, rút về, chuyên chở hoặc tìm nơi ở nếu tính năng đó được bật.

Chu trình: đánh giá mục tiêu → kiểm tra nguồn/lương → cam kết → hành quân → dừng/quan sát → hành động tại địa điểm → về hoặc chọn lại. Nhiệm vụ đang chạy được lưu, không quyết định lại hoàn toàn mỗi lần load.

Đoàn có ích nhờ mang quân/hàng, làm mới tình báo, giữ/đánh mục tiêu thật và thay đổi sức ép chiến dịch. Chiến lợi phẩm chỉ từ tài sản có nguồn, không là gói thưởng cố định treo trên một icon chạy.

## 3. Ba nguồn tổ chức để xem xét

| Loại đề xuất | Nguồn quân và biên chế | Hậu cần/tuyển | Mất nơi dựa |
|---|---|---|---|
| Có căn cứ | Quân từ thành, vẫn dùng gốc dù đi xa | Kho/xe/lương thật; tuyển qua cơ sở | Mất riêng gốc khi phe còn thành: chờ/chuyển biên chế theo O18, không tự thành du mục |
| Lưu vong/tàn quân | Chỉ phần thực sự còn sống/rút thoát; không có suất mới | Dùng nguồn mang theo và hành động đã hỗ trợ; không tự tuyển khi không có nguồn hợp lệ | Phe không còn thành có thể tìm nơi hợp lệ bằng quy trình chung; không được cấp thành/quân miễn phí |
| Du mục | `capacity_model = mobile` chỉ cho loại NPC được khai báo | Ngân sách, phương tiện, vật chất, thời gian và điểm bổ sung có luật | Xe/hàng mất có thể giảm năng lực theo công thức sẽ chọn, không xóa quân lập tức |

Mất một thành gốc không đồng nghĩa cả phe đã lưu vong nếu còn các thành khác. `capacity_model = none` nếu dùng chỉ có nghĩa không có nguồn tuyển/suất mới, không là cap vô hạn cho lực lượng hiện hữu.

NPC du mục là khác biệt tổ chức có khai báo. Cùng luật nghĩa cùng tính đúng nguồn, thời gian, di chuyển và tầm nhìn, không bắt mọi phe có cơ sở giống nhau. D22 của người chơi không đổi: đưa quân khỏi thành không tạo thêm suất hoặc tự nhận mô hình di động.

## 4. Chạm trán tại địa điểm, giới hạn bản thử

**Mặc định đề xuất:** đoàn dùng chuỗi lệnh hành quân thường tới các địa điểm hiện hữu như mỏ, trại, thành, điểm dừng được đặc tả. Có ETA và khoảng dừng, không thêm waypoint chiến đấu bắt buộc vào mọi xe/đoàn rút.

Trận chỉ xét tại địa điểm khi có quan hệ/lệnh cho phép và hành động hợp lệ. Hai đoàn cắt nhau giữa đường **không tự có trận**. Chưa có cướp xe, hộ tống hoặc phá tiếp tế trên đoạn đường. Muốn gây sức ép phải tới nơi mục tiêu sẽ dừng hoặc tấn công mỏ/trại/cổng.

Một địa điểm mới chỉ là “điểm dừng chiến đấu” khi có luật quyền, vị trí, sức chứa và chạm trán; không thêm hàng loạt waypoint ngầm rồi gọi là chưa có đánh chặn. Nếu giới hạn đi xuyên nhau không chấp nhận được, O37 phải mở hẳn thiết kế đoạn đường trước, không vá bằng hoạt ảnh.

## 5. Tầm nhìn và quyết định

Đoàn biết quân/hàng của mình, dùng quan sát/trinh sát/báo cáo có mốc để đánh giá bên khác. Truy đuổi tới địa điểm thấy gần nhất; tới không gặp thì tìm tin mới hoặc bỏ theo ngân sách nhiệm vụ. Không đọc vị trí/đích bí mật chỉ vì chung bộ nhớ máy.

AI cần kiểm tra lương cho hành trình và trở về, mục tiêu đã đổi chủ, đường/đích không còn hợp lệ và sức chứa. Có thể quay về hoặc đổi kế hoạch thay vì đi chết. Không hạ mức an toàn xuống dưới điều kiện khả thi chỉ vì lâu chưa đánh.

Khi ước lượng năng lực đối thủ, chỉ dùng profile đã quan sát; nếu mốc hồi chưa biết thì một giả định thận trọng có nhãn. Không biết cooldown không có nghĩa được đọc field ẩn.

## 6. Nguồn xuất hiện và giới hạn

Nguồn hợp lệ đề xuất: xuất từ căn cứ có quân; phần rút thực sau thất bại; hoặc tạo ban đầu/cấp theo ngân sách preset tại vị trí vào thế giới có khai báo. “Ngoài tầm nhìn” **không tự làm spawn hợp lệ**. Không sinh quân nguy hiểm trong thành người chơi hoặc scale bí mật theo tài sản người chơi.

Trần số đoàn và lịch cấp theo phe/toàn thế giới là công cụ vận hành mô phỏng đề xuất, không trần quân tùy tiện của người chơi. Có trần không thay yêu cầu nguồn/lương, và ngân sách hồi là nguồn tạo mới cần sổ, không gọi nhầm là bảo toàn.

Tuyển/bổ sung/đổi xe cần nơi, thời gian và vật chất. Chưa mặc định du mục tự tái sinh hàng hay lưu vong được quân đầy trở lại. Chia/gộp giữ quân, xe, hàng, gốc và trạng thái hồi; không nhặt một đoàn để nhân cả lực lượng lẫn phần thưởng.

## 7. Kết thúc nhiệm vụ và thế giới dài

Có căn cứ còn hợp lệ thì về/gộp thủ quân mà giữ nguồn. Không còn mục tiêu thì chọn lại trong số lần/ngân sách giới hạn; không có nơi về thì trạng thái chờ/tàn quân có chủ và thông báo, không tự xóa.

Giải tán là hành động có lý do và ghi nguồn tiêu hao; hàng/xe đi đâu phải có luật. Không xóa quân còn sống để dọn nhẹ máy. Định cư/chiếm thành cần điều kiện chung, không sinh đất/thành mới chỉ vì dừng chân.

Giữ tối đa một bước **mission** đang hiệu lực cho mỗi phiên bản nhiệm vụ; lịch đói hoặc biến động khác có thể độc lập. Không tuyên bố mỗi đoàn chỉ có đúng một event cho mọi hệ thống rồi bỏ qua cạn lương giữa đường. Event cũ bị vô hiệu và được dọn theo luật an toàn.

Đo số đối tượng sống/event hợp lệ và tăng trưởng save theo lịch sử. File save không nhất thiết phẳng qua ba năm vì lịch sử vẫn tăng; có thể tổng hợp báo cáo/ledger đã đóng với số dư đối soát, không xóa nguồn quan trọng hoặc vật chất hiện hữu.

## 8. Dữ liệu và UI

Đoàn cần: faction, role, cohorts với line/tier/path/readiness, vị trí hoặc movement, đích/ETA, stop_until, cargo/food/wagons, capacity source/model, mission/mốc/abort rule, tình báo, ngân sách đã dùng và phiên bản.

UI bản đồ dùng icon nhỏ của đoàn + chủ/quan hệ + vai trò được quan sát. Bấm mở tình báo có thời điểm; không hiện mọi mục tiêu, đích, hàng hoặc quân bí mật. Phe/nhánh/quan hệ không dùng một màu duy nhất thay cho cả ba.

Lưu cả nhiệm vụ/hành trình và quyết định đã commit. Pause/tua/đóng game theo đồng hồ chung; không reset lương, mốc hồi hoặc ngân sách khi load.

## 9. Lát cắt đề xuất

L: một đoàn có căn cứ đi qua 3–4 địa điểm, mang hàng/lương thật, biết quan sát/đánh mục tiêu yếu/rút khi không đủ. Dùng cùng engine hành quân, không thêm du mục trước chỉ để có icon chạy.

B: thêm phe thứ hai, quan hệ khác nhau và một case mất thành cuối còn tàn quân. Lưu vong có thể thử trước du mục vì dùng lực lượng đã tồn tại; chưa phải hệ phục quốc đầy đủ. Du mục/cap di động và tương tác giao thương/qua biên/định cư làm sau khi có đặc tả O36/O38.

C07:N8–N15 và các ca nguồn/cap/cleanup còn chưa chạy. Một patrol thành công không chứng minh đã có du mục, thông minh chiến lược hoặc thế giới tự vận hành cân bằng.
