# Giao diện và mỹ thuật

Phiên bản 1.3 · 07/11/2026. Kế thừa R04/U03, áp D28 offline. Thành tròn, ô cố định, một kiến trúc, bốn mùa và báo cáo giữ hướng đã chọn. Bậc quân, hình ảnh và bố trí cụ thể còn đề xuất. Xem [quân/nghiên cứu](military-and-research.md).

## 0. Điều khiển thời gian offline

Đề xuất có pause, tốc độ, tua tới mốc đáng chú ý, lưu/tải và cảnh báo tự dừng. Luôn hiển thị thời gian game, phân biệt ETA game với ước tính chờ đời thực. Pause dừng mọi phe, không để UI báo thành bị đánh trong thời gian đã đóng game.

Dự báo là thông tin có mốc, không lời hứa chắc thắng. Cửa lệnh/hiệu lực pause theo preset O10/O32; đổi tốc độ không làm client tự áp kết quả.

## 1. Mục đích của bản đồ

Bản đồ thế giới giúp người chơi tìm mục tiêu, hiểu khoảng cách, chủ quyền và tuyến hậu cần. Cảnh chi tiết thành giúp xây dựng. Hai màn có thể dùng cùng asset gốc nhưng khác tỷ lệ và mức chi tiết.

Phản hồi U03: ảnh đầu cho thành quá lớn và chưa thể hiện NPC rõ. **Không dùng tỷ lệ ảnh đó làm tỷ lệ bản đồ game.** Ảnh làm lại cũng chỉ là bản thử, chưa được duyệt làm chuẩn.

## 2. Ba mức zoom

| Mức | Thể hiện | Lược bớt |
|---|---|---|
| Thế giới | Vùng, màu/viền đế chế, Đại thành và dấu quan trọng | Nội thất thành, từng xe, nhãn mục tiêu nhỏ |
| Khu vực | Thành nhỏ, trại, mỏ, NPC, tuyến và đường di chuyển | Từng công trình và chi tiết cây/đá |
| Cận cảnh bản đồ | Địa điểm, đường tiếp cận, đoàn quân và tương tác | Không biến thành màn nội thành tự động |

Bấm vào thành mở thông tin hoặc vào màn nội thành riêng. Zoom không được làm một thành chiếm gần cả màn hình trước khi người chơi chọn xem thành đó.

**Mục tiêu thử tỷ lệ:** tại viewport bản đồ khoảng 1440 px, thử icon thành thường khoảng 24–40 px, Đại thành khoảng 1,5–2 lần, rồi kiểm tra mật độ thật và thiết bị. Đây là thông số THỬ NGHIỆM, không phải scale địa lý đã khóa. Kích thước vùng bấm có thể lớn hơn hình, cần xử lý chồng lấn bằng chọn/zoom hoặc danh sách.

Không phải mọi cấp cần một icon lớn hơn. Đổi màu mái, đường nét, huy hiệu hoặc vài mốc hình để giữ mật độ. Bậc thành không được che lấp thông tin NPC/đế chế và mục tiêu đang chọn.

## 3. Ngôn ngữ ký hiệu địa điểm

| Đối tượng | Hình nhận diện đề xuất | Thông tin ngắn |
|---|---|---|
| Thành của mình | Thành vòng tường nhỏ + dấu chủ | Tên và bậc khi đủ chỗ |
| Thành người khác | Cùng bộ kiến trúc + dấu chủ khác | Chủ, tình trạng quan hệ theo luật |
| Trại của mình | Lều/trại không có vòng tường + cờ chủ | Lương/cảnh báo khi liên quan |
| Trại NPC | Lều + huy hiệu NPC khác hình huy hiệu chủ | `Trại NPC · Hạng 5` |
| Thành NPC | Thành nhỏ + huy hiệu NPC và icon thành | Hạng, tình trạng trinh sát |
| Đại thành NPC | Thành đặc trưng vừa phải + biểu tượng vương quyền | Loại, hạng, vùng; không phóng to thành cảnh chính |
| Đại thành đã chiếm | Giữ hình loại, đổi dấu chủ | Chủ, vùng và trạng thái kiểm soát |
| Mỏ | Icon gỗ/đất sét/sắt/lương + dấu kiểm soát | Loại, hạng và cảnh báo kho nếu có quyền |
| Thành bỏ hoang | Hình thành xuống cấp + dấu trạng thái riêng | Nguồn/trạng thái được công khai, không giả là trại |

Huy hiệu và màu là đề xuất, chưa khóa palette. Phân biệt **loại địa điểm**, **chủ hiện tại** và **thái độ/khả năng tấn công**; không coi mọi NPC đều là kẻ thù chỉ vì cùng màu đỏ. Thành NPC đổi chủ phải giữ loại địa điểm nhưng thay rõ dấu quyền.

Không chỉ dựa vào màu: dùng hình huy hiệu, ký hiệu và nhãn. Nhãn cấp luôn có tên thang như “cấp công trình”, “bậc thành”, “hạng NPC”. Bản đồ nhiều mục tiêu cần lọc và ẩn bớt nhãn theo zoom; không hiện tất cả tên cùng lúc.

## 4. Bảng chọn mục tiêu

Hiển thị theo quyền và tình báo:

- Loại địa điểm, tọa độ, chủ, vùng và hạng/bậc liên quan.
- Tin trinh sát gần nhất với thời điểm; số quân không biết hiển thị là chưa biết.
- Khoảng cách hoặc thời gian tới theo lực lượng được chọn, không dùng cùng ETA cho mọi đội.
- Hành động hợp lệ: xem, trinh sát, hành quân, đánh, tiếp tế, khai thác hoặc chiếm theo hệ thống đã mở.
- Điều kiện thiếu và rủi ro có thể biết. Chỉ được dự báo theo thông tin người chơi được phép có.

Không ghi sẵn quân địch chính xác chỉ để bản mẫu nhìn đầy đủ. Tooltip không che mục tiêu và đường đi; khung chi tiết trên điện thoại có thể mở từ dưới. Chọn nhầm mục tiêu không gửi quân ngay.

## 5. Các lớp bản đồ

Địa hình, đường, vùng hành chính, quyền đất, địa điểm, đoàn quân, tuyến, cảnh báo và nhãn là các lớp có thể cập nhật riêng. Nền cảnh quan không chứa vĩnh viễn biên giới, cấp NPC hoặc đường của một đế chế.

Lớp “vùng Đại thành” khác lớp “đất thuộc người chơi”. Màu một vùng không ngụ ý chủ Đại thành sở hữu toàn bộ tài sản trong đó.

Đường hành quân và tiếp tế phân biệt bằng ký hiệu/họa tiết. Có hướng, trạng thái và ETA khi chọn. Biểu tượng di chuyển không phải hoạt cảnh chiến đấu và không được quyết định vị trí nghiệp vụ phía client.

Hình ô vuông/lục giác, kích thước, lục địa và hàng hải chưa khóa. Mẫu vẽ có đường cong hoặc không có lưới không tự quyết định topology hay thuật toán tìm đường.

## 6. Màn nội thành và quản trị

Nội thành tròn, mỗi ô có vị trí và vùng bấm ổn định. Không kéo/đổi chỗ nhà. Hình giàn giáo chỉ xuất hiện khi công việc chạy; hình cấp mới chỉ áp khi hoàn thành.

Bảng công trình có cấp, chức năng, chi phí, phần giữ/khả dụng, điều kiện và thời gian. Không thể nâng phải có lý do, không chỉ nút mờ.

Màn quân phân biệt tổng quân, nguồn biên chế, quân sẵn có ở đây, đang đi, giữ mỏ và đang tuyển. Nếu thử cap có trọng số, luôn hiển thị cả quân số và suất, không thay “1.000 quân” bằng “1.000 suất” mà không giải thích.

Tổng quan nhiều thành ưu tiên ngoại lệ: nơi sắp đói, thiếu xe, kho đầy, thành mới chiếm và lệnh thất bại. Có lọc, phân trang và thao tác có ngân sách. Không dùng bảng hàng trăm dòng bấm lặp làm độ khó.

## 7. Hậu cần, báo cáo và phục hồi

Tuyến cần dự báo cung/ngày hoặc giờ, nhu cầu cùng đơn vị, lịch chuyến đã đi, lượng xe, mức giữ tại nguồn và thời điểm thiếu dự kiến. Phân biệt thiếu sản lượng liên tục với khoảng trống giữa hai chuyến. Người chơi phải thấy cách sửa cảnh báo.

Báo cáo trận thể hiện lực lượng được phép biết, bố trận, tổn thất, chiến lợi phẩm, tác động kiểm soát và nguyên nhân chính theo luật. Không cần dựng cảnh lính đánh nhau.

Xem trước tái lập nói rõ cấp từng nhà dự kiến, phần không khôi phục, điều kiện chức năng, quân còn ở xa và nơi có thể tới. Không dùng một con số “giữ 50%” gây hiểu rằng giữ cả quân/kho/đất.

## 7.1. Thể hiện tiến hóa quân

Bản đồ dùng icon dòng quân, dấu chủ và huy hiệu bậc/nhóm khi cần; không vẽ mỗi lính hoặc 25 loại đạo quân khổng lồ. Bảng quân/portrait thể hiện khác biệt giáp, khiên, vũ khí và tư thế theo bậc đã có trong bản thử.

Hiển thị rõ quân số, dòng/bậc, suất đang dùng/giữ, nơi đóng và phần đang nâng. Quân đang nâng vẫn có mặt trong phòng thủ, không hiển thị như đã biến mất. Nút nâng nói đủ tech/cơ sở/kho/suất hay thiếu gì.

Phân biệt tech đã mở với quân đã trang bị. D31 có hướng năng lực/nhánh; cùng phong cách chung, không tự thành ba nền văn minh. Tên Paladin còn tạm, là kỵ. 45 profile theo phương án đầy đủ không đòi 45 hoạt cảnh; D09 giữ báo cáo.

## 7.2. Nhánh và năng lực

Bảng quân hiển thị dòng/bậc/nhánh độc lập, tình trạng sẵn sàng và còn hồi theo đồng hồ game. Chuyển nhánh nói profile/chi phí/suất nào thay đổi, không cho hiểu nghiên cứu xong đã đổi toàn quân.

Báo cáo gộp hợp lý theo lượt/nguồn: quỹ bảo hộ tạo và bị trừ/phá bao nhiêu, sát thương theo dòng, lý do không kích hoạt. Không chỉ ghi “Thánh mạnh hơn”, không thêm thanh mana hoặc điều khiển phép trong trận mặc định.

## 7.3. Phe và đoàn lưu động

Icon nhỏ cho đoàn có dấu chủ/quan hệ và role quan sát được; nhánh là lớp khác, không dùng một màu cho cả ba. Nhãn có thể là “Tuần tra”, “Thương đoàn”, “Tàn quân” khi thông tin được biết; tên phe còn là nội dung tham khảo.

Bấm xem tin có mốc, quân/hàng/đích trong phạm vi trinh sát; không lộ mission/đích bí mật. Nêu rõ trong bản thử đoàn chỉ chạm trán tại địa điểm. Không vẽ hiệu ứng va chạm giữa đường khiến người chơi tưởng đã có giao chiến.

Đây là yêu cầu thông tin, chưa tạo hình/asset mới theo U08. Xem [năng lực](combat-abilities.md) và [đoàn](mobile-npcs.md).

## 8. Quy cách asset đề xuất

Giữ hướng tươi sáng, cách điệu, sắc nét và đồng nhất. Chọn một camera, tỷ lệ, ánh sáng, chất liệu và bảng màu cho từng nhóm màn. Không trộn nhiều nền văn minh do có ảnh riêng lẻ đẹp.

Tách nhóm asset:

1. Nền/địa hình có thể ghép theo vùng.
2. Icon thế giới nhỏ của thành, trại, NPC và mỏ.
3. Công trình nội thành chi tiết theo mốc phát triển.
4. Biểu tượng quân/tài nguyên/trạng thái, huy hiệu chủ và chọn mục tiêu.
5. Lớp mùa, công trường, hư hại và hiệu ứng cảnh báo nếu được duyệt.

Mỗi asset có ID, nhóm, kích thước, điểm neo, vùng hình, vùng bấm, mùa, mốc phát triển, phiên bản và nguồn/quyền dùng. Tên file tiếng Anh ASCII dạng `world-npc-camp-tier-01.png`; đây là ví dụ, không hàm ý đã có asset.

Bốn mùa giữ vị trí, vùng bấm và bố cục. Thử vài mốc ngoại hình trong thang 1–20; không mặc định cần 20 ảnh × 4 mùa cho mỗi nhà. Hệ thống AI, Blender và sửa 2D là hướng sản xuất được tham khảo, chưa có pipeline hay thư viện asset hoàn chỉnh.

## 9. Cổng duyệt mẫu

- Ở kích thước xem thật, tìm được thành, trại, NPC và mỏ mà không cần đoán màu.
- Hiển thị nhiều địa điểm mà thành không chiếm mất bản đồ; bảng chọn không che điểm đang chọn.
- Mức zoom rộng vẫn phân biệt được chủ quyền và vùng, không cần nội thất thành.
- Tin cũ được ghi thời điểm; bí mật không bị lộ; nhãn không chồng hoặc quá nhỏ.
- Kéo/zoom/chạm có mục tiêu rõ, không vô tình phát lệnh chiến tranh.
- Cùng địa điểm qua bốn mùa không đổi vùng tương tác.

Chỉ sau khi duyệt tỷ lệ, ký hiệu và một cảnh tương tác mẫu mới sản xuất asset hàng loạt. Hai ảnh sinh thử ngày 07/11 không qua cổng này mặc nhiên.
