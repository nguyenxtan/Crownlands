# Crownlands

> **Hướng hiện hành:** D28 offline một người; D29–D33 ghi thêm tiến hóa quân/Học viện, nhánh Thánh và đối lập có năng lực, NPC có phe/quan hệ và lưu động theo U08. Bộ 1.3 đã đối chiếu với Claude; tên nhánh, kỹ năng, 14/45 profile và mô hình đoàn cụ thể vẫn là đề xuất để thử. Bắt đầu từ [khung lối chơi](gameplay-blueprint.md).

Bộ tài liệu làm việc hiện hành của dự án, cập nhật ngày 07/11/2026. Crownlands chuyển hướng thành game chiến thuật một người chơi offline trong một thế giới tiếp diễn qua bản lưu. Chiếm thêm lãnh thổ đem lại tiềm lực, đồng thời làm tăng nhu cầu bảo vệ, tiếp tế và tổ chức. Công nghệ web vẫn là một ứng viên, chưa khóa runtime.

Đây là phiên bản tài liệu 1.3, chưa phải phiên bản game. Chưa có mô phỏng, playtest, benchmark hoặc implementation xác nhận các cơ chế. Các file `reviews`/`proposals` giữ lịch sử lập luận; đọc kết luận hiện hành và sổ quyết định để tránh kế thừa ý đã bị rút.

## Đọc từ đâu

| Tài liệu | Mục đích |
|---|---|
| [Khung lối chơi offline](gameplay-blueprint.md) | Bản đọc đầu: vòng chơi, chinh phục, thời gian, NPC và phạm vi A1/A2′/L/B |
| [Quyết định và vấn đề còn mở](decisions.md) | Phân biệt điều chủ dự án đã chọn với phương án còn phải thử |
| [Định hướng và vòng chơi](game-design.md) | Trải nghiệm, phạm vi, tiến trình và đường phục hồi |
| [Hệ thống và cân bằng](systems-and-balance.md) | Kinh tế, quân, hạn mức, mỏ, hậu cần và chiến đấu |
| [Quân đội và nghiên cứu](military-and-research.md) | Bậc, kiến thức/cơ sở, tuyển/nâng/chuyển và giới hạn |
| [Nhánh và năng lực](combat-abilities.md) | Hướng Thánh/đối lập, quỹ bảo hộ, hồi và scope thử |
| [Phe và đoàn NPC](mobile-npcs.md) | Quan hệ, nhiệm vụ, căn cứ/tàn quân/du mục và giới hạn chạm trán |
| [Thế giới và mở rộng](world-and-expansion.md) | Nghịch lý mở rộng, thế giới lâu dài và chống tích lũy áp đảo |
| [NPC và Đại thành](npc-and-great-cities.md) | Loại mục tiêu, quyền vùng, thưởng 20/20/40 và đổi đô |
| [Thiết kế kỹ thuật](technical-design.md) | Mô phỏng cục bộ, đồng hồ, cửa lệnh và bản lưu |
| [Giao diện và mỹ thuật](interface-and-art.md) | Bản đồ, nhận diện NPC, các mức zoom và quy cách asset |
| [Lộ trình và kiểm chứng](roadmap-and-validation.md) | Lát cắt A1/A2′/L/B, ca thử chưa chạy và loại yêu cầu online cũ |
| [Nhật ký cập nhật](CHANGELOG.md) | Nội dung thay đổi so với hồ sơ gốc |
| [Phản biện của Claude](reviews/2026-11-07-expansion-review.md) | Lập luận tư vấn, các đường khai thác và giới hạn của review |
| [Bảy ý tưởng tạo lựa chọn](proposals/2026-11-07-hard-choices.md) | Tham khảo về dự bị, tự quản, mỏ, hợp đồng, thu hẹp và thủ đô dự phòng; chưa duyệt |
| [Đề xuất offline và chinh phục](proposals/2026-11-07-offline-conquest.md) | Bản xuất phát của Codex để Claude phản biện, trước khi thống nhất thiết kế |
| [Review chinh phục vòng 1](reviews/2026-11-07-offline-conquest-round-1.md) | Phản biện đầu của Claude |
| [Codex phản biện lại](reviews/2026-11-07-offline-conquest-codex-response.md) | Mười hai điểm phản biện và trả lời tám câu hỏi |
| [Review chinh phục vòng 2](reviews/2026-11-07-offline-conquest-round-2.md) | Điểm đã sửa, lựa chọn còn khác và ca kiểm chứng chưa chạy |
| [Tiến hóa quân và nghiên cứu: đầu vào](proposals/2026-11-07-military-progression.md) | Lưu ý tưởng chủ dự án và câu hỏi Codex đã gửi review |
| [Claude review quân](reviews/2026-11-07-military-progression-review.md) | Các phản ví dụ, 12 ca chưa chạy và khuyến nghị |
| [Kết quả review 1.2](reviews/2026-11-07-cross-review-resolution.md) | Lịch sử chinh phục/quân trước U08, phần bị thay được ghi rõ |
| [Bổ sung Thánh/đối lập và NPC lưu động](proposals/2026-11-07-branches-and-mobile-npcs.md) | Bản xuất phát Codex theo nguồn U08 |
| [Claude review U08](reviews/2026-11-07-branches-and-mobile-npcs-review.md) | Phản ví dụ, hướng mô hình và N1–N15 chưa chạy |
| [Đối chiếu cuối U08](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md) | Phần tiếp thu, Codex sửa thêm và phạm vi đề nghị 1.3 |

Tên thư mục và file dùng tiếng Anh; nội dung dùng tiếng Việt. `reference-docs` giữ nguyên các file gốc, `project-docs` chứa bản biên tập hiện hành.

## Trạng thái nội dung

| Nhãn | Ý nghĩa |
|---|---|
| **CHỐT** | Lựa chọn chủ dự án ghi rõ; không tự sửa khi triển khai |
| **CHỐT VỀ HƯỚNG** | Đích thiết kế đã chọn; công thức, điều kiện hoặc con số triển khai vẫn mở |
| **ĐỀ XUẤT** | Phương án được giữ để xem xét, chưa phải luật phát hành |
| **THỬ NGHIỆM** | Cấu hình hoặc phép tính dùng cho prototype/mô phỏng, chưa cân bằng |
| **CHƯA QUYẾT** | Cần có quyết định trước khi mở tính năng liên quan |
| **HOÃN** | Giữ trong hồ sơ, chưa thuộc lát cắt đầu được đề xuất |

Các phần kỹ thuật, công thức và kế hoạch trong bộ này mặc định là **ĐỀ XUẤT**, trừ nội dung có mã D và trạng thái rõ trong `decisions.md`. Việc đưa một phản biện vào tài liệu không có nghĩa chủ dự án đã duyệt cách giải quyết của phản biện đó.

## Thứ tự nguồn

1. Quyết định mới của chủ dự án, có ngày và phạm vi, được ghi trong `decisions.md`.
2. Quyết định D01–D18 của hồ sơ gốc, khi chưa có lựa chọn mới thay thế.
3. Các đặc tả và cấu hình thử được chọn cho từng đợt kiểm chứng.
4. Tư vấn và ý tưởng mở rộng. Chúng không tự ghi đè ba lớp trên.

Nếu hai đoạn mâu thuẫn, tra sổ quyết định và ghi vấn đề mở; không tự chọn đoạn thuận tiện nhất để lập trình. Thay đổi đang mở có thể thử trong môi trường kín bằng một cấu hình được ghi tên và phiên bản.

## Nguồn và phạm vi chuyển đổi

| Mã nguồn | Nội dung |
|---|---|
| R01 | [Tập 01 v1.0](../reference-docs/01_Dinh_huong_va_luat_game_v1.0.docx): định hướng và D01–D18 |
| R02 | [Tập 02 v1.0](../reference-docs/02_Dac_ta_he_thong_va_can_bang_v1.0.docx): đặc tả và công thức thử |
| R03 | [Tập 03 v1.0](../reference-docs/03_Kien_truc_ky_thuat_va_du_lieu_v1.0.docx): dữ liệu, lệnh và I01–I12 |
| R04 | [Tập 04 v1.0](../reference-docs/04_Giao_dien_va_quy_chuan_my_thuat_v1.0.docx): UX01–UX10 và mỹ thuật |
| R05 | [Tập 05 v1.0](../reference-docs/05_Lo_trinh_kiem_thu_va_quan_tri_v1.0.docx): B, T01–T70 và O01–O16 |
| R06 | [Bảng cân bằng v1.0](../reference-docs/Tam_Gioi_Bang_can_bang_v1.0.xlsx): số và công thức mẫu |
| R07 | [Hồ sơ tổng hợp v1.0](../reference-docs/Tam_Gioi_Khai_Quoc_Ho_so_tong_hop_v1.0.pdf): bản PDF tham khảo |
| U01 | Trao đổi chủ dự án ngày 06–07/11/2026: tên Crownlands, làm web app trước, tách hai thư mục |
| U02 | Tổng hợp thiết kế mới ngày 07/11/2026: thế giới lâu dài, cấp 20, khai thác, hạn mức quân, Đại thành, NPC chủ động và nghịch lý mở rộng |
| U03 | Phản hồi bản đồ ngày 07/11/2026: thành trong ảnh mẫu quá lớn, NPC chưa được thể hiện rõ |
| U04 | Bảy ý tưởng tham khảo ngày 07/11/2026, lưu và phân tích trong `proposals`; toàn bộ còn là đề xuất |
| U05 | Chuyển trọng tâm sang offline một người với vương quốc NPC; D28 ghi nhận hướng, các mặc định thời gian/lưu còn là đề xuất |
| U06 | Yêu cầu review chéo Codex–Claude để tìm lối chơi logic; chưa đồng nghĩa phê duyệt mọi phương án sau review |
| U07 | Đề xuất tiến hóa quân, công nghệ toàn đế chế/cơ sở địa phương và năm bậc; chưa có lựa chọn cuối về Paladin/phép thuật |
| U08 | [Danh mục đính kèm nguyên bản](sources/2026-11-07-offline-design-addendum.md): ghi hướng chọn mới về nhánh, phe và NPC lưu động; cách triển khai chi tiết còn đề xuất/cần khóa |
| C01 | Review mở rộng của Claude trước khi đổi offline |
| C02 | Claude review chinh phục vòng 1 |
| C03 | Codex phản biện mười hai điểm sau vòng 1 |
| C04 | Claude review chinh phục vòng 2 |
| C05 | Claude review tiến hóa quân và sửa thêm một số điểm vòng 2 |
| C06 | Codex tổng hợp 1.2 trước U08, tách đồng thuận và sửa cuối |
| C07 | Claude phản biện nguồn U08, nhánh/hiệu ứng và NPC lưu động |
| C08 | Codex đối chiếu sau C07; sửa cuối có nhãn, chưa được review lại hoặc chạy thử |

U02 và U08 là phần tổng hợp người dùng cung cấp. Chỉ các hướng được nguồn ghi đã chốt/đã chọn được ghi D ở mức tương ứng; không suy nhãn đó sang mọi cách triển khai. U08 được giữ nguyên byte và có [manifest riêng](sources/offline-design-addendum-manifest.json).

`project-docs` chưa có tài liệu trước lần cập nhật này và không có PDF cần rã. Bộ Markdown được biên tập từ nguồn, **không phải bản trích xuất nguyên văn đầy đủ** của PDF/DOCX. Chi tiết cũ chưa được chép lại vẫn có thể tra trong R01–R07, với trạng thái gốc và các thay đổi được ghi rõ ở bộ hiện hành. Không dùng công thức cũ cho một hệ thống mới nếu thiếu đơn vị hoặc phạm vi áp dụng.

[Danh mục SHA256](sources/reference-manifest.json) dùng để xác nhận bảy file tham khảo không bị thay đổi trong lần biên tập này.

## Những điều chưa được duyệt

Cloudflare + PostgreSQL, 20–50 người thật thử, trần 5–12 thành, giới hạn mặt trận và giờ nghỉ là tư vấn theo bối cảnh cũ, không phải yêu cầu offline. Runtime, lưu/tải và đóng gói còn O15/O32. I–V, kiến thức toàn đế chế, một dự án, các tên nhánh, từng kỹ năng, 14/45 profile, cap du mục, luật cửa và thứ tự cùng mốc vẫn là đề xuất. D29–D33 chỉ ghi hướng được U08 xác nhận. Paladin thuần quân sự/hoãn phép là khuyến nghị 1.2 đã bị thay, không dùng làm giới hạn hiện hành.

Hai ảnh bản đồ sinh thử chỉ để nhận xét phong cách và tỷ lệ. Chưa có ảnh nào được duyệt làm bản đồ chuẩn, asset sản xuất hoặc bằng chứng về hình ô và cấu trúc thế giới.

Các tài liệu trong `proposals` giữ ý tưởng, không tự thêm quyết định D hoặc phạm vi MVP. C01 là review trước đổi hướng; C02–C06 là chuỗi 1.2, C07–C08 bổ sung U08 cho 1.3. U04 không bắt triển khai cả bảy ý tưởng. Khi review cũ khác với C08/bộ hiện hành, giữ nó như lịch sử, không coi cả hai là luật cùng áp dụng.
