# Khung lối chơi Crownlands offline

Phiên bản 1.3 · 07/11/2026. Bản tổng hợp sau review chéo Codex–Claude.

**D28 chốt hướng offline một người. Các cơ chế và mặc định thử bên dưới là ĐỀ XUẤT, chưa phải luật được chủ dự án duyệt.** Review đã kiểm tra lập luận và chỉ ra rủi ro; chưa có mô phỏng, playtest hoặc game chạy được.

## 1. Trải nghiệm muốn tạo

Từ một thành nhỏ, người chơi tổ chức đế chế, nuôi quân và chọn các chiến dịch trong một thế giới có vương quốc NPC hoạt động. Quân dần thay đổi trang bị và hình dáng; mở công nghệ không tự biến mọi quân thành tinh nhuệ.

Một quyết định tốt có thể là chiếm thêm đất, giữ mỏ rồi dừng, để đối thủ rút, hoặc bỏ mục tiêu để bảo toàn quân. Mạnh lên và thắng lớn là phần thưởng; game không bí mật sinh quân địch hoặc trừ sức mạnh theo số thành để kéo người chơi xuống.

**Vòng lõi:** xây → tuyển → chiếm mỏ → khai thác và chở hàng → chống phản kích → chọn chiến dịch → tiếp quản thành → củng cố hoặc rút → lưu và chơi tiếp.

## 2. Thế giới và nhịp chơi

Mặc định đề xuất cho bản thử: thế giới chạy theo đồng hồ mô phỏng; pause dừng mọi bên; tăng tốc áp cho cả người và NPC; đóng game không chạy bù thời gian thật. Thành, đất, lịch sử và công việc giữ trong bản lưu, không reset mùa.

Người chơi xem và chuẩn bị lệnh khi pause, không chen lệnh vào trước sự kiện đã xảy ra. Tự dừng khi có cảnh báo quan trọng và tua tới sự kiện đáng chú ý là ứng viên UX để thử, không yêu cầu canh giờ đời thực.

Thời lượng cũ phải audit cùng sản lượng, lương, hành quân và nhịp quyết định. Không chỉ đổi thời gian xây. “20–40 phút một chiến dịch” và các mốc Học viện là giả thuyết, chưa có cam kết.

## 3. Một cách đổi chủ, nhiều lựa chọn chiến dịch

| Lựa chọn | Có thể có lợi khi | Giá phải trả/rủi ro |
|---|---|---|
| Công phá ngay | Có ưu thế, cần chiếm trước viện binh hoặc không đủ hậu cần để chờ | Thương vong, thiếu lực giữ sau trận |
| Giữ ngoại thành, gây sức ép | Có thể nuôi trại và ngăn nguồn cung thật | Xe/quân bị ghim, lương, viện binh và cơ hội mục tiêu khác |
| Rút, đổi mục tiêu hoặc củng cố | Thông tin mới cho thấy chiến dịch không còn đáng | Bỏ lợi ích trước mắt, đối phương có thời gian phục hồi |

Rút của bên thủ có thể giúp bên công chiếm thành mà không diệt hết quân. Đây là kết quả của tình thế và hành động, **không quảng cáo ba hệ đầu hàng/công phá/bao vây độc lập**. Hòa ước, bồi thường, giao thành có cam kết và chư hầu để sau khi chứng minh cần.

## 4. Sở hữu, kiểm soát và tiếp quản

Một thành có các phần độc lập:

- **Chủ hợp pháp** và phiên bản sở hữu.
- **Thủ quân** thực sự trong thành, gồm quân đang nâng nếu còn sống.
- **Bên giữ ngoại thành**, nơi sản xuất và cửa ra/vào liên quan.
- **Công việc tiếp quản**, chỉ chạy khi đủ điều kiện.
- **Phục hồi sau chiếm** nếu dùng P03; thành đang phục hồi vẫn bị đánh được.

Thắng trận không tự đổi chủ. Preset thử: bên tiếp quản giữ ngoại thành, không còn thủ quân hợp lệ chống giữ, đủ lực lượng kiểm soát cấu hình và còn khả năng duy trì. Đến hạn kiểm tra lại rồi đổi chủ đúng một lần.

Mất điều kiện thì hủy công việc về 0 là mặc định thử, không phải luật đã chốt. Thắng một toán nhỏ tới phá mà vẫn đủ điều kiện không làm reset. Phe khác thắng bên giữ phải bắt đầu tiếp quản của mình; không kế thừa phần việc của đối thủ.

Ngưỡng lực lượng kiểm soát là dữ liệu thử theo địa điểm, chưa tính bằng bậc thành chưa định nghĩa. Nếu dùng suất phải kiểm tra voi/tinh nhuệ và việc đứng đúng ngưỡng. Nó không thay điều kiện thắng trận và không tạo quota phòng thủ cho từng thành.

## 5. Bao vây cắt gì?

Chỉ nguồn sản xuất thuộc khu **thật sự mất kiểm soát** mới ngừng. Kho cũ và nguồn được bảo vệ vẫn còn. Không đặt mọi lương về 0 khi quân tới gần thành.

Một cụm sản xuất ngoại thành và một cửa tiếp cận là trừu tượng đề xuất cho bản thử. Có thể cấu hình mọi ô sản xuất ở ngoài tường để thử; đây không phải luật bắt buộc cho mọi bản đồ sau này.

Bên thủ có thể xuất quân, nhận viện binh hoặc rút khi có điều kiện. Bên công cũng cần lương thật. Quân ở nhà vốn ăn lương, vì vậy đánh giá **chi phí tăng thêm** của việc vây, gồm vận tải, quân bị ghim và cơ hội khác. Hậu cần tốt khiến một cuộc vây có lợi là kết quả được mong muốn; chỉ đáng lo nếu chờ luôn là đáp án trong mọi tình huống.

## 6. Rút quân và cửa tiếp cận

Đề xuất để thử: bên giữ ngoại thành có lập trường **chặn** hoặc **để ngỏ** đối với thủ quân rút. Chặn thì ra khỏi thành phải giải quyết trận tại địa điểm, không có lợi thế tường; để ngỏ thì rời theo hành quân thường. Đây là lựa chọn tại ranh giới, không phải lời hứa an toàn trên toàn bản đồ.

Lệnh rời thực thi nguyên tử theo lập trường có hiệu lực lúc đó. Không đóng cửa để kéo lại đoàn đã đi. Phe thứ ba không bị ràng buộc. Bản đầu hoãn giao chiến trên đường cho mọi đoàn, không cấp bảo vệ đặc biệt cho đoàn rút.

Đích rút, lương đi đường, sức chứa, quyền ở đích và việc đích mất giữa đường phải được kiểm tra. Đoàn bị kẹt có vị trí/chủ/hàng rõ và được báo; không tự dịch chuyển, biến mất hoặc chạy vòng vô hạn.

Nếu cả hai lập trường không tạo lựa chọn thật, bỏ một lựa chọn thay vì giữ chỉ để có thêm nút. Cửa tiếp cận chưa phải cơ chế được người dùng chốt.

## 7. Quân mạnh đến từ đâu?

D29/D30 ghi hướng quân tiến hóa và nghiên cứu. Đề xuất kiến thức toàn đế chế, cơ sở/tài nguyên tại thành; mở công nghệ không tự trang bị quân đang có. Quân cũ nâng một phần vẫn có mặt, bị đánh và giữ biên chế.

Tách dòng, bậc, nhánh, phe và quan hệ. D31 chọn nhánh Thánh/đối lập có năng lực riêng. Quân chế/Thánh Quang/Hắc Ảnh, I–III chung và IV/V ba đường là phương án triển khai, không phải mọi chi tiết đã duyệt. Paladin là kỵ, không kiếm biến thành ngựa; khuyến nghị thuần quân sự cũ không còn là giới hạn.

Bản thử năng lực tự kích hoạt trong trận/báo cáo, quỹ hữu hạn và hồi theo thời gian game; không tự thêm mana. Quân chế vẫn là đường hoàn chỉnh. K giữ theo năm dòng, nhưng hiệu quả tương khắc phải thử với bậc, quỹ và ngân sách.

Xem [quân/nghiên cứu](military-and-research.md) và [nhánh/năng lực](combat-abilities.md). Quân thấp không nhất thiết tốt trong mọi tình huống, nhưng không để bậc/nhánh cao nhất thành đáp án cho mọi nhiệm vụ.

## 8. NPC có đời sống riêng nhưng không cần AI khổng lồ

NPC địa phương là mục tiêu/quấy nhiễu giới hạn. Vương quốc NPC có thành, quân, kho, nghiên cứu và mục tiêu. Hành vi offline theo luật, không cần dịch vụ AI online.

Bộ điều khiển dùng thông tin đã quan sát, khả năng nuôi và cam kết; có đầu tư nền, không đứng chờ/tự sát. Dự báo không đọc bí mật hoặc tiến PRNG để nhìn tương lai. D32/D33 bổ sung phe/quan hệ và đoàn lưu động: nhánh không tự là địch/bạn, đoàn có mission/tài sản/lương thật. [Bản thử đoàn](mobile-npcs.md) chỉ chạm trán tại địa điểm, chưa có giao chiến khi hai đoàn cắt nhau giữa đường.

Nếu không thể đánh hợp lý, trinh sát/đầu tư/đổi mục tiêu là hành động đúng. Không bắt AI tự sát để chứng minh nó hoạt động. Mất hết thành không tự xóa các đạo quân; chúng tiếp tục theo cùng luật lương và hành động đã hỗ trợ. Chưa cần hệ lưu vong hoặc ép người chơi truy sát hết tàn quân để được ghi nhận chiến thắng.

## 9. Phạm vi thử đề xuất

| Lát cắt | Nội dung | Chưa chứng minh |
|---|---|---|
| A1: vòng lõi | Một NPC hai thành, mục tiêu trung lập, năm dòng I; xây/mỏ/xe/trại/trận/tiếp quản/lưu | NPC độc lập nhiều phe hoặc năng lực đã vui |
| A2′: tiến hóa và nhánh | Kỵ I–III + IV ba nhánh, bốn dòng khác I–II: ứng viên 14 profile; Hộ trận/Phá ấn/trang bị; ít công nghệ, một dự án | Đủ 45 profile, V, mọi dòng có nhánh hoặc Thanh tẩy/Nguyền |
| L: đoàn có căn cứ | Một đoàn tuần tra 3–4 địa điểm, có lương/hàng/nhiệm vụ, biết rút | Du mục/cap mobile hoặc trận trên đường |
| B: nhiều phe | Phe thứ hai khác khuynh hướng, quan hệ cấu hình, một case tàn quân/mất thành cuối | Toàn bộ ngoại giao, du mục và phục quốc |

A2′ thay phạm vi 10/12 profile của 1.2 bằng một ứng viên theo U08, chưa được duyệt. A2′ và L có thể thử riêng sau A1. B dùng cùng luật vật chất/thời gian/tầm nhìn; khác biệt tổ chức được khai báo, không nguồn miễn phí.

Hoãn đầy đủ 45 profile, sáu cây, V toàn bộ, Thanh tẩy/Nguyền, tướng/item/XP, bảo dưỡng ngoài lương, công thành phức tạp, chư hầu và các ý tưởng tổ chức đế chế. Hướng Thánh/đối lập không còn bị hoãn tuyệt đối. Đại thành/thưởng B, dời đô và tái lập vẫn giữ cho giai đoạn sau nền.

## 10. Khi nào phải sửa luận điểm?

Nếu công phá hoặc chờ luôn tối ưu, tuyến tiếp tế chỉ là bấm lặp, AI đứng im/tự sát, bậc cao xóa sạch mọi lựa chọn hoặc người thử không hiểu nguyên nhân thất bại, cần xem lại mô hình trước khi thêm hệ thống.

Nếu người chơi đã tổ chức tốt và thật sự áp đảo, cho họ hưởng thành quả, ghi mốc chiến thắng tự nguyện và có thể chơi tiếp là hướng đề xuất. Không reset thế giới hoặc ép đế chế suy yếu để kéo dài thời lượng.

Các ca kiểm chứng và nguồn review xem [lộ trình](roadmap-and-validation.md), [đối chiếu hiện hành 1.3](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md) và lịch sử review 1.2. Không có ca nào đã chạy trong bước viết tài liệu.
