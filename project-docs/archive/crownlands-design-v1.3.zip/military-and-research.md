# Quân đội và nghiên cứu

Phiên bản 1.3 · 07/11/2026. **Đặc tả đề xuất để thử, chưa được chủ dự án duyệt toàn bộ.** Đầu vào U07/U08; [đối chiếu 1.3](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md) ghi phần kế thừa/sửa từ review 1.2.

## 1. Tiến trình và nhận diện

Giữ năm dòng kiếm, giáo, cung, kỵ và voi. Đề xuất I–V là bậc trang bị/huấn luyện, không phải năm binh chủng mới hoặc cấp công trình. Cùng dòng giữ nhận diện; kiếm không biến thành kỵ, Paladin không thành dòng thứ sáu.

Mốc công trình vẫn theo D20; quan hệ với bậc quân còn là cấu hình thử. Hạng NPC không cho biết chính xác từng lính, không thay trinh sát. Cấp thành không được tính bằng trung bình bậc quân.

Bậc cao thay hình dáng/profile theo D29. D31 chọn nhánh Thánh và đối lập có năng lực; khuyến nghị Paladin thuần quân sự cũ đã được thay. Tên/silhouette vẫn theo một phong cách; từng kỹ năng và mức thể hiện còn O34/O35. Xem [nhánh và năng lực](combat-abilities.md).

## 2. Phân biệt kiến thức, năng lực và quân thật

| Lớp | Đề xuất |
|---|---|
| Kiến thức đế chế | Công nghệ đã hoàn tất, mở recipe/khả năng |
| Cơ sở thành | Học viện/Lò rèn/nơi tuyển đủ điều kiện tại nơi thực hiện |
| Nguồn lực | Kho tại nơi trả, thời gian và hạn mức của quân |
| Lực lượng | Dòng, bậc, nhánh thực tế, quân số, gốc, vị trí/trạng thái và bucket sẵn sàng |

Học viện mở kiến thức; Lò rèn cho năng lực trang bị; Doanh trại/Chuồng ngựa/Trại voi thực hiện tuyển hoặc huấn luyện. Vai trò Lò rèn mới thay đề xuất tăng công/giáp chung của hồ sơ cũ **nếu được lựa chọn**, chưa tự xóa nguồn cũ hoặc bắt đầu migration.

Không thêm thép/giáp/vũ khí như tài nguyên mới bắt buộc. Bản thử dùng bốn tài nguyên cũ. Không có kho chung hoặc vật liệu tự trừ từ một thành xa.

## 3. Nghiên cứu đề xuất

- Một công nghệ có tối đa một dự án đang chạy cho cùng đế chế.
- Bản thử một dự án toàn đế chế. 1–3 dự án và sáu nhánh là phương án dài hạn chưa duyệt.
- Dự án có thành nguồn, chi phí địa phương và cấp cơ sở chụp lúc bắt đầu; không cộng tốc độ vô hạn bằng nhiều Học viện.
- Hoàn tất mở kiến thức đế chế; thành khác vẫn cần cơ sở để tuyển/nâng.
- Mất Học viện không xóa kiến thức đã hoàn tất. Dự án dở bị hủy và không chuyển cho người chiếm là mặc định thử; phí đã tiêu không hoàn ngầm cho chủ cũ.
- Chiếm công trình cấp cao không tự nhận kiến thức của chủ cũ. Kiến thức khi tái lập còn thuộc O12/O29, chưa tự khóa.

Hàng chờ nghiên cứu nếu có giữ tài nguyên tại nơi đặt. Chưa bắt buộc thêm vào A2′; một dự án đang chạy đủ để kiểm tra lựa chọn thứ tự trước.

| Loại công nghệ | Cách áp dụng |
|---|---|
| Mở bậc/recipe | Không sửa profile quân đã có |
| Hiệu ứng trực tiếp như vận tải | Ghi phạm vi/mốc; ví dụ chỉ chuyến xuất phát sau hoàn tất |
| Mở hành động như công thành | Chỉ bật khi luật hành động đã được đặc tả; hoãn khỏi bản lõi |

Bộ lọc, cảnh báo, bảng tổng quan và công cụ giảm thao tác cơ bản không khóa sau nghiên cứu. Nghiên cứu mở năng lực trong game, không là phí để được bớt bấm.

## 4. Quân bậc thấp và tương khắc

Không kết luận trước rằng mọi bậc phải tồn tại mãi trong đội hình, hoặc mọi quân thấp nên lỗi thời. Đo theo giai đoạn, nhiệm vụ và nguồn lực. Ở đế chế giàu có thể ít dùng quân thấp hơn, nhưng việc bậc cao tốt nhất ở mọi nhiệm vụ là dấu hiệu cần kiểm tra.

Giữ ma trận tương khắc theo năm dòng, không tạo ma trận 25×25 để che các hệ số bậc. Cấu hình cần thử giáo đối kỵ/voi lệch bậc và lệch quân số/ngân sách. “Trong khoảng một bậc tương khắc còn đáng quan tâm” là tiêu chí thử, không bảo đảm giáo luôn thắng.

Hiệu quả trên mỗi suất của tinh nhuệ không buộc phải ngang quân rẻ, cũng chưa chốt phải cao hơn. So đồng thời giá, tốc độ tuyển/thay thế, lương, hành trình, suất và mục tiêu. Cùng quân số mạnh hơn có thể là chủ đích; cùng mọi ngân sách đều tốt hơn chưa phải lựa chọn chiến thuật.

Kỵ nặng có thể chậm hơn; giữ kỵ nhẹ bằng đánh đổi profile trước khi thêm nhánh. Không dùng các vai trò hộ tống/đánh chặn đã hoãn làm bằng chứng rằng quân thấp có ích ngay.

## 5. Tuyển thẳng và nâng quân cũ

Khi công nghệ/cơ sở/kho/suất đủ, có thể tuyển thẳng bậc đã mở. Quân cũ có thể nâng một phần tại cơ sở phù hợp. Khả năng nhảy nhiều bậc trong một job còn mở; không buộc người chơi bấm từng người.

Hai phép so khác nhau:

1. **Chưa có quân, công nghệ đã mở:** so tuyển thẳng bậc đích với tuyển thấp rồi nâng từ cùng trạng thái đầu.
2. **Đã có quân thấp:** chi phí tuyển trước đó là chi phí chìm; so nâng với tuyển thêm/thay thế, có xét suất, quân bị ghim và thời gian di chuyển.

Không cần cấm đường vòng rẻ hơn **hoặc** nhanh hơn ở mọi khía cạnh. Điều cần tránh là đường vòng luôn rẻ hơn, nhanh hơn và không có đánh đổi khác; tương tự không ép nâng luôn rẻ hơn tuyển mới như một định luật. Một đường có lợi tiền nhưng bất lợi thời gian có thể tạo lựa chọn tốt. Các giá phải được thử, chưa có bảng giá mới.

## 6. Vòng đời nâng trong preset A2′

Đề xuất hoàn tất cả lô ở một mốc cho đơn giản, dữ liệu vẫn ghi số quân còn hợp lệ. Hoàn tất từng phần là phương án khác, chưa duyệt.

| Mốc | Xử lý đề xuất |
|---|---|
| Nhận lệnh | Chọn quân có mặt/cùng chủ; kiểm tra tech/cơ sở/kho; giữ phần suất tăng thêm tại gốc; ghi job/lịch |
| Bắt đầu | Trả chi phí theo preset; quân vẫn ở thành, còn bậc cũ; không được hành quân |
| Có trận | Quân đang nâng vẫn bị đánh và chiến đấu bằng bậc đang có; không tàng hình trong hàng đợi |
| Có tổn thất | Giảm số đủ điều kiện của job; cập nhật quân và giải phóng phần suất của quân chết trong cùng bước, không đợi job xong |
| Hoàn tất | Chỉ số còn sống/hợp lệ đổi bậc một lần; suất giữ đổi thành suất hiện hữu; lương đổi tại mốc này |
| Hủy để di chuyển | Giữ bậc hiện tại, giải phóng phần giữ, áp phí/hoàn đúng preset rồi mới nhận lệnh đi |
| Cơ sở/địa điểm đổi chủ | Hủy phần chưa xong, không hoàn cho chủ cũ qua quyền đã mất; quân vẫn có chủ riêng |
| Gốc biên chế mất ở thành khác | Không lấy suất của chủ mới. Job/đơn vị chờ biên chế cần quy tắc O18/O30 trước triển khai |

Tổn thất giữa quân đang nâng và quân cùng profile dùng một quy tắc phân bổ/làm tròn xác định. Tách/gộp lô không làm giảm tổng tổn thất hoặc nhân quyền hoàn. Không cấp lại đủ N ban đầu sau khi một phần đã chết.

Phí hủy còn là O30. Phải ghi rõ trước chạy thử: khoản giữ vẫn nằm trong kho hay vật liệu đã tiêu; ai nhận khi cướp/đổi chủ. Không tạo chỗ giấu hàng bằng khoản hoàn ngầm. Một preset đơn giản có thể không hoàn phần vật liệu đã tiêu của job đang chạy, nhưng đây là thử nghiệm, cần đo độ gắt.

Nếu chưa chọn luật khi mất gốc, không bật tình huống đó trong A2′ thay vì tự cho vượt mọi điều kiện. Bản đầy đủ phải có ca này. Nếu lưu thương tích, đổi bậc/nhánh không tự hồi máu. Đổi nhánh dùng cùng job, một profile hiệu lực; giữ khóa hồi qua chuyển đổi, không hưởng đôi. Không thêm XP/y tế chỉ để vá.

Quân đang nâng vẫn là thủ quân nên tiếp quản thành không thể bỏ qua họ. Nếu phải rút, hủy job trước; hoàn/hủy lệnh là tác động nguyên tử, không có một frame quân vừa ở hàng vừa ngoài đường.

## 7. Thời gian và NPC

Thứ tự cùng mốc là preset O10 trong [thiết kế kỹ thuật](technical-design.md). Job nâng xong trước pha trận thì đánh bậc mới; chưa xong thì bậc cũ. Tech unlock không tự nâng quân. Save/load không làm lại job.

NPC dùng cùng điều kiện kiến thức, cơ sở, kho và biên chế. A2′ có thể dùng danh sách nghiên cứu cố định và chỉ tuyển thẳng, ghi nhãn hạn chế controller; không cho NPC tự nhận bậc mới miễn phí để bù AI chưa có chức năng nâng.

## 8. Phạm vi thử theo U08

A1 giữ năm dòng I cho vòng lõi. A2′ đề nghị kỵ I–III + IV ba nhánh (6), bốn dòng khác I–II (8), tổng 14 profile. Đây là ứng viên, không quyết định cứng hoặc phải tăng tiếp lên 45 ngay.

Theo phương án I–III chung, IV–V ba đường cho cả năm dòng, có 45 profile nếu mọi tổ hợp tồn tại. Kiến trúc dữ liệu tách `line/tier/path`, không nhân thêm dòng chiến đấu. Trường hợp một đế chế học nhiều nhánh/trộn quân vẫn đề xuất, không tự thêm bất mãn.

Thử Hộ trận/Phá ấn/trang bị chuyên dụng trước, rồi xem Thanh tẩy/Nguyền và V. Không blanket hoãn mọi năng lực theo khuyến nghị 1.2 nữa. Vẫn hoãn đầy đủ sáu cây, nhiều dự án, bảo dưỡng vật tư, item/XP và xe phá cổng.

L/B kiểm tra đoàn lưu động và phe. Tên cuối, công nghệ tiền đề, cap và chi phí theo nhánh còn O28–O30/O34–O38. Không cần 45 asset hoạt cảnh; D09 giữ báo cáo.

Đại thành đầu tiên phù hợp không đòi Paladin hoặc V như chìa khóa. M1–M12 của C05 và N1–N15 của C07 chưa chạy; các mã thuộc file review, không là milestone hoặc bất biến kỹ thuật. Thử quỹ dùng chung, bucket hồi, chuyển qua nhánh bị động và mất gốc giữa job trước khi nói an toàn.
