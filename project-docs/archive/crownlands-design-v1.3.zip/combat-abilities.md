# Nhánh quân và năng lực chiến đấu

Phiên bản 1.3 · 07/11/2026. D31 ghi hướng Thánh và nhánh đối lập có năng lực/cách đối phó theo U08. **Tên nhánh, I–V, từng kỹ năng, pha và tham số bên dưới vẫn là ĐỀ XUẤT để thử.** Chưa có mô phỏng hoặc playtest. Xem [biên bản đối chiếu](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md).

## 1. Các trục riêng biệt

| Trục | Ý nghĩa |
|---|---|
| Dòng `line` | Kiếm, giáo, cung, kỵ, voi; giữ D07 |
| Bậc `tier` | Trang bị và huấn luyện thực tế, đề xuất I–V |
| Nhánh `path` | Hướng năng lực, không là dòng quân thứ sáu hoặc cấp tiếp sau V |
| Phe `faction` | Chủ và nguồn lực |
| Khuynh hướng `path_bias` | Ưu tiên của controller, không khóa mọi quân vào một nhánh |
| Quan hệ `relation` | Tình trạng giữa các phe; không suy từ Thánh/Hắc |

Phương án để thử: I–III chung, IV–V có Quân chế/Thánh Quang/Hắc Ảnh. Nhánh Quân chế là đường hoàn chỉnh, không phải phần nền chưa nâng. Tên gọi là tạm; Thánh không tự là bạn, Hắc không tự là địch.

Nếu mọi tổ hợp tồn tại, `5 × [3 + (3 × 2)] = 45` profile. Không phải 45 dòng hoặc cam kết 45 asset. Kế thừa dữ liệu giúp nhập liệu, không thay việc kiểm tra cân bằng từng tổ hợp đại diện.

Paladin là tên tạm của kỵ có năng lực Thánh, không biến kiếm thành kỵ. Khuyến nghị thuần quân sự của bản 1.2 đã được thay bởi hướng U08, không còn là giới hạn hiện hành.

## 2. Lớp năng lực tối giản

Đề xuất tự kích hoạt theo bố trận và lượt, giữ trận tự tính/báo cáo; không bấm phép trong trận. Bản thử chỉ dùng hiệu ứng trong một trận nguyên tử. Không mana, hồi sinh, triệu hồi vô hạn, teleport quân/hàng hoặc kinh nghiệm từng lính mặc định.

Hai loại thời gian có tên rõ:

- Thời hạn tác dụng tính bằng lượt trận.
- Thời gian hồi tính bằng đồng hồ thế giới, không reset khi mở trận mới.

Hiệu ứng trận không mang ra thế giới ở lát cắt này. Tuy vậy mốc hồi và lịch sử sẵn sàng **phải lưu**. Nếu sau này có hiệu ứng ngoài trận, cần `ActiveEffect` có nguồn/thời hạn và migration save, không dùng suy luận “trận nguyên tử nên không cần lưu gì”.

## 3. Bộ năng lực đại diện để thử

| Nhánh đề xuất | Năng lực | Quy tắc nhỏ để thử | Đánh đổi/rủi ro |
|---|---|---|---|
| Thánh | Hộ trận | Đầu trận nếu sẵn sàng; quỹ hấp thụ hữu hạn theo quân nguồn đủ điều kiện, phủ một tuyến | Có thể chỉ giống thêm máu nếu mục tiêu/phạm vi không tạo lựa chọn |
| Đối lập | Phá ấn | Giảm quỹ bảo hộ đang phủ mục tiêu trước sát thương, theo lượng nguồn và trần được cấu hình | Chuyên biệt; toàn profile vẫn cần có giá trị ở một số tình huống không có bảo hộ |
| Quân chế | Trang bị chuyên dụng | Bị động theo profile, củng cố vai trò có sẵn; không đổi ma trận K hoặc miễn mọi hiệu ứng | Có thể ít đặc sắc; chưa ép chỉ số nền phải cao nhất ở cùng giá |

Nguyền ấn, Thanh tẩy và Kỷ luật là các phép thử tiếp theo, chưa phải tất cả phải có cùng lúc. Kỷ luật không được kéo thêm một thanh sợ hãi chỉ để có việc chống. Không gắn cho mọi đơn vị toàn bộ năng lực.

Không cần Phá ấn có tác dụng miễn phí khi không có bảo hộ. Có thể cân bằng bằng giá và profile hoặc chọn nó theo đối thủ. Cần ít nhất một hoàn cảnh hợp lý, không bắt mọi kỹ năng luôn hữu ích trước mọi đội.

## 4. Quỹ bảo hộ dùng chung

**Mặc định thử của Codex sau review:** cùng loại Hộ trận và cùng tuyến tạo một quỹ chung. Dung lượng là tổng đóng góp hợp lệ theo số quân nguồn sẵn sàng, không có khoản cố định theo số nhóm. Các nhóm được phủ cùng rút từ một quỹ, không nhận bản sao dung lượng.

Nếu nhiều mục tiêu chịu sát thương cùng lượt, phân bổ hấp thụ theo quy tắc xác định và đối xứng đã ghi trong preset, ví dụ tỷ lệ sát thương hợp lệ với quy tắc phần dư. Không ưu tiên mục tiêu chỉ vì nó nằm bên trái hoặc có ID nhóm nhỏ hơn.

Quỹ sau kích hoạt chỉ giảm hoặc hết hạn, không tăng trở lại vì gộp nhóm hay thay cách hiển thị. Thử mặc định đóng góp chụp tại lúc kích hoạt, tồn tại tới hết quỹ/thời hạn/trận; nguồn chết sau đó không sinh thêm hoặc hoàn phần quỹ. Đây là một lựa chọn khác đề xuất “nguồn chết thì xóa quỹ” của reviewer, cần đo trước khi khóa.

Các cách chồng khác loại Hộ trận chưa mở. Không dùng câu “mỗi nhóm lấy quỹ lớn nhất” nếu chưa nói quỹ đó chia sẻ hay bị sao chép: một dòng như vậy chưa đủ chống lạm dụng.

## 5. Hồi và bảo toàn khi đổi tổ chức

Lưu số lượng cùng trạng thái sẵn sàng theo cohort hoặc các bucket tương đương. Cùng profile nhưng khác mốc hồi có thể chung một đạo quân, không được ép thành một mốc sớm nhất.

- Tách: chia số lượng, giữ nguồn và mốc của mỗi phần; không nhân lượt dùng/dung lượng.
- Gộp: giữ các bucket khác mốc; chỉ gộp hoàn toàn khi trạng thái tương đương.
- Kích hoạt: ghi mốc hồi cho đúng phần nguồn đã dùng, cùng tác động trận.
- Nâng/đổi nhánh hoàn tất: không làm sẵn sàng sớm hơn mốc cũ. Mặc định thử `ready_new = max(ready_old, finish_at + rearm_delay_new)` cho khóa sẵn sàng tương ứng.
- Đi qua nhánh bị động không xóa khóa cũ để đổi về nhánh chủ động rồi dùng lại.
- Hủy: không đổi profile/mốc cũ thành mốc mới, không cấp lại hiệu ứng hoặc khoản hoàn.
- Tải: khôi phục đúng lượng/bucket/mốc. Người chơi tải save trước để chọn khác là quyền của họ; tải cùng trạng thái làm hồi đầy là lỗi.

Giá trị `rearm_delay_new`, nhiều năng lực trên một profile và việc tuyển mới bắt đầu sẵn sàng hay đang hồi thuộc O35. Bản thử có thể chỉ một năng lực chủ động mỗi biến thể để tránh hệ hồi phình to.

## 6. Hai lớp chiến đấu và thứ tự lượt

Giữ ma trận K 5×5 theo dòng. Nhánh/hiệu ứng là lớp bổ sung, không thay K hoặc tự xóa yếu điểm giáo–kỵ–voi. **K không đổi chưa chứng minh tương khắc còn hiệu lực:** bảo hộ quá lớn vẫn có thể che hết sát thương; phải thử theo bậc, quân số và ngân sách.

Đề xuất trận vẫn nằm trong pha quân/giao chiến của đồng hồ thế giới, có vòng lượt bên trong:

1. Chụp nhóm sống, sẵn sàng và phạm vi/mục tiêu đầu lượt.
2. Kích hoạt hiệu ứng đầu trận nếu hợp lệ, ghi quỹ/nguồn/khóa hồi.
3. Xử lý gỡ/phá/suy yếu theo thứ tự của preset, không theo bên người chơi.
4. Tính sát thương cơ bản và K, rồi các hiệu chỉnh cho phép.
5. Phân bổ hấp thụ chung, sát thương còn lại và tổn thất đồng thời.
6. Giảm thời hạn, ghi báo cáo và kiểm tra kết thúc.

Thứ tự giữa Thanh tẩy/Nguyền chưa chốt vì chưa có ở bộ nhỏ. Nếu mở, cần ca cùng lượt và không làm mới hiệu ứng vô hạn. Lượt trận không làm thời gian thế giới nhảy nhiều ngày; cooldown dùng mốc trận tại thế giới theo preset.

## 7. Nâng và đổi nhánh

Dùng [vòng đời nâng quân](military-and-research.md): cơ sở tại chỗ, chi phí tại chỗ, quân vẫn bị đánh và không xuất đi khi làm việc. Chỉ một profile/nhánh có hiệu lực; phần suất tăng giữ trước, phần giảm chỉ trả khi hoàn tất. Quân chết giải phóng phần tương ứng một lần.

Đề xuất đế chế học nhiều nhánh và trộn trong một đạo quân; từng cohort chỉ một nhánh. Đây chưa phải lựa chọn cuối về chuyên hóa đế chế. Không tự thêm bất mãn hoặc cấm quân Thánh/Hắc hỗ trợ nhau. Quan hệ ngoại giao giữa các phe là một trục khác.

## 8. Trường dữ liệu cần có

Một năng lực: ID/version, profile nguồn, điều kiện, target scope, pha/lượt kích hoạt, lượng/trần, scaling theo số quân, duration unit, stack rule, dispel/kháng, cooldown domain, trạng thái khi nguồn chết/đổi chủ và nội dung báo cáo.

Một profile: line/tier/path, stats cơ bản, chi phí/lương/suất/tốc độ, công nghệ và cơ sở, khả năng nâng/đổi với chi phí/thời gian, ability IDs. Không tự tạo số cân bằng hoặc cập nhật XLSX nguồn khi các đơn vị chưa khóa.

Báo cáo ghi nguồn, mục tiêu, lượt, hấp thụ/phá/suy yếu, tác động K và lý do không kích hoạt khi cần. Không lộ bí mật chưa quan sát chỉ vì dữ liệu ở máy cục bộ.

## 9. Phạm vi thử và phản chứng

Ứng viên A2′: kỵ I–III và IV ba nhánh là 6 profile; bốn dòng còn lại I–II là 8, tổng 14. Đây là đề nghị của Claude được giữ để thử, chưa phê duyệt, không phải phải làm đủ 45. Nếu chi phí tiến trình tới kỵ IV quá lớn, dựng một scenario thử công khai; không cần giả vờ đã mô phỏng toàn bộ lịch sử Học viện.

Không tự thêm V chỉ để đủ tên Paladin. Có thể dùng tên thử của kỵ IV và để tên/bậc cuối cho chủ dự án chọn. Bộ nhỏ chưa chứng minh các dòng khác có nhánh hoặc Thanh tẩy/Nguyền đã cân bằng.

Các ca review C07:N1–N15 chưa chạy. Bổ sung: quỹ bị nhiều nhóm rút cùng lượt; tách/gộp giữ cùng bố trận và độ sẵn sàng; đổi từ nhánh hồi dài sang ngắn; nguồn chết giữa trận; K còn tác dụng khi quỹ lớn; so Hộ trận với tăng máu để biết có lựa chọn riêng.
