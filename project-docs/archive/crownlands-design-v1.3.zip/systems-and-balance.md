# Hệ thống và cân bằng

Phiên bản 1.3 · 07/11/2026. Đề xuất cho một người offline D28. Công thức R02/R06 còn THỬ NGHIỆM, cần audit nhịp/đơn vị. Xem [sổ quyết định](decisions.md), [khung lối chơi](gameplay-blueprint.md), [quân/nghiên cứu](military-and-research.md), [năng lực](combat-abilities.md) và [đoàn NPC](mobile-npcs.md).

## 1. Tài nguyên và sản xuất

Bốn tài nguyên hiện hành là gỗ, đất sét, sắt và lương thực. Mỗi thành, trại và điểm khai thác có kho riêng. Không có kho toàn đế chế tự nuôi quân ở nơi khác. Khả năng quản lý tập trung không tạo khả năng dùng chung hàng đang ở xa.

Kinh tế tính theo thời gian mô phỏng, chia đoạn khi cấp nhà, kho, quân ăn hoặc thưởng đổi. Theo P14, pause/đóng game không cộng sản xuất hoặc đói bằng giờ đời thực. Giữ phần lẻ để tần suất mở màn không làm mất hàng do làm tròn; hiển thị riêng số dư/giữ/khả dụng.

R02 đề xuất một số công thức tăng cấp và sản lượng. Chưa tự mở rộng chúng lên cấp 20 cho mọi loại: R06 có `field_cap = 10` mẫu, trong khi D20 nói thang 1–20. O08/O24 cần xác định ô tài nguyên có thuộc thang mới không trước khi tạo cấu hình chạy thử.

## 2. Xây dựng và hàng đợi

Lệnh xây kiểm tra chủ sở hữu hiện tại, ô, loại công trình, cấp, phụ thuộc, tài nguyên khả dụng và chỗ hàng đợi. Một công trình không đồng thời chạy hai nâng cấp.

| Trạng thái đề xuất | Tài nguyên | Lịch |
|---|---|---|
| Chờ | Giữ chi phí; chưa tiêu | Chưa coi là có mốc hoàn tất chắc chắn |
| Chạy | Chuyển khoản giữ sang đã tiêu | Chốt thời lượng theo trạng thái lúc bắt đầu; tạo lịch hoàn tất |
| Xong | Không trừ thêm | Áp cấp một lần |
| Hủy/vô hiệu | Hoàn hoặc giải phóng theo quy tắc đã chọn | Sự kiện cũ mất hiệu lực |

Đây là làm rõ đề xuất của R02 §3 và R03 §5.3: công việc đang chạy phải có lịch bền vững trong cùng giao dịch; công việc chờ chưa được tính như đã bắt đầu. Số chỗ chờ và tỷ lệ hoàn tiền của hồ sơ cũ vẫn là thử nghiệm.

“Sổ lệnh đặt trước” là đề xuất giảm lợi thế online liên tục, chưa được duyệt. Cần đo số lựa chọn hữu ích và chi phí giữ tài nguyên, tránh thành chuỗi tự chơi vô hạn.

## 3. Quân và đơn vị hạn mức

Năm binh chủng giữ nguyên: kiếm, giáo, cung, kỵ, voi. Xe vận tải hoặc chức năng trinh sát chưa tự trở thành binh chủng chiến đấu thứ sáu. Tương khắc phải kiểm tra cùng giá, lương, thời gian tuyển, thời gian tới và hạn mức, không chỉ cùng số đầu quân.

D22 đã chọn hạn mức theo thành. P01/P02 đề xuất phân biệt:

| Đại lượng | Ý nghĩa | Chưa được suy ra |
|---|---|---|
| Quân số | Số đơn vị mỗi loại | Một voi không nhất thiết chiếm một suất như kiếm |
| Suất biên chế | Tổng số lượng × trọng số từng loại | Trọng số chưa khóa; không dùng số của review làm mặc định |
| Hạn mức thành gốc | Nguồn bảo đảm biên chế theo thành | Không đồng nghĩa sức chứa nơi quân đang ở |
| Sức chứa địa điểm | Giới hạn tập kết/phục vụ tại thành, trại, mỏ | Không tự cộng vào hạn mức đế chế |
| Khả năng nuôi | Lương hiện có và vận tải duy trì được | Có suất và chỗ đóng chưa có nghĩa đủ lương |

Đơn vị hạn mức vẫn là O17. Review chỉ ra nguy cơ cap theo đầu người khiến quân đắt và mạnh trên mỗi đầu chiếm ưu thế. Cần so cả phương án đầu người lẫn suất có trọng số bằng mô phỏng; không lấy một phép quy đổi sát thương đơn giản làm kết luận cân bằng.

## 4. Vòng đời biên chế đề xuất

- Quân đang tuyển giữ suất ngay khi lệnh được chấp nhận; hoàn thành chuyển phần giữ sang quân hiện hữu, không cộng hai lần.
- Quân hành quân, ở trại, giữ mỏ hay khai thác vẫn có gốc và vẫn dùng suất. Không giải phóng hạn mức bằng cách đưa quân ra ngoài.
- Tách/gộp đạo quân bảo toàn từng loại, gốc và tổng suất. Đếm theo lực lượng, không đếm số nhóm.
- Chuyển gốc cần nơi nhận đủ chỗ biên chế, một thời điểm hiệu lực và cập nhật nguyên tử. Đổi tự do gần như tạo quỹ chung toàn đế chế; O18 phải chọn đây có phải chủ đích không.
- Thành đổi chủ không tự chuyển quân của chủ cũ cho chủ mới, không xóa lực lượng đang ở xa và không tự cho hai bên cùng dùng một nguồn suất.
- Quân mất gốc có thể cần trạng thái chờ biên chế. Ân hạn, giới hạn tuyển và hậu quả quá trần chưa khóa. Đề xuất đóng tuyển toàn đế chế của reviewer cần thử trước vì có thể làm người thua không thể phục hồi.
- Đổi đô không tự tăng hạn mức hoặc giải phóng suất. Mức đóng góp của thành mới chiếm thuộc P03/O18.

Các dòng trên là P01/P02, chưa phải đặc tả hoàn chỉnh. Bất kỳ phương án nào cũng cần chặn “rửa hạn mức” bằng nhường thành, bỏ thành hoặc tái lập lặp.

## 4.1. Nhánh, hiệu ứng và nguồn hạn mức NPC

D31 ghi hướng năng lực riêng, không thêm dòng quân thứ sáu hoặc tài nguyên thứ năm. Bốn tài nguyên và D25 cộng/không lặp giữ nguyên. Mỗi cohort một nhánh, trạng thái sẵn sàng không reset qua tách/gộp/đổi nhánh/tải. Quỹ bảo hộ là hữu hạn dùng chung, không tạo quân, lương hoặc hồi sinh mặc định.

Quân người chơi và đoàn từ căn cứ vẫn dùng cap gốc. Cap di động là phương án NPC riêng chưa khóa, phải có nguồn/phương tiện/ngân sách; không tự phát sinh khi mất thành hoặc đưa quân đi mỏ. Tàn quân giữ phần còn sống, không nhận suất/tuyển mới miễn phí.

Năng lực kinh tế/nghi thức nếu sau này có phải khai báo nguồn/tác động và không nhân chồng thưởng Đại thành. Hiện bộ nhỏ chỉ hiệu ứng chiến đấu, không sản xuất vật chất.

## 5. Khai thác ngoài thế giới

D21 đã chọn quân chiếm giữ và khai thác. Thiết kế phải phân biệt bốn phần:

| Phần | Vai trò |
|---|---|
| Lực lượng khai thác | Tác động năng suất trong giới hạn điểm; không đồng thời ở mặt trận khác |
| Lực lượng giữ | Đối phó nguy cơ quân sự; không mặc định mỗi lính giữ đều sinh thêm hàng |
| Tiêu thụ | Lương của toàn bộ quân thực sự hiện diện, tại đúng địa điểm |
| Vận tải | Đưa hàng khỏi kho mỏ bằng phương tiện có sức chở và hành trình |

Đây là cách tách vai trò, không yêu cầu thêm dân hoặc đơn vị mới. Một lực lượng có thể được phân công theo luật sẽ chọn; không được tính một người vừa khai thác toàn thời gian vừa đi chiến dịch.

Đề xuất có trần năng suất, kho và điều kiện trữ lượng/hồi. **Hữu hạn tại một thời điểm khác với không tái tạo vĩnh viễn.** Nếu có hồi tài nguyên, đó là nguồn tạo mới cần có ngân sách/tốc độ được ghi, không gọi nhầm là bảo toàn tài nguyên.

O20 cần quyết định loại quân nào khai thác được, hiệu suất, có cần xe riêng, khoảng rút quân, ai được lấy hàng còn ở mỏ, cách đổi chủ, khi kho đầy và quyền đất. Quân kiểm soát mỏ có tạo chủ quyền đất dân sự hay không vẫn chưa chốt.

Tránh vòng quân rảnh → mỏ → thu nhập → thêm quân vô hạn. So với đầu tư nội thành và đế chế lớn thời bình. Bỏ bài toán tài khoản phụ trong offline; vẫn chặn lỗi nhân/chuyển hàng giữa các chủ mô phỏng.

## 6. Trại và tuyến tiếp tế

Trại yếu hơn thành và không tự thành thành trì. Có chỗ chứa quân không đồng nghĩa đủ sức nuôi chúng. Quân cần lương khi đóng và khi đi; kho ở thành xa không bù lương tại trại tức thời.

Đề xuất tuyến P05 có nguồn, đích, mức giữ tại nguồn, mục tiêu dự trữ, số xe và ngân sách tối đa. Xe đi và về thật; không dùng một xe cho hai chuyến. Đo năng lực tuyến theo sức chở hữu ích chia **toàn bộ chu kỳ** gồm đi, về và các khoảng chờ, không chỉ thời gian tới đích.

Tồn kho tăng/giảm theo từng mốc: tiêu thụ liên tục, đoàn tới, chiến đấu, thay quân và đổi quyền. Dự báo phải xét lịch hàng đã đi, số xe khả dụng và nguồn có đủ hàng, không chỉ một tốc độ trung bình.

Tuyến không chạy thì báo nguyên nhân và hành động: thiếu xe, nguồn giữ dự trữ, đích đầy, quyền đổi hoặc đường không hợp lệ. Đề xuất giao diện hiển thị lượng dự trữ theo giờ, thời điểm thiếu dự kiến và độ chắc chắn của dự báo.

Thiếu lương có cảnh báo, khoảng cứu và hậu quả O04 theo thời gian game; mọi phe cùng preset. Bản đầu có thể thử suy yếu thay vì chết hàng loạt. Pause/đóng game không làm đói tiến theo giờ thật. Đánh chặn/hộ tống trên đường còn hoãn; hàng ở cổng xử lý theo quyền/kiểm soát tại mốc tới.

## 7. Chiến đấu và chiếm thành

Giữ bố trận trước, trận tự tính và báo cáo. Chiến đấu cần ảnh đầu vào, phiên bản luật, kết quả và lời giải thích có thể kiểm chứng. Dùng lại đặc tả lượt/vị trí trong R02 §6 để thử, không coi các hệ số mẫu là luật cân bằng đã duyệt.

Cướp không tự đổi chủ. O06/O31 tách chủ, thủ quân, ngoại thành, job tiếp quản và phục hồi. Phe NPC tới cùng lúc không tự gộp quân; O10 quyết định pha/thứ tự. Thắng trận không đồng nghĩa tiếp quản xong. Công phá/vây là cách tạo tình thế, đầu hàng có điều khoản còn hoãn.

Trinh sát có thời điểm quan sát, phạm vi thông tin và khả năng cũ đi. Hạng NPC không thay thế trinh sát. Giới hạn mặt trận là đề xuất trước đây, chưa được chốt; thử lợi ích chiến thuật, thiên lệch phòng thủ và khai thác tách nhóm trước khi chọn.

## 8. Tái lập và giao thương

Tái lập dùng cấp công trình hoàn thành hợp lệ theo ảnh nguồn, tỷ lệ và quy tắc làm tròn đã chọn. Không tính theo bậc thành tổng hợp hoặc lấy cấp nâng chưa hoàn tất. Trường hợp công trình thiếu phụ thuộc sau khôi phục cần giữ đường sản xuất và phục hồi sống còn.

Quyền tái lập dùng một lần. Thành cũ còn tồn tại cùng thành mới có thể làm tổng cấp phát triển tăng: đó là nguồn được cấp theo luật, phải ghi nhận, không giả định mọi vật chất/cấp đều bảo toàn tuyệt đối.

Chuyển nội bộ và giao thương với vương quốc NPC là phạm vi khác nhau. O07 giữ bài toán hai phía/kho/hàng/đổi chủ; chưa mở chỉ vì xe đã chạy. Hợp đồng dài hạn còn là đề xuất. Cướp/giao thương là chuyển hàng, không là nguồn tiêu hủy tự động.

## 9. Sổ nguồn và tiêu hao

| Loại | Ví dụ cần theo dõi |
|---|---|
| Tạo mới | Sản xuất nội thành, hồi mỏ, phần tài nguyên NPC được cấp, hỗ trợ khởi đầu/tái lập |
| Chuyển | Cướp, mua bán, vận tải, chuyển kho khi đổi chủ |
| Tiêu hao | Xây, tuyển, nuôi, sửa/phục hồi, phần hàng mất theo luật |
| Tồn tại | Kho, hàng đang đi, khoản giữ, kho NPC và mỏ |

Không cộng phần khoản giữ lần nữa vào tổng tồn. Thuế nếu có là trưng thu/chuyển phân bổ hoặc thay đổi phần sản xuất được nhận, chưa được coi là nguồn thứ năm cộng chồng lên cùng lượng sản xuất.

Mọi báo cáo cân bằng cần lưu cấu hình, đơn vị, nguồn dữ liệu, cơ cấu quân, thời gian thế giới và các hỗ trợ. Ví dụ 50.000/150.000 quân của U02 chỉ minh họa: không dùng cùng bảng kinh tế mẫu để khẳng định nuôi được. Chưa có mô phỏng nào chứng minh các giá trị đó.
