# Quyết định và vấn đề còn mở

Phiên bản 1.3 · 07/11/2026. Mã nguồn R, U và C xem [README](README.md). “Chốt về hướng” không đồng nghĩa đã có công thức đủ để phát hành.

**Thay đổi hiện hành:** D28 chuyển trọng tâm sang một người chơi offline và vương quốc NPC. Các mục về nhiều người thật, tài khoản, PvP và vận hành online bên dưới phải đọc theo phạm vi mới, không kế thừa làm yêu cầu offline.

## 1. Quyết định kế thừa

D01–D18 giữ mã của R01. Bảng sau diễn đạt gọn, không mở rộng quyền hạn của quyết định gốc.

| Mã | Lựa chọn | Trạng thái |
|---|---|---|
| D01 | Webgame chiến thuật xây dựng và điều hành đế chế | CHỐT |
| D02 | Thành có bố cục tròn | CHỐT |
| D03 | Xây trên vị trí cố định, không kéo thả tự do | CHỐT |
| D04 | Một phong cách kiến trúc chung | CHỐT |
| D05 | Hình ảnh đồng nhất, sắc nét | CHỐT |
| D06 | Bốn mùa cảnh quan rõ rệt | CHỐT |
| D07 | Năm quân: kiếm, giáo, cung, kỵ, voi; có tương khắc | CHỐT |
| D08 | Bố trận trước, hệ thống tự giải quyết trận | CHỐT |
| D09 | Kết quả bằng báo cáo, không hoạt cảnh chiến đấu | CHỐT |
| D10 | Mỗi người một đế chế, không bang hội, quân hoặc kho chung | CHỐT |
| D11 | Ngoại giao cá nhân như thư và thỏa thuận | CHỐT VỀ HƯỚNG; hiệu lực cưỡng chế còn mở |
| D12 | Điều quân ra ngoài và lập trại tiền phương | CHỐT |
| D13 | Trại không có thành, phòng thủ yếu hơn thành | CHỐT |
| D14 | Quân trong trại cần lương và tiếp tế vật lý | CHỐT |
| D15 | Nhiều thành, lãnh thổ có màu trên bản đồ lớn | CHỐT |
| D16 | Có thể chiếm thành khi thỏa điều kiện, không chỉ cướp | CHỐT VỀ HƯỚNG |
| D17 | Có thể bỏ thành, đi xa và tái lập | CHỐT VỀ HƯỚNG |
| D18 | Thành tái lập giữ 1/2 hoặc 1/3 cấp phát triển cũ | CHỐT VỀ HƯỚNG; điều kiện chọn tỷ lệ còn mở |

D18 không chia cấp thành bị chiếm, không tự hồi sinh quân hoặc tài nguyên. Không gắn sẵn 1/2 với rút lui và 1/3 với mất thành cuối thành luật chính thức.

## 2. Quyết định bổ sung và đổi hướng

| Mã | Nội dung | Trạng thái và khoảng hở |
|---|---|---|
| D19 | Thế giới tồn tại lâu dài, không reset đế chế theo mùa bắt buộc; lịch sử tiếp diễn | CHỐT. Chưa giải quyết toàn bộ O02 |
| D20 | Công trình, thành, mục tiêu NPC, thành bỏ hoang và Đại thành theo thang 1–20 | CHỐT VỀ HƯỚNG. Thang riêng, cách tính bậc thành và phạm vi ô tài nguyên còn mở |
| D21 | Quân chiếm giữ và khai thác điểm tài nguyên ngoài thế giới | CHỐT VỀ HƯỚNG. Năng suất, trữ lượng, quyền đất và điều kiện hồi chưa khóa |
| D22 | Mỗi thành có hạn mức quân; phát triển thêm thành để mở rộng quân đội | CHỐT VỀ HƯỚNG. Đơn vị tính, thành gốc và chuyển biên chế chưa khóa |
| D23 | Có Đại thành NPC là trung tâm cai trị vùng; không tự sở hữu thành người khác trong vùng | CHỐT VỀ HƯỚNG. Quyền cai trị cụ thể còn mở |
| D24 | Có thể dời trung tâm đế chế về Đại thành sau khi chiếm | CHỐT VỀ HƯỚNG. Nhập thành và chuyển tài sản cần đặc tả riêng |
| D25 | Thưởng Đại thành B: tối đa +20% toàn đế chế, thêm tối đa +20% trong vùng hợp lệ, tổng không quá +40% sản lượng cơ bản tại một nơi | CHỐT. Cộng, không nhân; không nhận lặp. Cơ sở tính và điều kiện hiệu lực còn mở |
| D26 | NPC có thể chủ động quấy nhiễu | CHỐT VỀ HƯỚNG. Loại hành vi, nguồn lực và tần suất chưa khóa |
| D27 | Mở rộng vượt khả năng giữ, nuôi và cai trị phải có đánh đổi; không phạt theo mốc số thành tùy tiện | CHỐT VỀ HƯỚNG. Cơ chế và mức tác động phải thử |
| D28 | Một người chơi offline xây đế chế trong thế giới tiếp diễn qua bản lưu, đối đầu/cạnh tranh với các vương quốc NPC | CHỐT VỀ HƯỚNG theo U05. Không bắt buộc dịch vụ online hoặc mô hình kinh doanh; runtime và các chi tiết thời gian/lưu còn cần đặc tả |
| D29 | Quân tiến hóa rõ về trang bị, hình dáng và khả năng chiến đấu | CHỐT VỀ HƯỚNG theo U08; chưa chốt I–V, các profile và mốc |
| D30 | Có Học viện/nghiên cứu liên kết trang bị, huấn luyện, hậu cần và chinh phục | CHỐT VỀ HƯỚNG theo U08; phạm vi kiến thức và số dự án còn mở |
| D31 | Có nhánh Thánh và nhánh đối lập, năng lực riêng và cách đối phó | CHỐT VỀ HƯỚNG theo U08; chưa chốt tên, ba đường, IV/V hoặc từng kỹ năng |
| D32 | NPC có phân loại/phe/khuynh hướng/quan hệ khác nhau, không một khối chung | CHỐT VỀ HƯỚNG theo U08; tên và bảng quan hệ còn mở |
| D33 | NPC có lực lượng lưu động, không bắt buộc ở thành/trại cố định | CHỐT VỀ HƯỚNG theo U08; ba mô hình đoàn và cap di động chưa khóa |

Tên hiện hành là Crownlands; file gốc mang tên Tam Giới giữ để truy nguồn. Runtime/đóng gói, chư hầu, I–V và kiến thức toàn đế chế còn đề xuất. D31 đã ghi hướng nhánh có năng lực riêng: khuyến nghị cũ Paladin thuần quân sự/hoãn phép không còn là giới hạn dự án. Không suy D31 thành duyệt từng kỹ năng hoặc mana.

## 3. Đề xuất đang giữ

| Mã | Phương án | Trạng thái |
|---|---|---|
| P01 | Tách hạn mức thành gốc và sức chứa nơi đóng; quân đi xa vẫn tính hạn mức gốc; giữ chỗ cho quân đang tuyển | ĐỀ XUẤT chống lách D22 |
| P02 | Tính hạn mức bằng suất biên chế có trọng số theo loại quân | ĐỀ XUẤT; mọi trọng số là THỬ NGHIỆM |
| P03 | Thành mới chiếm đóng góp sản lượng/hạn mức tăng dần theo ổn định | ĐỀ XUẤT |
| P04 | Khu điều hành có năng lực và tải quản trị; quá tải tăng dần, có đường xử lý | ĐỀ XUẤT; không áp dụng phạt toàn đế chế mặc định |
| P05 | Tuyến tiếp tế đặt sẵn có dự trữ, ngân sách, số xe và dự báo thiếu hụt | ĐỀ XUẤT; vận tải vẫn vật lý |
| P06 | Điểm khai thác có trần năng suất, kho hữu hạn và quy tắc trữ lượng/hồi | ĐỀ XUẤT; mô hình hữu hạn hay tái tạo còn mở |
| P07 | Điều kiện nhận thưởng Đại thành: ổn định, kết nối, phạm vi sản xuất và quá trình chuyển chủ | ĐỀ XUẤT; không thay số của D25 |
| P08 | Pause/tự dừng/cảnh báo thay yêu cầu phản ứng theo giờ đời thực | ĐỀ XUẤT offline; giờ nghỉ/khiên online không áp dụng |
| P09 | Lịch sử thế giới, thành tích kinh tế/phòng thủ/hậu cần không cộng sức mạnh | ĐỀ XUẤT |
| P10 | Chuyên môn hóa thành qua vị trí, cấu hình và công năng | ĐỀ XUẤT; chưa có bonus chuyên môn mặc định |
| P11 | Kiến thức toàn đế chế, dự án tại một Học viện, tuyển/nâng tại cơ sở địa phương | ĐỀ XUẤT; thay mô hình theo thành nếu được chọn |
| P12 | Năm dòng I–V; I–III chung, IV/V chuyên hóa thành ba đường | ĐỀ XUẤT; 45 profile chỉ đúng nếu mọi tổ hợp tồn tại, không là scope bắt buộc |
| P13 | Tuyển thẳng bậc mở hoặc nâng một phần; quân đang nâng vẫn bị đánh | ĐỀ XUẤT; chi phí/hủy/suất còn mở |
| P14 | Pause/tua/save cùng đồng hồ; đóng game không chạy bù giờ thật | ĐỀ XUẤT mặc định offline, O32 |
| P15 | Một quy trình tiếp quản, tách sở hữu/kiểm soát; cửa chặn/để ngỏ | ĐỀ XUẤT để thử, không phải đầu hàng có điều khoản |
| P16 | Quân chế/Thánh Quang/Hắc Ảnh là ba đường hoàn chỉnh, tách phe và quan hệ | ĐỀ XUẤT về tên/cấu trúc, không khóa toàn bộ đế chế một nhánh |
| P17 | Năng lực tự kích hoạt trong trận, quỹ hữu hạn, hồi theo đồng hồ thế giới | ĐỀ XUẤT thử nhỏ; không tự thêm mana hoặc phép bấm tay |
| P18 | Đoàn có mission, có căn cứ/tàn quân/du mục với nguồn khai báo | ĐỀ XUẤT; thí điểm có căn cứ trước |
| P19 | Đổi nhánh tại cơ sở, một profile hiệu lực, bảo toàn khóa hồi/suất/tài sản | ĐỀ XUẤT, cùng vòng đời nâng |
| P20 | Quan hệ phe tách khuynh hướng nhánh; thử trung lập/thù địch trước | ĐỀ XUẤT; Thánh/Hắc không tự quyết định địch/bạn |

## 4. Quyết định mở kế thừa

| Mã | Phạm vi còn mở | Cổng cần giải quyết |
|---|---|---|
| O01 | Điều kiện tỷ lệ tái lập, thời điểm chụp cấp, nguồn hỗ trợ và chống lặp | Trước mở tái lập có hậu quả thật |
| O02 | D19/D28 giữ lịch sử qua bản lưu; mục tiêu dài hạn và thử thách vẫn mở, không còn bài toán công bằng người thật mới/cũ | Trước thử chiến dịch dài |
| O03 | Hình ô, quyền đất, liên thông, tranh chấp | Tách hình ô trước dữ liệu bản đồ và chuyển đất trước chiếm thành |
| O04 | Thiếu lương/suy yếu/hao hụt theo thời gian game, cùng preset cho người và NPC | Trước bật hậu quả thiếu lương |
| O05 | Trinh sát, xe, khai hoang, công thành và điều kiện mở | Trước từng tính năng |
| O06 | Điều kiện chiếm, lực lượng, giữ kiểm soát và giải vây | Trước chiếm thành |
| O07 | Giao dịch hai phía, mất hàng, hủy và đổi chủ | Trước mở chợ |
| O08 | Ô xây/khai thác, cấp, giá, thời gian, kho, sản lượng và hoàn hủy | Trước cấu hình thử kinh tế |
| O09 | Chỉ tiêu tự động hóa, quân được tính, ngân sách và quyền | Trước policy/tuyến tự động |
| O10 | Thứ tự sự kiện, phe NPC tới cùng lúc, pause và cửa nhận lệnh | Trước mô phỏng liên hệ và tiếp quản |
| O11 | Hướng dẫn khởi đầu và tái định cư offline; bỏ khiên/bảo vệ cạnh tranh PvP | Trước vòng chơi phục hồi |
| O12 | Nghiên cứu và phụ thuộc công trình sau tái lập | Trước tái lập |
| O13 | Quan hệ với vương quốc NPC, rút quân, đầu hàng/hiệp ước nếu được chọn | Trước cơ chế ngoại giao có hiệu lực |
| O14 | Thời lượng bốn mùa; hiện không có hệ số kinh tế mùa đã duyệt | Trước hoàn thiện mùa |
| O15 | Runtime offline, đồng hồ mô phỏng, lưu/tải, backup/xuất file và quy mô máy cá nhân; không yêu cầu login/server | Trước bản thử có trạng thái lưu |
| O16 | Phát hành hoặc thu tiền nếu sau này có nhu cầu; không là tiền đề làm game cá nhân | Hoãn khỏi phạm vi offline đầu |

## 5. Quyết định mở mới

| Mã | Cần lựa chọn | Cổng |
|---|---|---|
| O17 | Hạn mức theo đầu người hay suất; trọng số, nguồn hạn mức và vai trò cấp thành | Trước tuyển quân có hạn mức |
| O18 | Biên chế cục bộ hay gần quỹ toàn đế chế; chuyển gốc, quá hạn mức, mất thành cuối | Trước nhiều thành và đổi chủ |
| O19 | Sức chứa thành/trại/mỏ; quá tải khi nhiều đoàn đến cùng lúc | Trước triển khai sức chứa |
| O20 | Năng suất, trữ lượng, hồi, kho mỏ, loại quân khai thác và quyền đất | Trước khai thác ngoài thế giới |
| O21 | Quyền cai trị vùng, địa điểm/người nhận thưởng, base và mốc hiệu lực D25 | Trước Đại thành |
| O22 | Đổi đô, giữ thành cũ, thời gian chờ và khả năng nhập thành | Trước dời đô; chưa triển khai nhập thành |
| O23 | Ngân sách, phát hiện mục tiêu, hồi phục và hành vi NPC chủ động | Trước NPC chủ động |
| O24 | Vai trò và cách tính bậc thành/hạng NPC; ô tài nguyên có lên 20 không | Trước khóa cấu hình cấp |
| O25 | Năng lực quản trị có cần thiết không; tải, chi phí và biện pháp phục hồi | Sau mô phỏng hậu cần chưa có thanh quản trị |
| O26 | Thành hoang do thế giới tạo hoặc chủ động bỏ; chuyển tài khoản bất hoạt thành NPC không còn áp dụng offline | Trước cơ chế bỏ thành/thành hoang |
| O27 | Hình thái thế giới, seed, vùng khởi đầu và vị trí/quy mô vương quốc NPC | Trước thử chiến dịch dài |
| O28 | Profile bậc/nhánh, tương khắc lệch bậc, quân thấp, tên và bậc của Paladin | Trước A2′; hướng năng lực D31 không hỏi lại như chưa chọn |
| O29 | Kiến thức đế chế, số dự án, mất Học viện, cơ sở và hiệu ứng trực tiếp của tech | Trước nghiên cứu A2′ |
| O30 | Nâng lô/từng phần/nhảy bậc, tổn thất/hoàn/hủy, mất gốc và thương tích nếu có | Trước nâng quân A2′ |
| O31 | Ngoại thành, lực giữ, cửa/rút, hàng tới, ngắt tiếp quản và nhiều phe | Trước tiếp quản; nhiều phe trước B |
| O32 | Pause/cửa lệnh/thứ tự, lưu nguyên vẹn, tốc độ/tua và migration save | Trước bản thử có lưu |
| O33 | Mốc kết thúc/tiếp tục sandbox, nhịp chiến dịch và chư hầu nếu xét | Không chặn A1; trước mở rộng dài hạn |
| O34 | Nhánh, mốc mở, chuyển/trộn, cơ sở và phạm vi kiến thức nhiều nhánh | Trước nhánh A2′ |
| O35 | Trigger/target/pha/trần/stack/dispel, hai đồng hồ, nguồn chết, quỹ và khóa hồi | Trước năng lực A2′ |
| O36 | Nguồn đoàn, căn cứ/lưu vong/du mục, cap/bổ sung/định cư/giải tán | Trước từng loại đoàn; cap mobile chưa dùng cho người chơi |
| O37 | Địa điểm chạm trán, đường đi, phát hiện/truy đuổi; có chấp nhận hoãn trận giữa đường | Trước L/B, trước mở thiết kế đoạn đường |
| O38 | Phe/quan hệ/khuynh hướng, qua biên, phản ứng, ngân sách/trần và nhiệm vụ | Trước hành vi phe/đoàn tương ứng |

## 6. Không tự chuyển thành luật

- Không chốt trần cứng 5–12, 20 hoặc 30 thành.
- Không coi quân ngoài thành đã giải phóng hạn mức; P01 vẫn cần đặc tả chính thức.
- Không áp số 50.000/150.000 quân minh họa thành mục tiêu kinh tế.
- Không đổi 20/20/40 theo ý reviewer. Nếu cần đổi phải có quyết định thay D25.
- Không đồng nhất mọi thực thể cấp 20 về sức mạnh.
- Không biến quyền cai trị vùng thành thuế/điều khiển tài sản người khác.
- Không tự thêm quân thứ sáu, vàng bắt buộc, bang hội, hoạt cảnh hay reset mùa.
- Không áp giờ nghỉ, giới hạn mặt trận hoặc tài khoản bất hoạt thành NPC như nội dung đã duyệt. Hướng mới một người với NPC thay bối cảnh PvP cũ, nhưng không tự duyệt toàn bộ preset đã đề xuất.
- Không biến đồng thuận agent thành quyết định D. I–V, ba đường/tên nhánh, 14/45 profile, từng kỹ năng, một dự án, cap di động, cửa tiếp cận và thứ tự cùng mốc đều còn đề xuất. D29–D33 chỉ ghi hướng U08 nêu là đã chọn.
