# Định hướng và vòng chơi

Phiên bản 1.3 · 07/11/2026. D28 ghi hướng một người offline. Mọi cơ chế mới chưa có quyết định D là đề xuất để thử, không phải luật đã cân bằng. Đọc trước [khung lối chơi](gameplay-blueprint.md).

## 1. Trải nghiệm cốt lõi

Người chơi xây một đế chế trong thế giới tiếp diễn qua bản lưu, cạnh tranh với vương quốc NPC có thành, kinh tế và mục tiêu riêng. Không yêu cầu server nhiều người, tài khoản trực tuyến hoặc mô hình kinh doanh.

Vòng lõi: xây thành → kinh tế → quân → mỏ/cứ điểm → vận tải → chiến dịch → tiếp quản → củng cố hoặc rút → lưu và tiếp tục. Đạt cấp 20 không reset thế giới. Một cuộc thắng lớn có thể là mốc thành tựu tự nguyện, chưa bắt buộc kết thúc bản lưu.

## 2. Trụ cột

| Trụ cột | Biểu hiện | Cần thử |
|---|---|---|
| Phát triển nhìn thấy | Thành tròn, ô cố định, cấp và quân có diện mạo tiến bộ | Có tạo mục tiêu hấp dẫn thay vì chỉ tăng số? |
| Tổ chức một đế chế | Kho/quân/đất có chủ rõ, quyết định tại từng địa điểm | Quản nhiều thành có còn dễ hiểu? |
| Hậu cần có ý nghĩa | Xe, trại, kho và lương thực tại chỗ | Có lựa chọn thay vì chỉ bấm gửi lương? |
| Mở rộng có đánh đổi | Mặt trận thật, đường xa, quân/xe bị ghim, phục hồi | Khi nào nên dừng mở rộng? |
| Thất bại có đường về | Rút, thu hẹp và tái lập D17/D18 | Người chơi có kế hoạch tiếp theo không? |
| Thế giới NPC | Các phe có thể tranh mục tiêu với nhau | Không cùng phe chống người chơi, không đứng im/tự sát? |

## 3. Nhịp offline đề xuất

Pause dừng mô phỏng; tăng tốc áp mọi bên; đóng game không chạy bù thời gian thật. Lưu tay, tự lưu luân phiên và xuất backup là phương án đề xuất, chưa khóa runtime. Thời gian chơi không bị thiết kế quanh đăng nhập hàng ngày.

Dùng một đồng hồ game và thứ tự xử lý rõ. Tua nhanh không xóa lương, nguồn cung hoặc cơ hội đã mất trong game. Cần đo thời gian giữa các quyết định có nghĩa, không buộc người chơi để máy chạy chỉ để hết thanh xây.

## 4. Chiến dịch và chinh phục

Công phá hoặc duy trì kiểm soát để gây sức ép; bên thủ có thể đánh ra, nhận viện binh hoặc rút. Vây chỉ cắt nguồn thật sự mất kiểm soát. Thắng trận, giữ ngoại thành, tiếp quản và cai trị là các việc khác nhau.

Một quy trình tiếp quản dùng cho mọi trường hợp đủ điều kiện, không có ba hệ chuyển quyền riêng. Rút quân có thể để lại thành cho đối phương chiếm mà không giết hết thủ quân; chưa có đầu hàng chính thức hoặc hòa ước nhiều điều khoản ở bản thử.

Người chơi có thể chiếm mỏ rồi dừng hoặc bỏ thành xa để củng cố. Quy trình rút bỏ lãnh thổ có tổ chức vẫn là đề xuất, không tự tạo thành mới/quyền tái lập từ mỗi thành bỏ lại.

## 5. Tiến hóa quân

Giữ năm dòng kiếm/giáo/cung/kỵ/voi, bố trận và báo cáo. I–V là đề xuất bậc trang bị/huấn luyện, khác cấp công trình và hạng NPC. Nghiên cứu chỉ mở khả năng; cơ sở địa phương, chi phí, biên chế và hậu cần quyết định quân thực tế.

D29/D30 ghi hướng tiến hóa/Học viện; D31 chọn Thánh và đối lập có năng lực. Ba đường và I–V còn đề xuất, không 45 profile ngay. Xem [quân/nghiên cứu](military-and-research.md) và [năng lực](combat-abilities.md). Nghiên cứu toàn đế chế/một dự án/đổi nhánh là phương án cần thử, không tự đổi mọi quân khi nghiên cứu xong.

## 6. Quy mô, ngoại giao và mục tiêu dài hạn

Không có trần số thành đã duyệt. Đế chế lớn tổ chức tốt được mạnh hơn; không cộng phạt theo thành thứ 30. Công cụ giảm thao tác được thiết kế từ đầu, không lấy việc bấm nhiều làm hình phạt quy mô.

Không có nhóm nhiều người/quân/kho chung. D32 chọn NPC có phe/khuynh hướng/quan hệ; D33 chọn đoàn lưu động. Phe, nhánh và quan hệ tách biệt; [đoàn có nhiệm vụ và hậu cần thật](mobile-npcs.md), không chỉ icon. Giao thương/đình chiến/chư hầu còn phạm vi sau; hỗ trợ độ khó phải khai báo, không sinh quân vì người chơi mạnh.

Lịch sử, thành tựu hậu cần, giữ vùng và chinh phục là mục tiêu đề xuất. Khi đã thắng đủ lớn, cho phép ghi thành quả và chơi tiếp là một phương án; không ép suy thoái hoặc reset để kéo dài game.

## 7. Thất bại và phục hồi

D17/D18 giữ hướng di dân/tái lập với 1/2 hoặc 1/3 cấp phát triển theo điều kiện sẽ chọn, không hồi sinh quân hoặc chia cấp thành người thắng nhận. Quân ở xa không dịch chuyển tới thành mới.

Bản thử có thể dùng tải lại khi mất thành cuối; đó là giới hạn lát cắt, không thay D17/D18 bằng chỉ load ở bản đầy đủ. Save/load là quyền người chơi offline, không cần chống gian lận cạnh tranh.

## 8. Phạm vi và đánh giá

Đề xuất A1 vòng lõi; A2′ thử tiến hóa/nhánh; L một đoàn có căn cứ; B nhiều phe và một ca tàn quân. Không hoãn tuyệt đối hướng năng lực mới. Hoãn đủ 45 profile/V/sáu cây, thuế/An dân, dự bị/tự quản, item/XP, du mục, công thành và ngoại giao phức tạp; Đại thành/thưởng B/dời đô/tái lập giữ dài hạn.

Người thử phải hiểu vì sao thua, thiếu lương hoặc bỏ mục tiêu; có thể chọn cách khác trong hoàn cảnh khác và muốn thử lại. Số giờ chơi, login hay số nhà nâng không tự chứng minh game vui. Hiện chưa có kết quả thử.
