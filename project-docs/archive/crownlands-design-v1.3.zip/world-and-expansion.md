# Thế giới và nghịch lý mở rộng

Phiên bản 1.3 · 07/11/2026. D19/D27 giữ hướng, D28 đổi sang offline. Cơ chế còn là đề xuất. Căn cứ U02, review mở rộng và [tổng hợp offline](reviews/2026-11-07-cross-review-resolution.md).

## 1. Nguyên tắc

Chiếm thành tăng tiềm lực nhưng cũng tăng nghĩa vụ bảo vệ, nuôi quân và cai trị. Đế chế yếu đi khi những nghĩa vụ đó vượt khả năng thực tế, không vì chạm một con số thành định sẵn.

Đế chế 30 thành được tổ chức tốt vẫn có thể mạnh hơn nhiều so với 10 thành. Mục tiêu là tạo rủi ro cho mở rộng không đủ chuẩn bị, không bảo đảm người nhỏ luôn thắng hoặc trừng phạt mọi người chơi lớn.

Không có trần số thành đã duyệt. Không dùng khối lượng bấm lặp làm hình phạt quy mô. Một cơ chế không tạo lựa chọn ngoài việc duy trì một thanh chỉ số dưới ngưỡng cần được xem lại.

## 2. Ba lớp chi phí cần tách

| Lớp | Ví dụ đề xuất | Lựa chọn cần tạo | Giới hạn |
|---|---|---|---|
| Mở mới | Giữ thành vừa chiếm, khôi phục kho/phòng thủ, nối vận tải | Đánh tiếp hay củng cố; chọn thành nào trước | Chỉ trì hoãn lợi ích, không tự hãm người đã ổn định |
| Duy trì | Quân ăn lương, xe đang đi, hạ tầng và chi phí điều hành nếu được chọn | Dồn nguồn lực ở đâu, bỏ tài sản nào không đáng giữ | Có thể biến thành thuế cố định mà người giàu dễ trả |
| Mặt trận | Đối thủ hoặc NPC thực sự có thể đánh vào tài sản | Giữ quân, cơ động, chọn vị trí và đường rút | Chỉ có tác dụng khi tồn tại mối đe dọa có thật |

Không ghi “mỗi thành cần X quân” như quota bắt buộc. Nhu cầu giữ thành là quyết định người chơi dựa trên nguy cơ có thể quan sát. Một bảng dự báo rủi ro không được tự trừ chỉ số khi người chơi không làm theo.

Các ví dụ quân giữ và quân rảnh trong U02 là lựa chọn minh họa của chủ đế chế, không phải số do game thu của người chơi.

## 3. Địa lý và khả năng tập trung

Một cụm thành liền mạch có thể chia sẻ các hướng phòng thủ và tuyến ngắn; các thành rải rác tạo nhiều mặt trận và chuyến đi dài. Phải tính bằng bản đồ, thời gian di chuyển và khả năng tiếp cận thực tế, không chỉ chu vi màu hay số ô sở hữu.

Đánh giá hành lang đất, vùng đệm và địa hình khiến một cứ điểm khóa cả vùng. Điểm nguy cơ chỉ trợ giúp giao diện theo tình báo hợp lệ; không đọc quân bí mật. Không còn yêu cầu nhận diện tài khoản phụ trong offline.

Quân tại một mặt trận còn chịu sức chứa, lương mang theo, thông lượng vận tải và thời gian quân rút từ nơi khác đến. Tổng quân đế chế không phải số quân có thể duy trì ở bất kỳ mục tiêu nào.

## 4. Thành mới chiếm và năng lực quản trị

P03 đề xuất thành mới chưa phát huy đầy đủ ngay. Chọn rõ đại lượng nào phục hồi: sản lượng, hạn mức, khả năng ra lệnh hay quyền đất. Không gộp mọi thứ vào một thanh ổn định rồi âm thầm đổi nhiều luật.

P04 đề xuất tải quản trị theo bất ổn, chia cắt và khó tiếp cận, có phần theo quy mô nếu thật sự cần. Năng lực có thể đến từ trung tâm và đầu tư. Hai yêu cầu thiết kế cần kiểm tra:

- Thành mới không tự cộng vừa đủ năng lực để vô hiệu toàn bộ gánh nặng mà nó tạo ra.
- Củng cố, tổ chức vùng và giảm cam kết có tác dụng; không có ngưỡng đột ngột làm đế chế mất nửa sức mạnh.

Ưu tiên thử hậu cần và mặt trận **chưa có thanh quản trị**. Chỉ thêm mô hình quản trị nếu nó giải quyết một vấn đề đo được mà hai lớp kia chưa giải quyết. Không mặc định thêm thuế, An dân và sĩ khí cùng lúc.

## 5. Bài toán đế chế lớn đã ổn định

Đây là ca khó nhất, không phải ca ngoại lệ. Một đế chế giàu, có mạng lưới tốt và không gặp đối thủ ngang tầm có thể trả mọi chi phí duy trì. Phạt mở nóng không giải quyết được tình trạng đó.

Các câu hỏi chưa có đáp án:

- Lợi ích biên của thành tiếp theo còn vượt chi phí và rủi ro bao nhiêu?
- Đối thủ nhỏ có mục tiêu giới hạn đáng đánh hay bắt buộc phải thắng toàn bộ quân địch?
- Tài sản nào có thể bị tranh chấp bằng lực lượng thật mà không cần theo dõi game suốt ngày?
- Người mới có vùng phát triển đủ tài nguyên và mục tiêu hay chỉ được đặt vào đất yếu?
- Các nguồn mới từ mỏ, NPC và Đại thành làm khoảng cách tăng nhanh đến đâu?

Không có kết luận hiện tại rằng Crownlands đã chống được độc bá. Nếu mô phỏng cho thấy tất cả lựa chọn đều dẫn tới một người thống trị không thể bị thách thức, cần quay lại cơ chế kinh tế/quyền lực, không giải quyết bằng NPC bí mật mạnh lên theo người dẫn đầu.

## 6. Vòng lặp thắng và nguồn tài sản

Vòng cần kiểm tra: thêm thành → thêm hạn mức quân → giữ thêm mỏ/NPC → thêm thu nhập → chiếm Đại thành → thưởng sản lượng → thêm thành.

Trần +40% của D25 chỉ ngăn cộng thưởng Đại thành vô hạn. Một tỷ lệ thưởng vẫn mang lại lượng tuyệt đối lớn hơn cho đế chế có nhiều cơ sở sản xuất. Điều kiện áp dụng, thời điểm hiệu lực và nguồn sản xuất được hưởng chưa khóa.

Theo dõi riêng tài nguyên tạo mới, chuyển chủ, tiêu hao và tồn kho theo [đặc tả hệ thống](systems-and-balance.md). Khai thác có hồi và ngân sách NPC đều có thể tạo mới tài nguyên; “có quỹ” không tự chứng minh kinh tế bền vững.

Nếu cần thay số hoặc phạm vi lợi ích đã chốt, tạo quyết định thay thế D25 với tác động dữ liệu và cấu hình. Không sửa ngầm bằng công thức.

## 7. Chiến dịch, thất bại và lịch sử

D19/D28 giữ thế giới qua bản lưu. Theo P14, pause/đóng game không làm thế giới chạy thêm; mùa không xóa thành. Chưa cần cân bằng người thật mới đến ngày 60 hoặc mở đất để phục vụ mật độ tài khoản.

Đề xuất tạo thế giới theo seed/preset, các vương quốc có vị trí và nguồn lực được ghi. Người chơi có thể chọn tiếp tục sau một mốc chiến thắng. NPC mạnh lên do luật và tài nguyên của nó, không do bí mật đo số thành người chơi rồi tăng quân.

Khi đã áp đảo, giữ thành quả; không ép sụp đổ để kéo dài. Nếu cuối game thành việc dọn lặp, thử mốc kết thúc tự nguyện hoặc công cụ chiến dịch trước khi tăng sức địch.

D17/D18 giữ đường tái lập; bản thử load khi mất thành cuối chưa thay hướng bản đầy đủ. Quân ở xa không teleport, thành mới và nguồn hỗ trợ có sổ riêng.

## 8. Bỏ gánh vận hành nhiều người

Không có tài khoản phụ, tranh chấp tài khoản, chống save-load hoặc phạt người chơi tự sửa save. Giữ kiểm tra quân/hàng/biên chế để luật mô phỏng không tự nhân hoặc làm mất tài sản.

Các bài cũ về nhiều tài khoản và người chơi bất hoạt chỉ còn lịch sử review, không là yêu cầu offline. NPC không có thành không tự mất mọi quân: giữ chủ và cùng luật lương/hành động. Mốc chiến thắng không bắt buộc truy sát hết tàn quân nếu không có mục tiêu đó.

## 8.1. Đoàn lưu động và nhánh trong thế giới dài

D31–D33 thêm hướng năng lực và phe/đoàn, không thay giới hạn tài sản hoặc tự hãm đế chế lớn. Mỗi đoàn có mission, nguồn quân/lương và ngân sách; xem [đặc tả đoàn](mobile-npcs.md). Không cấp cap du mục cho quân mất gốc, không spawn để kéo người thắng xuống.

Hồi ngân sách/nguồn đoàn là tạo mới được ghi. Theo dõi đoàn sống, mission/event còn hiệu lực và lịch sử đã tổng hợp; không xóa quân hiện hữu để dọn máy hoặc đòi save phải bằng đúng một kích thước vĩnh viễn.

## 9. Tiếp thu phản biện

| Ý kiến Claude | Cách ghi vào bản hiện hành |
|---|---|
| Chỉ phạt mở nóng chưa đủ | Tách ba lớp chi phí; bắt buộc thử đế chế lớn ổn định |
| Quota quân giữ theo biên giới dễ bị lách | Không ghi thành luật; giữ nguy cơ thật và quyết định phòng thủ của người chơi |
| 20/20/40 chưa chặn vòng lặp thắng | Giữ số đã chốt; đưa điều kiện thưởng và ca mất Đại thành vào mô phỏng |
| Đổi biên chế có thể thành quỹ chung | Ghi O18, không giả vờ đã có giới hạn cục bộ không lách được |
| Mỏ dùng lính biến quân rảnh thành thu nhập | Tách khai thác/giữ/lương/vận tải; thử trần và mô hình hồi |
| Quản trị dễ thành thuế | Chạy phương án chưa có thanh quản trị để so sánh |
| Cần kho mỏ và quỹ NPC hữu hạn | Giữ là đề xuất; ghi rõ nguồn hồi để tránh hiểu là hữu hạn vĩnh viễn |
| Tạm ngưng thưởng lúc bị vây, giảm dần sau mất | Chưa tiếp thu làm luật: cần chặn quấy rối giá rẻ và thưởng trùng hai chủ |

Kịch bản, dữ liệu cần đo và tiêu chí trước thử xem [lộ trình kiểm chứng](roadmap-and-validation.md).
