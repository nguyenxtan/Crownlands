# Lộ trình và kiểm chứng offline

Phiên bản 1.3 · 07/11/2026. Kế hoạch ĐỀ XUẤT sau review chéo. **Chưa có ca game, mô phỏng, benchmark hoặc playtest nào chạy trong lần biên tập.** Kiểm tra link/hash tài liệu không phải kiểm thử game.

## 1. Các lát cắt theo U08

| Lát cắt | Nội dung | Bằng chứng cần có |
|---|---|---|
| A1: vòng lõi | Một vùng/NPC hai thành, trung lập, năm dòng I, xây/mỏ/xe/trại/trận/tiếp quản/lưu | Chơi được chuỗi có thành thứ hai và tiếp tục save |
| A2′: nhánh dọc | Kỵ I–III + IV ba nhánh và bốn dòng khác I–II: ứng viên 14 profile; ít công nghệ/một dự án; Hộ trận/Phá ấn/trang bị | Tiến hóa/nhánh đổi quyết định, quỹ/hồi/suất không bị nhân, báo cáo đọc được |
| L: đoàn có căn cứ | Một patrol 3–4 địa điểm có nguồn quân/hàng/lương/mission, biết tránh/rút | Đoàn tác động lựa chọn, không chỉ icon; không bí mật biết vị trí |
| B: nhiều phe | Phe thứ hai khác khuynh hướng, relation cấu hình, một case tàn quân/mất thành | NPC cạnh tranh nhau, không moral auto-target, tàn quân không có suất mới |

A2′ thay ứng viên 10/12 profile của 1.2. 14 profile là đề nghị để thử, chưa duyệt; không kết luận 45 đã cân bằng. A2′ và L có thể thử riêng sau A1. Các tên V/Paladin chưa cần bấm đủ mốc chỉ để kiểm chứng Hộ trận; scenario thử phải có nguồn và giới hạn rõ.

A1 chưa chứng minh AI độc lập hoặc năng lực vui. Load khi mất thành cuối ở lát cắt không thay D17/D18 dài hạn.

## 2. Các bước sau nếu vòng lõi có giá trị

Nhiều thành và phục hồi → Đại thành/quyền vùng/thưởng 20–20–40 → dời đô/tái lập → chiến dịch dài và mục tiêu tự nguyện. Thứ tự chi tiết cần theo phụ thuộc và kết quả thử.

Hoãn đủ 45 profile/V/sáu cây, Thanh tẩy/Nguyền toàn bộ, công thành phức tạp, đầu hàng/hiệp ước, chư hầu, trận/hộ tống trên đường, NPC tự chọn trại, du mục/cap mobile, item/XP, bảo dưỡng ngoài lương và bảy ý tưởng tổ chức. Không hoãn tuyệt đối hướng Thánh/đối lập mới; không loại mục tiêu dài hạn vì chưa có ở A1.

## 3. Cổng trước khi chạy

- Chọn preset O04/O10/O17–O20/O31/O32 và ghi đơn vị, chi phí, lương, nguồn tài sản, topology và quy mô thử.
- Quy định mất điều kiện tiếp quản, cổng/rút, điểm hàng quay về/kẹt và nhiều bên nếu bật.
- A2′ cần O28–O30/O34/O35: profile/nhánh, kiến thức/cơ sở, nâng/chuyển, quỹ/hồi, suất và hoàn/hủy. L/B cần O36–O38 về nguồn/mission/tầm nhìn/chạm trán. Không để thiếu expected outcome rồi tự xử mất quân.
- Engine offline cần save/restore nguyên vẹn trước thử dài, không dựng login/API/cloud như tiền đề.
- R02/R05 nhắc CSV nhưng bảy file nguồn không có. Cần tạo/kiểm tra fixture, không tuyên bố đã có đủ đầu vào T01–T70.
- Placeholder cho phép thử luật; tỷ lệ bản đồ và ký hiệu NPC cần test riêng trước sản xuất asset.

## 4. Danh mục kiểm chứng theo nguồn

| Nguồn | Phạm vi | Cách dùng |
|---|---|---|
| R05: T01–T70 | Luật/tài sản nền | Giữ các ca áp dụng; loại yêu cầu vận hành nhiều người, không đánh số lại mã gốc |
| [Review chinh phục vòng 1](reviews/2026-11-07-offline-conquest-round-1.md): K1–K12 | Phản ví dụ ban đầu | Một số mặc định đã bị rút; đọc cùng vòng 2, không cài nguyên xi |
| [Review vòng 2](reviews/2026-11-07-offline-conquest-round-2.md): C1–C15 | Kiểm soát, cửa/rút, AI, clock/save | Cập nhật theo các sửa của review quân và tổng hợp cuối |
| [Review quân](reviews/2026-11-07-military-progression-review.md): M1–M12 | Bậc, nghiên cứu, nâng và chi phí | Chưa chạy; không biến dự đoán về tỷ số suất thành điều kiện đúng mặc định |
| [Tổng hợp 1.2](reviews/2026-11-07-cross-review-resolution.md) | Chinh phục/quân trước U08 | Giữ phần không bị nguồn mới thay |
| [Review C07](reviews/2026-11-07-branches-and-mobile-npcs-review.md): N1–N15 | Nhánh/hiệu ứng/đoàn | Chưa chạy; mã có scope C07, không trùng bất biến N01–N20 |
| [Đối chiếu C08](reviews/2026-11-07-branches-and-mobile-npcs-resolution.md) | Sửa cuối và phạm vi 1.3 | Đọc ưu tiên cùng D29–D33 và đặc tả hiện hành |

Các mã K/C/M thuộc file review riêng, không phải milestone M cũ hoặc test đã viết. Đồng thuận agent chưa phải tiêu chí đạt thực nghiệm.

## 5. Thử thế giới lâu dài

Giữ các câu hỏi của S1–S15 v1.1 có ích: đế chế nhỏ/ổn định/mở nóng; liền/rải rác; mỏ nhiều chu kỳ; nhận/mất Đại thành; mất gốc và phục hồi; cơ cấu quân; thiệt hại nhiều mặt trận; quấy rối nhỏ; thưởng trùng hai chủ.

S6 tài khoản phụ và S12 người thật vào muộn/bất hoạt không áp dụng theo D28. Không tái dùng mã cho ý nghĩa khác. Phần offline cần thử thế giới theo seed, NPC có nguồn lực, và đế chế lớn đã ổn định nhưng được quyền thắng.

Nếu so NPC khi người chơi có quy mô khác, giữ các điều kiện đối chứng liên quan. Không tự yêu cầu NPC giống hệt khi hàng, đất hoặc hành động hợp lệ của thế giới đã tác động khác; yêu cầu là **không có tăng sức bí mật theo số thành người chơi**.

Đo nguồn tạo mới/chuyển/tiêu/tồn, throughput, suất/loại/bậc, quân bị ghim, chi phí biên so với ở nhà, số lệnh và thời gian giữa hai quyết định có nghĩa. Quân ở nhà cũng ăn lương; không tính toàn bộ lương như chi phí tăng thêm của vây.

## 6. T71–T96 chuyển tiếp từ bản 1.1

Giữ mã để truy nguồn. Các ca chỉ có nghĩa khi bật tính năng liên quan; T95 bị bãi bỏ theo D28. Toàn bộ danh mục còn là đề xuất, chưa triển khai/chưa chạy.

| Mã | Tình huống | Kết quả cần kiểm tra |
|---|---|---|
| T71 | Quân ra trại/mỏ, thành gốc gửi lệnh tuyển tiếp | Không giải phóng suất bằng vị trí nếu chọn P01 |
| T72 | Hai tab tuyển khi gần chạm hạn mức | Chỉ giữ số suất thực sự còn; không vượt do cạnh tranh |
| T73 | Tuyển hoàn thành từng phần rồi hủy/thử lại | Suất giữ chuyển sang hiện hữu đúng một lần |
| T74 | Tách/gộp quân từ nhiều thành | Giữ chủ, số lượng và nguồn gốc; không tạo suất |
| T75 | Hai lệnh chuyển biên chế cùng dùng chỗ trống | Không dùng cùng hạn mức nhận hai lần |
| T76 | Thành gốc đổi chủ khi quân đang đi | Không xóa quân/chuyển quân cho chủ mới; áp preset quá hạn mức |
| T77 | Nhường thành rồi tái lập và tuyển tiếp | Không rửa nguồn hạn mức hoặc cấp hỗ trợ nhiều lần |
| T78 | Nhiều đoàn tới địa điểm sắp đầy | Áp đúng luật O19, không ghi âm hoặc xóa quân tùy tiện |
| T79 | Thêm quân khai thác vượt điểm bão hòa | Không vượt năng suất/trữ lượng của preset |
| T80 | Kho mỏ đầy, hàng không có xe | Hàng không tự về thành; không cấp vượt kho theo luật |
| T81 | Quân rời mỏ đúng mốc sản xuất | Tính theo đoạn; một người không khai thác ở hai nơi |
| T82 | Điểm mỏ đổi quyền khi xe/quân đang tới | Hàng/quân giữ đúng chủ và trạng thái theo O20 |
| T83 | Nhiều Đại thành cùng có hiệu lực tại một nơi | Không cộng lặp; toàn đế chế/vùng/tổng đúng trần |
| T84 | Chuyển chủ Đại thành đúng mốc tính sản xuất | Tính theo đoạn, không thưởng hồi tố hoặc phát hai lần |
| T85 | Dùng 20% và 20% trên cùng cơ sở | Thưởng cộng 40%, không 44%, không tự thưởng lên thưởng |
| T86 | Chủ Đại thành gửi lệnh tới thành khác chủ cùng vùng | Từ chối; quyền vùng không sinh quyền tài sản |
| T87 | Đổi đô liên tiếp hoặc gửi lại cùng lệnh | Không cộng công trình/kho/quân/quyền tái lập |
| T88 | Bật/tắt thưởng lúc bị vây, hồi phục/ân hạn | Không quấy rối nhỏ vô hạn hoặc nhận trùng hai chủ theo preset |
| T89 | NPC phản công và handler chạy lại | Nguồn quân/kho/ngân sách chỉ bị ghi một lần |
| T90 | NPC cạn ngân sách hoặc nguồn hồi | Không tự tạo quân/hàng ngoài nguồn đã cấu hình |
| T91 | Ô rỗng, nhà cấp 1, thành bậc 20, NPC hạng 20 | Không đổi nhầm thang hoặc công thức tái lập |
| T92 | Bốn mùa chuyển trong thế giới đang chạy | Không reset tài sản/chủ quyền hoặc đổi hitbox |
| T93 | Zoom rộng với nhiều thành, mỏ và trại | Nhận ra loại/chủ, nhãn không che; không render nội thành khổng lồ |
| T94 | Chọn NPC chưa trinh sát bằng UI và gọi API trực tiếp | Không lộ quân/kho riêng; tin cũ có thời điểm |
| T95 | KHÔNG CÒN ÁP DỤNG: chuyển tài khoản bất hoạt thành NPC | Bỏ theo D28; không tái dùng mã này cho cơ chế khác |
| T96 | Dừng tiến trình rồi restore cùng lịch/ledger | Đối soát quân, suất, kho, quyền, thưởng và sự kiện |

## 7. Ca bổ sung sau review

- Thành đang phục hồi bị vây lại; chiếm lại không tạo kho/cấp mới.
- Ảnh hưởng cổng khi quân/hàng/tiếp quản cùng mốc; đổi lập trường không bắt lại quân đã rời.
- Quân đang nâng bị đánh/hủy/hoàn tất/capture/load cùng mốc; giải phóng suất của quân chết đúng một lần.
- Mất thành gốc khác địa điểm nâng; không mượn suất của chủ mới hoặc bỏ kiểm tra ngầm.
- Dự báo nhiều lần không sửa state/PRNG; tin mới/cũ làm đổi quyết định hợp lý.
- Cùng save/ruleset/lệnh cùng mốc/pha/thứ tự ở các tốc độ thì đồng nhất; lệnh khác mốc được phép khác.
- Tua qua nhiều ngày vẫn phản hồi và ghi đủ sự kiện; không có vòng event không tiến thời gian.
- Restore bản lưu có quân/hàng đi và job dở; hỏng lần ghi mới vẫn khôi phục được bản cũ.

Các test này chưa có mã mới để tránh hiểu nhầm đã có fixture hoặc implementation. Trước viết test cần chốt expected outcome của preset.

## 7.1. Phản chứng nhánh và đoàn

C07:N1–N15 chưa chạy. Bổ sung ca quỹ dùng chung bị nhiều mục tiêu rút cùng lượt; so chia nhóm giữ bố trận/sẵn sàng; đổi từ cooldown dài sang ngắn và đi qua nhánh bị động; nguồn chết giữa trận; quân thấp/Quân chế vẫn có cách phù hợp.

Thử patrol mất riêng thành gốc nhưng phe còn thành, mất hết thành còn quân, tàn quân không nhận cap/tuyển, du mục nếu bật có nguồn rõ. Đoàn qua nhau trên đường không có trận; tới địa điểm mới xét; chase không theo tọa độ bí mật.

Chạy dài cần đối tượng/event sống trong trần cấu hình và nguồn, không đòi kích thước save phẳng khi lịch sử hợp lệ tăng. Lịch đói không bị mất vì chỉ lên một bước mission. Không có kết quả nào của các ca này trong lần biên tập.

## 8. Playtest và tiêu chí sửa thiết kế

Thử nhỏ với người ít chơi game và người hiểu chiến thuật. Cho mục tiêu mở để họ tự chọn lực lượng/đường/điểm dừng; ghi mỗi lần người điều phối phải gợi ý. Thay từng biến thể, không đổi toàn bộ kinh tế và trận cùng lúc.

Đạt về thiết kế khi người thử hiểu vì sao thắng/thua/đói, nhìn ra lựa chọn khác và muốn thử lại. Nếu đánh ngay/chờ/nâng bậc cao nhất luôn là đáp án, hậu cần chỉ là bấm lặp hoặc AI không có hành vi hợp lý, xem lại luận điểm trước khi thêm hệ thống.

Có quyền kết thúc thỏa mãn khi đã mạnh. Không áp chỉ tiêu giữ người, đăng nhập ngày hoặc chống người chơi load để thử chiến thuật.

Mục tiêu server p95/RPO/RTO cũ không là cổng offline. Đo thao tác, tua, save/restore trên cấu hình máy công bố; chưa có số đạt. Ghi tiêu chí và ngưỡng trước mỗi lần thử.
