# NPC và Đại thành

Phiên bản 1.3 · 07/11/2026. D28 chuyển sang offline; D21/D23–D26 giữ hướng. Điều kiện cụ thể và controller còn đề xuất. Xem [khung lối chơi](gameplay-blueprint.md) và [quân/nghiên cứu](military-and-research.md).

## 0. Phe, địa điểm và đoàn trong offline

NPC địa phương và vương quốc là tầng tổ chức; địa điểm và đoàn là hình thức hoạt động khác. D32/D33 chọn phe/quan hệ và lưu động. Một phe có thể có thành lẫn đoàn; path_bias chỉ ưu tiên, relation quyết định địch/trung lập. Nhãn Thánh/Hắc không tự quyết thái độ. Xem [phe và đoàn](mobile-npcs.md).

Controller theo luật chạy cục bộ, ngân sách đầu tư nền, kiểm tra lương/đường về và cam kết chiến dịch. Trinh sát/đổi mục tiêu/đầu tư là hành động hợp lý khi chưa thể đánh; không hạ điều kiện khả thi chỉ vì lâu chưa tấn công. Dự báo dùng tin được biết, không tiên tri.

A1 một vương quốc/mục tiêu trung lập; A2′ thử nhánh theo scenario có nguồn; L một đoàn có căn cứ; B thêm phe thứ hai và case tàn quân. Chưa kết luận NPC độc lập từ A1. Các hạn chế tuyển thẳng/danh sách nghiên cứu có nhãn không cho phép cấp bậc/nhánh miễn phí ngoài setup.

Mất gốc khi còn thành khác khác mất hết thành. Quân giữ chủ và nguồn; có thể chờ/chuyển biên chế hoặc thành tàn quân theo O18/O36, không tự được cap du mục. Đoàn lưu vong là cách tổ chức đề xuất của phần còn sống, chưa hệ phục quốc đầy đủ. Không xóa quân để dọn hoặc bắt săn hết tàn quân để chơi tiếp.

## 1. Loại địa điểm

| Loại | Vai trò | Phân biệt cần giữ |
|---|---|---|
| Trại NPC | Mục tiêu chiến lợi phẩm, có thể tham gia quấy nhiễu theo luật | Không phải thành có quyền sở hữu dân sự |
| Điểm tài nguyên | Quân chiếm giữ để khai thác và chở hàng về | Quân giữ, kho, trữ lượng và chủ quyền là các vấn đề riêng |
| Thành bỏ hoang | Công trình cũ và lực lượng chiếm giữ; có thể chiếm/tái thiết | Tạo theo thế giới hoặc bỏ thành theo luật; không do đóng game |
| Đại thành NPC | Trung tâm vùng có quân, cứ điểm và nguồn lực | Giá trị chiến lược lớn hơn thành thường; không tự có quyền tài sản toàn vùng |
| Trại người chơi | Điểm đóng quân và tiếp tế ngoài thành | Không được vẽ/ghi nhãn như trại NPC hoặc thành |

Mỗi nhóm có thang 1–20 theo D20, nhưng ý nghĩa và cách tính hạng chưa khóa. Cùng số 20 không chứng minh cùng sức chiến đấu. Mức đe dọa cần gắn với lực lượng và tình báo thật.

## 2. NPC chủ động

D26 chốt hướng có hành vi chủ động. Thổ phỉ cướp xe, phản kích mỏ, viễn chinh và phục quốc là các phương án, chưa phải toàn bộ tính năng đã duyệt.

Đề xuất mỗi hành động NPC dùng lực lượng, vị trí, thời gian di chuyển và ngân sách được ghi. Nếu hệ thống bổ sung quân hoặc tài nguyên NPC, đó phải là nguồn cấp có quy tắc và giới hạn, không giấu trong kết quả trận hoặc nhân theo độ giàu của mục tiêu.

O23 cần xác định:

- NPC biết gì về mục tiêu, quan sát bằng cách nào và không được dùng bí mật nào.
- Điều kiện chọn mục tiêu, khoảng cảnh báo và giới hạn số cuộc quấy nhiễu.
- Nguồn quân, lương, chiến lợi phẩm, cách hồi, hành vi khi đã thua hoặc cạn ngân sách.
- Tránh vòng farm hồi sinh và ưu thế của người canh đúng giờ.
- Không để NPC khiến mọi thành đều phải có quân theo một quota vô hình.

Ưu tiên thử một phản công cố định có thể giải thích ở bản giấy/mô phỏng. Hệ thống ghi nhớ vùng và phục quốc nhiều bước để sau khi đã kiểm chứng nguồn lực và độ dễ hiểu.

## 3. Vùng và quyền sở hữu

Một vùng có thể có Đại thành trung tâm và nhiều thành thuộc những người khác nhau. Quyền cai trị vùng và quyền sở hữu từng tài sản phải tách biệt.

D23 không trao cho chủ Đại thành quyền ra lệnh, lấy kho, nhận quân, áp thuế hoặc đổi chủ thành của người khác. Nếu sau này đề xuất thêm một quyền vùng, cần quyết định mới, không suy từ chữ “cai trị”.

Đề xuất một địa điểm thuộc một vùng tại một phiên bản bản đồ; lớp ranh giới vùng tách khỏi màu chủ quyền. O21 quyết định biên vùng, đối tượng nhận thưởng và hiệu lực khi thay bản đồ. Kiểm soát mỏ có đổi quyền đất hay không vẫn thuộc O20/O03.

## 4. Thưởng Đại thành B

**Phần đã chốt D25:**

- Thưởng toàn đế chế không vượt +20%.
- Thưởng vùng hợp lệ không vượt +20%.
- Tổng thưởng Đại thành tại một nơi không vượt +40% sản lượng cơ bản.
- Cộng hai phần, không nhân nối tiếp; không lặp thưởng theo số Đại thành và không cộng nhiều thưởng vùng cho cùng nơi.

Diễn đạt toán học chỉ cho **phần thưởng Đại thành**, với `B` là cơ sở tính còn phải chọn:

```text
0 <= g <= 0.20
0 <= r <= 0.20
b = min(g + r, 0.40)
great_city_bonus = B * b
```

Đây là cách viết giới hạn đã chọn, không phải công thức đầy đủ của kinh tế. Chưa xác định `B`, điều kiện `g/r` khác 0, cách làm tròn, thời điểm hiệu lực hoặc cách tương tác với công nghệ khác. Không tính thưởng lên chính phần thưởng đã cộng.

### Các điều kiện còn mở ở O21

| Vấn đề | Phương án để thử, chưa duyệt |
|---|---|
| Người nhận thưởng vùng | Chỉ tài sản của chủ Đại thành trong vùng, không mặc định mọi thành của người khác |
| Nguồn tính B | Chỉ sản xuất ô tài nguyên nội thành; loại mỏ, chiến lợi phẩm, giao dịch và gói hỗ trợ |
| Sau chiếm | Tăng hiệu lực dần theo giữ ổn định và phiên bản sở hữu |
| Thành cô lập | Có/không cần kết nối hợp lệ; cần định nghĩa đường và tình trạng bị cắt |
| Đang bị vây | Có giảm/ngưng thưởng không; tránh một lực lượng nhỏ làm thiệt toàn đế chế |
| Mất Đại thành | Dừng ngay hay chuyển tiếp; không tự tiếp tục quyền cho chủ cũ |
| Nhiều Đại thành | Quy tắc chọn nguồn hợp lệ và chống nhận trùng |
| Biên vùng/đổi chủ | Mốc logic tính từng đoạn, phiên bản vùng và quyền |

Nếu thử giảm dần sau mất trong khi chủ mới đã nhận thưởng, phải giải quyết việc hai bên cùng hưởng một nguồn. Không tự chọn cơ chế này chỉ vì reviewer nêu. Cần đánh giá cả khả năng sụp đổ dây chuyền lẫn lạm dụng ân hạn.

Thưởng phần trăm đem lại lượng tuyệt đối lớn hơn cho đế chế lớn; cap +40% chưa chứng minh chống độc bá. Sửa số hoặc giới hạn người nhận ngoài phạm vi đã chốt cần được ghi thành thay đổi D25.

## 5. Chiếm, dời đô và nhập thành

Đại thành phải qua điều kiện chiếm và tiếp quản như cơ chế tương ứng, không đổi chủ chỉ vì thắng một trận. Quân/tài sản người thua và lực lượng NPC được giải quyết theo nguồn và chủ riêng.

D24 cho phép chuyển trung tâm đế chế về Đại thành đã chiếm. **Phương án đơn giản để thử** là đổi địa điểm trung tâm; quân hành quân và hàng vận chuyển thật. Chưa có quyền cộng cấp công trình, cộng kho, gộp hai thành hoặc đổi gốc mọi quân tức thời.

Nếu có “nhập thành”, phải đặc tả tài sản nào chuyển, tài sản nào mất/giữ, điều kiện ô, giới hạn kho, thời gian, quyền hủy và nhật ký nguồn. Không dùng quyền tái lập như công cụ nâng miễn phí Đại thành, vẫn giữ nguyên thành cũ rồi nhận thêm cùng tài sản.

Thời gian chờ đổi đô, thành cũ có còn là thành thường, ảnh hưởng tới hành chính và điều kiện nhận thưởng thuộc O22. Đổi đô không mặc định thay quyền sở hữu vùng.

## 6. Thành bỏ hoang

Tách thành hoang do preset thế giới tạo với thành người chơi/NPC chủ động bỏ lại. Công trình và kho có nguồn lịch sử để biết tài sản mới hay chuyển chủ. Tái lập hoặc nhường thành không nhân hỗ trợ ngầm.

O26 không còn là hệ thống đổi tài khoản bất hoạt thành NPC. Offline không tự mất thành vì người chơi đi vắng. Nếu cho tháo dỡ/bỏ thành, cần thời gian, quyền, vận tải và xử lý gián đoạn riêng; chưa mặc định hủy thành trước mặt đối thủ.

Quy tắc không chia cấp thành bị chiếm giữ nguyên. Cấp xuống do hư hại/tháo dỡ nếu sau này có phải có nguồn riêng, không mượn tỷ lệ tái lập.

## 6.1. Đoàn có căn cứ, lưu vong và du mục

Thí điểm dùng Army có mission, lương/hàng thật, chuỗi hành quân thường tới địa điểm và khoảng dừng. Trận chỉ tại địa điểm: đi ngang nhau giữa đường chưa giao chiến, không kể là đã có cướp xe/hộ tống.

Có căn cứ giữ cap gốc; tàn quân không có suất/tuyển mới ngầm; du mục có mô hình mobile chỉ NPC cấu hình, chưa khóa công thức và bổ sung. Nguồn spawn/cấp ban đầu/ngân sách/trần phải rõ. Truy đuổi theo tin đã biết và điểm cuối thấy, không đọc vị trí ẩn.

Dừng không tự claim đất; định cư/giao thương/qua biên là phạm vi riêng. Xem O36–O38 và [đặc tả đoàn](mobile-npcs.md). Các tên phe trong U08 là tham khảo, không bắt có đủ bảy phe trong bản thử.

## 7. Hiển thị và thông tin

Bản đồ dùng hình loại mục tiêu, huy hiệu chủ và hạng cùng lúc. Trại NPC, thành NPC và Đại thành có ký hiệu khác nhau; thành người chơi không chỉ đổi màu từ cùng một nhãn NPC. Xem [giao diện và mỹ thuật](interface-and-art.md).

Chọn mục tiêu chỉ hiển thị thông tin được phép: loại, chủ, hạng, tọa độ, tình báo đã ghi và thời điểm. Số quân chưa trinh sát không được gửi sẵn xuống trình duyệt. Nút trinh sát/tấn công/chiếm/khai thác phụ thuộc quyền và trạng thái thực, không phải mọi NPC đều có đủ các nút.
