# Biên bản kiểm tra bộ tài liệu 2.2

Phiên bản 2.2 · 10/11/2026 · Snapshot kiểm tra docs trước khi bắt đầu sinh asset proof. Trạng thái hình mới xem [proof v01](../assets/previews/proof-v01/README.md); các số179 link/0 ảnh bên dưới thuộc snapshot này.

| Phạm vi | Kết quả |
|---|---|
| Nguồn gốc | Bảy file `reference-docs` và attachment U08 khớp SHA256 đã lưu |
| Lưu v2.1 | [archive v2.1](archive/crownlands-design-v2.1.zip) có 44 entry, integrity đạt, từng entry khớp byte file trước khi sửa; sources/reviews/proposals cũ và [Claude review 2.1](reviews/2026-11-07-supplement-02-claude-review.md) không đổi byte |
| Asset contract | Manifest/roster/layout JSON nguyên byte so với v2.0/2.1: 189 export `planned`, 16 proof/134 core bổ sung/39 expansion; 14 profile/14 slot/16 plot; repo có 0 file ảnh |
| Liên kết và mã | 179 liên kết Markdown tương đối ngoài archive đều có đích; B01–B28 (không B29), BS-01–BS-10, BS-T01–BS-T13, RV21-01–RV21-15, BUILD-01–BUILD-05 có mặt; D/P/O/I/N/CAL giữ namespace |
| S00 references | 0.2-draft parse; chủ/profile/gốc/capacity/site/custody tham chiếu hợp lệ, kho không vượt cap, 52 quân khởi đầu; `ai_budget` có floor ≤ garrison (headroom thủ đô 20, tiền thành 6), quota không dồn, không viện binh nội bộ |
| Bước đầu kinh tế | Theo số thử: 400 lương/giờ game, quân đầu ăn 52, còn 348; đủ vốn cho nâng ruộng đầu. Không chứng minh cân bằng |
| Đường đi tĩnh | BFS bốn hướng với núi/sông/cầu và **ô site không transit**: mỏ đất 8, mỏ lương 10, trại 10, tiền thành 19, thủ đô 36; thủ đô→tiền thành 17. Bỏ cầu: thủ đô 90 (đường vòng) |
| Phép tính tham chiếu | Kho 6000 đầy, +400/−52: net-clamp cho 6000 khi chia 1/2/4 đoạn (cách cũ 5948/5974/5987); 100 lương với −52/h chạm 0 tại 90000/13 giây, event tick 6924; toy phân bổ 1 quantum cho 2 claim bằng nhau tất định khi đổi thứ tự và tách cùng key. **Không phải engine test** |
| Trạng thái game | Không gọi engine, không thử AI/trận/đói/cache/lưu/tua; BS-T và RV21 là expected outcomes chưa chạy |
| Trạng thái review | Claude review B23–B28/S00 (C09) đã có; các lựa chọn sửa 2.2 là của Codex (C10), chưa được Claude review lại |
| Trạng thái hình | Không tạo ảnh, không thêm asset, chưa duyệt hình proof |

Kết quả máy đọc ở [static validation](prototype/static-validation.json), kèm hash S00 trước/sau và lý do đổi. S00 là **specification fixture**, chưa là save hoặc ruleset đầy đủ: còn thiếu combat/health theo profile, lịch đói CAL10, cost/tech đầy đủ, AI scoring/targeting CAL11 và schema trước khi chạy thật.

[Đối chiếu BS](prototype-readiness.md), [resolution 2.2](reviews/2026-11-10-supplement-02-resolution.md), [scenario S00](prototype/scenarios/first-foundation.json), [baseline](final-design.md) và [asset plan](asset-production-plan.md) là các điểm vào hiện hành.
