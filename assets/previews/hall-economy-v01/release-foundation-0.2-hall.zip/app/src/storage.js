import {createGame,RESOURCES,SCALE,RULESET,MAX_TIME,FIELD_COST} from './game.js';
import {validateCurrentState} from './state-validation.js';
const PRIMARY='crownlands.foundation.primary', BACKUP='crownlands.foundation.backup';
const MAX_BYTES=2_000_000;
const bad=()=>{throw new Error('Bản lưu không hợp lệ hoặc không tương thích với bản thử.');};
const integer=(n,min=0,max=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
const keys=(obj,names)=>obj&&typeof obj==='object'&&!Array.isArray(obj)&&Object.keys(obj).length===names.length&&names.every(k=>Object.hasOwn(obj,k));

function validateLegacyState(g,scenario) {
  if(!g||typeof g!=='object'||Array.isArray(g)||!integer(g.schema))bad();
  if(g.schema!==1)throw new Error('Bản lưu dùng phiên bản luật chưa được hỗ trợ.');
  if(typeof g.ruleset!=='string'||!g.ruleset)bad();
  if(g.ruleset!=='foundation-0.1')throw new Error('Bản lưu dùng phiên bản luật chưa được hỗ trợ.');
  const template=createGame(scenario);
  if(g.scenario!==scenario.id||!integer(g.time,0,MAX_TIME)||!integer(g.sequence,0,16))bad();
  if(!keys(g.clock,['paused','speed','remainder'])||typeof g.clock.paused!=='boolean'||![1,2,4,8].includes(g.clock.speed)||!integer(g.clock.remainder,0,999))bad();
  if(!Array.isArray(g.cities)||g.cities.length!==3||!Array.isArray(g.jobs)||g.jobs.length>16||!Array.isArray(g.events)||g.events.length>40)bad();
  g.cities.forEach((c,i)=>{
    const t=template.cities[i];
    if(c.id!==t.id||c.owner!==t.owner||c.upkeep!==t.upkeep||JSON.stringify(c.buildings)!==JSON.stringify(t.buildings)||JSON.stringify(c.cap)!==JSON.stringify(t.cap))bad();
    if(!Array.isArray(c.plots)||c.plots.length!==16)bad();
    c.plots.forEach((p,j)=>{if(p.id!==t.plots[j].id||p.resource!==t.plots[j].resource||![1,2].includes(p.level)||c.owner!=='player'&&p.level!==t.plots[j].level)bad();});
    if(!keys(c.stock,RESOURCES)||!keys(c.ledger,RESOURCES))bad();
    for(const r of RESOURCES){
      if(!integer(c.stock[r],0,c.cap[r]*SCALE)||!keys(c.ledger[r],['produced','upkeep','overflow','unmet','spent'])||Object.values(c.ledger[r]).some(n=>!integer(n,0,4e15)))bad();
      const l=c.ledger[r],maxExpense=r==='grain'?g.time*c.upkeep*1000:0;
      if(l.produced>g.time*500000||l.upkeep+l.unmet>maxExpense||l.overflow>l.produced||l.spent!==(c.owner==='player'?g.sequence*FIELD_COST[r]*SCALE:0))bad();
    }
  });
  const ids=new Set(),plots=new Set();
  for(const j of g.jobs){
    const p=g.cities[0].plots.find(p=>p.id===j.plot);
    if(!keys(j,['id','city','plot','started','ends'])||!integer(j.id,1,g.sequence)||ids.has(j.id)||plots.has(j.plot)||j.city!==g.cities[0].id||!p||p.level!==1||!integer(j.started,0,g.time)||j.ends!==j.started+120||j.ends<=g.time||j.ends>MAX_TIME)bad();
    ids.add(j.id);plots.add(j.plot);
  }
  const completed=g.cities[0].plots.filter(p=>p.level===2).length;
  if(g.sequence!==completed+g.jobs.length)bad();
  let last=-1;
  for(const e of g.events){
    if(!keys(e,['time','kind','city','plot'])||!integer(e.time,last,g.time)||e.kind!=='plot-complete'||e.city!==g.cities[0].id||!g.cities[0].plots.some(p=>p.id===e.plot&&p.level===2))bad();
    last=e.time;
  }
  return g;
}

function validateState(g,scenario){
  if(!g||typeof g!=='object'||Array.isArray(g)||!integer(g.schema))bad();
  if(g.schema!==1&&g.schema!==2)throw new Error('Bản lưu dùng phiên bản luật chưa được hỗ trợ.');
  if(typeof g.ruleset!=='string'||!g.ruleset)bad();
  if(g.schema===1){
    validateLegacyState(g,scenario);
    const next=structuredClone(g),template=createGame(scenario);
    next.schema=2;next.ruleset=RULESET;next.training=[];next.trainingSequence=0;
    next.cities.forEach((c,i)=>{c.troops={...template.cities[i].troops};c.capacity=template.cities[i].capacity;});
    return validateCurrentState(next,scenario);
  }
  if(g.schema!==2)throw new Error('Bản lưu dùng phiên bản luật chưa được hỗ trợ.');
  return validateCurrentState(g,scenario);
}

export function encodeSave(game) { return JSON.stringify(game,null,2); }
export function decodeSave(text,scenario) {
  if(typeof text!=='string'||text.length>MAX_BYTES)bad();
  return validateState(JSON.parse(text),scenario);
}

const empty=()=>({version:1,session:null,manual:[null,null,null],quick:null,autos:[]});
export class SaveStore {
  constructor(storage,scenario) { this.storage=storage;this.scenario=scenario; }
  parse(text) {
    if(text.length>20*MAX_BYTES)bad();
    const d=JSON.parse(text);
    if(d&&integer(d.version,2))throw new Error('Kho lưu dùng phiên bản mới hơn; hãy giữ lại dữ liệu để khôi phục.');
    if(!d||d.version!==1)bad();
    if(!keys(d,['version','session','manual','quick','autos'])||!Array.isArray(d.manual)||d.manual.length!==3||!Array.isArray(d.autos)||d.autos.length>5)bad();
    for(const r of [d.session,d.quick,...d.manual,...d.autos])if(r!==null){
      if(!keys(r,['savedAt','state'])||!integer(r.savedAt))bad();r.state=validateState(r.state,this.scenario);
    }
    return d;
  }
  read() {
    const primary=this.storage.getItem(PRIMARY),backup=this.storage.getItem(BACKUP);
    if(primary===null&&backup===null)return {data:empty(),recovered:false};
    if(primary!==null){
      try{return {data:this.parse(primary),recovered:false};}
      catch(e){if(/phiên bản/.test(e.message))throw e;}
    }
    if(backup!==null){try{return {data:this.parse(backup),recovered:true};}catch{ /* retain both originals */ }}
    throw new Error('Không thể khôi phục bản lưu. Hãy nhập bản dự phòng hoặc chủ động chọn chơi mới.');
  }
  save(game,slot='session') {
    game=validateState(game,this.scenario);
    const {data,recovered}=this.read(),before=!recovered?this.storage.getItem(PRIMARY)??JSON.stringify(data):JSON.stringify(data);
    const record={savedAt:Date.now(),state:structuredClone(game)};
    if(slot==='quick')data.quick=record;
    else if(slot==='auto')data.autos=[record,...data.autos].slice(0,5);
    else if(/^manual-[0-2]$/.test(slot))data.manual[Number(slot.at(-1))]=record;
    else if(slot!=='session')throw new Error('Ô lưu không tồn tại.');
    data.session=record;
    this.storage.setItem(BACKUP,before);
    this.storage.setItem(PRIMARY,JSON.stringify(data));
    return record;
  }
  // Only called after an explicit new-game recovery choice. Manual saves are retained when valid.
  resetSession(game) {
    let data;
    try {data=this.read().data;} catch {data=empty();}
    data.session={savedAt:Date.now(),state:structuredClone(validateState(game,this.scenario))};
    this.storage.setItem(PRIMARY,JSON.stringify(data));
  }
}
