import {IMAGES,knownSites} from './visuals.js';

export class WorldMap {
  constructor(canvas,scenario,onSelect){
    this.canvas=canvas;this.ctx=canvas.getContext('2d');this.scenario=scenario;this.onSelect=onSelect;
    this.sites=knownSites(scenario);this.camera={x:16,y:32,zoom:1.5};this.selected=scenario.settlements[0].id;this.images={};
    for(const [key,src] of Object.entries({...IMAGES,grass:'./assets/grass.webp'})){
      const im=new Image();im.onload=()=>{this.images[key]=im;this.draw();};im.src=src;
    }
    new ResizeObserver(()=>this.draw()).observe(canvas);
    let pointer=null;
    canvas.addEventListener('pointerdown',e=>{canvas.focus();pointer={id:e.pointerId,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId);});
    canvas.addEventListener('pointermove',e=>{if(!pointer)return;const dx=e.clientX-pointer.x,dy=e.clientY-pointer.y;
      if(Math.hypot(e.clientX-pointer.startX,e.clientY-pointer.startY)>5)pointer.moved=true;
      this.camera.x-=dx/(32*this.camera.zoom);this.camera.y-=dy/(32*this.camera.zoom);pointer.x=e.clientX;pointer.y=e.clientY;this.bound();this.draw();});
    canvas.addEventListener('pointerup',e=>{if(!pointer)return;if(!pointer.moved){const rect=canvas.getBoundingClientRect(),pt=this.toWorld(e.clientX-rect.left,e.clientY-rect.top),tol=32/this.scale;
      const s=this.sites.find(s=>Math.hypot(pt.x-s.position[0]-.5,pt.y-s.position[1]-.5)<tol);if(s){this.selected=s.id;onSelect(s);this.draw();}}
      pointer=null;});
    canvas.addEventListener('pointercancel',()=>pointer=null);
    canvas.addEventListener('wheel',e=>{e.preventDefault();const rect=canvas.getBoundingClientRect();this.zoom(Math.exp(-e.deltaY*.0015),e.clientX-rect.left,e.clientY-rect.top);},{passive:false});
    canvas.addEventListener('keydown',e=>{const moves={ArrowLeft:[-2,0],ArrowRight:[2,0],ArrowUp:[0,-2],ArrowDown:[0,2]};if(moves[e.key]){e.preventDefault();this.camera.x+=moves[e.key][0];this.camera.y+=moves[e.key][1];this.bound();this.draw();}});
  }
  get scale(){return 32*this.camera.zoom;}
  bound(){this.camera.x=Math.max(0,Math.min(64,this.camera.x));this.camera.y=Math.max(0,Math.min(64,this.camera.y));}
  toWorld(x,y){return{x:(x-this.width/2)/this.scale+this.camera.x,y:(y-this.height/2)/this.scale+this.camera.y};}
  point(x,y){return{x:(x-this.camera.x)*this.scale+this.width/2,y:(y-this.camera.y)*this.scale+this.height/2};}
  zoom(factor,x=this.width/2,y=this.height/2){const a=this.toWorld(x,y);this.camera.zoom=Math.max(.45,Math.min(3,this.camera.zoom*factor));const b=this.toWorld(x,y);this.camera.x+=a.x-b.x;this.camera.y+=a.y-b.y;this.bound();this.draw();}
  focus(site){this.selected=site.id;this.camera.x=site.position[0]+.5;this.camera.y=site.position[1]+.5;this.draw();}
  draw(){
    const box=this.canvas.getBoundingClientRect();if(!box.width||!box.height)return;
    this.width=box.width;this.height=box.height;const dpr=Math.min(2,window.devicePixelRatio||1);
    if(this.canvas.width!==Math.round(box.width*dpr)||this.canvas.height!==Math.round(box.height*dpr)){this.canvas.width=Math.round(box.width*dpr);this.canvas.height=Math.round(box.height*dpr);}
    const ctx=this.ctx;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#304735';ctx.fillRect(0,0,this.width,this.height);
    const tl=this.toWorld(0,0),br=this.toWorld(this.width,this.height),origin=this.scenario.settlements[0].position;
    for(let y=Math.max(0,Math.floor(tl.y));y<Math.min(64,Math.ceil(br.y));y++)for(let x=Math.max(0,Math.floor(tl.x));x<Math.min(64,Math.ceil(br.x));x++){
      const p=this.point(x,y),s=this.scale,distance=Math.abs(x-origin[0])+Math.abs(y-origin[1]),known=distance<=12,vision=distance<=6;
      if(!known){ctx.fillStyle=(x+y)%2?'#314936':'#324b37';ctx.fillRect(p.x,p.y,s+1,s+1);ctx.strokeStyle='#d1dab206';ctx.strokeRect(p.x,p.y,s,s);continue;}
      if(this.images.grass){ctx.drawImage(this.images.grass,(x%4)*64,(y%4)*64,64,64,p.x,p.y,s+1,s+1);}
      else {ctx.fillStyle='#849b59';ctx.fillRect(p.x,p.y,s+1,s+1);}
      ctx.fillStyle=vision?'#93a96b20':'#30482e55';ctx.fillRect(p.x,p.y,s+1,s+1);
      const mountains=this.scenario.world.mountain_rectangles.some(([x1,y1,x2,y2])=>x>=x1&&x<=x2&&y>=y1&&y<=y2);
      if(mountains){ctx.fillStyle='#7b8767';ctx.beginPath();ctx.moveTo(p.x,p.y+s);ctx.lineTo(p.x+s*.48,p.y+s*.08);ctx.lineTo(p.x+s,p.y+s);ctx.fill();ctx.fillStyle='#a5af89';ctx.beginPath();ctx.moveTo(p.x+s*.48,p.y+s*.08);ctx.lineTo(p.x+s*.75,p.y+s*.75);ctx.lineTo(p.x+s*.5,p.y+s*.6);ctx.fill();}
      if(x===36&&y>=4&&y<=59){ctx.fillStyle='#5c8d87';ctx.fillRect(p.x,p.y,s+1,s+1);if(y===32){ctx.fillStyle='#baac7d';ctx.fillRect(p.x,p.y+s*.3,s,s*.4);}}
      // Cosmetic woodland; does not add a site, resource or collision rule.
      if(!mountains&&x!==36&&((x*31+y*17)%29<5)&&!this.sites.some(t=>Math.abs(t.position[0]-x)+Math.abs(t.position[1]-y)<2)){
        ctx.fillStyle=vision?'#5a7943':'#516c40';for(let i=0;i<3;i++){const tx=p.x+s*(.2+i*.22),ty=p.y+s*(.36+(i%2)*.25);ctx.beginPath();ctx.moveTo(tx,ty-s*.2);ctx.lineTo(tx-s*.15,ty+s*.2);ctx.lineTo(tx+s*.15,ty+s*.2);ctx.fill();}
      }
      ctx.strokeStyle='#f2e1a20c';ctx.strokeRect(p.x,p.y,s,s);
    }
    // Known territory, never an omniscient political map.
    ctx.strokeStyle='#d7ca8d66';ctx.lineWidth=1.5;ctx.setLineDash([5,5]);ctx.beginPath();
    for(const [i,[dx,dy]] of [[0,-6],[6,0],[0,6],[-6,0]].entries()){const p=this.point(origin[0]+dx+.5,origin[1]+dy+.5);if(i)ctx.lineTo(p.x,p.y);else ctx.moveTo(p.x,p.y);}ctx.closePath();ctx.stroke();ctx.setLineDash([]);
    for(const site of this.sites){const p=this.point(site.position[0]+.5,site.position[1]+.5),active=this.selected===site.id,size=site.kind==='city'?this.scale*1.15:this.scale*.95;
      ctx.fillStyle='#162e2540';ctx.beginPath();ctx.ellipse(p.x,p.y+this.scale*.14,size*.38,size*.15,0,0,Math.PI*2);ctx.fill();
      if(active){ctx.strokeStyle='#f6d58d';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(p.x,p.y+this.scale*.15,size*.48,size*.25,0,0,Math.PI*2);ctx.stroke();}
      const im=this.images[site.kind];if(im)ctx.drawImage(im,p.x-size/2,p.y-size*.65,size,size);
      if(this.camera.zoom>=.7){ctx.font=`${active?'600 ':''}${Math.max(10,Math.min(12,this.scale*.24))}px system-ui`;ctx.textAlign='center';const label=site.name,w=ctx.measureText(label).width+18;
        ctx.fillStyle=active?'#2c422eee':'#29402cc9';ctx.fillRect(p.x-w/2,p.y+size*.39,w,22);ctx.fillStyle=active?'#f1dba5':'#d5ddbb';ctx.fillText(label,p.x,p.y+size*.39+15);}
    }
    // Edge vignette keeps map labels readable against the source grass.
    const v=ctx.createRadialGradient(this.width*.5,this.height*.5,this.width*.15,this.width*.5,this.height*.5,Math.max(this.width,this.height)*.7);v.addColorStop(0,'#112b1600');v.addColorStop(1,'#112b1666');ctx.fillStyle=v;ctx.fillRect(0,0,this.width,this.height);
    document.querySelector('#zoom-label').textContent=`${Math.round(this.camera.zoom*100)}%`;
    document.querySelector('.map-location').textContent=`${Math.round(this.camera.x)} : ${Math.round(this.camera.y)}`;
  }
}
