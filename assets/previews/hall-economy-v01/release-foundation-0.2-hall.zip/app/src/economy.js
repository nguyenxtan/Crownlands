import {RESOURCES,SCALE,MAX_TIME,rates,advanceGame} from './game.js';
import {UNIT_RULES,troopCount} from './units.js';

const cityById=(game,id)=>{
  const city=game.cities.find(city=>city.id===id);
  if(!city)throw new Error('Không tìm thấy thành.');
  return city;
};

export function economySnapshot(game,cityId){
  const city=cityById(game,cityId),net=rates(city),training=game.training.filter(job=>job.city===cityId);
  return {cityId,time:game.time,troops:troopCount(city),capacity:city.capacity,
    upgrades:game.jobs.filter(job=>job.city===cityId).length,trainingOrders:training.length,
    queuedTroops:training.reduce((sum,job)=>sum+job.remaining,0),
    upkeepAfterQueue:city.upkeep+training.reduce((sum,job)=>sum+job.remaining*UNIT_RULES[job.profile].upkeep,0),
    resources:Object.fromEntries(RESOURCES.map(resource=>{
      const upkeep=resource==='grain'?city.upkeep:0;
      return [resource,{stock:city.stock[resource],capacity:city.cap[resource]*SCALE,production:net[resource]+upkeep,upkeep,net:net[resource],ledger:{...city.ledger[resource]}}];
    }))};
}

export function forecastEconomy(game,cityId,requestedSeconds=3600){
  if(!Number.isSafeInteger(requestedSeconds)||requestedSeconds<0)throw new Error('Khoảng dự báo không hợp lệ.');
  const current=economySnapshot(game,cityId),seconds=Math.min(requestedSeconds,MAX_TIME-game.time),ends=game.time+seconds;
  const simulation=structuredClone(game),boundaries=new Set([ends]);
  for(const job of game.jobs)if(job.city===cityId)boundaries.add(job.ends);
  for(const job of game.training)if(job.city===cityId){
    for(let count=0;count<job.remaining;count++)boundaries.add(job.next+count*UNIT_RULES[job.profile].seconds);
  }
  const milestones=Object.fromEntries(RESOURCES.map(resource=>[resource,{fullIn:null,emptyIn:null}]));
  function checkMilestones(until){
    const city=cityById(simulation,cityId),net=rates(city),duration=until-simulation.time;
    for(const resource of RESOURCES){
      const milestone=milestones[resource],stock=city.stock[resource],capacity=city.cap[resource]*SCALE,perSecond=net[resource]*(SCALE/3600);
      if(milestone.fullIn===null&&(stock===capacity||perSecond>0)){
        const crossing=stock===capacity?0:Math.ceil((capacity-stock)/perSecond);
        if(crossing<=duration)milestone.fullIn=simulation.time-game.time+crossing;
      }
      if(milestone.emptyIn===null&&perSecond<0){
        const crossing=Math.ceil(stock/-perSecond);
        if(crossing<=duration)milestone.emptyIn=simulation.time-game.time+crossing;
      }
    }
  }
  let projected;
  // Follow the same integer simulation as the live game. Each existing order is
  // already paid; advancing its completion only changes production or upkeep.
  for(const boundary of [...boundaries].filter(time=>time>=game.time&&time<=MAX_TIME).sort((a,b)=>a-b)){
    checkMilestones(boundary);advanceGame(simulation,boundary-simulation.time);
    if(boundary===ends)projected=economySnapshot(simulation,cityId);
  }
  // Once all known local jobs finish, rates are constant. Find remaining storage
  // milestones analytically, without integrating years just to show an ETA.
  checkMilestones(MAX_TIME);
  return {requestedSeconds,seconds,ends,resources:Object.fromEntries(RESOURCES.map(resource=>{
    const before=current.resources[resource],after=projected.resources[resource];
    return [resource,{stock:after.stock,net:after.net,change:after.stock-before.stock,
      produced:after.ledger.produced-before.ledger.produced,upkeep:after.ledger.upkeep-before.ledger.upkeep,
      overflow:after.ledger.overflow-before.ledger.overflow,unmet:after.ledger.unmet-before.ledger.unmet,...milestones[resource]}];
  }))};
}
